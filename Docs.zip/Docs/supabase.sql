-- ============================================================================
--  EcomStrait — Supabase schema for lead capture + newsletter
--  Run this in the Supabase SQL editor (Dashboard → SQL → New query).
--  The app writes with the public anon key, so RLS must allow anonymous
--  INSERTs. There is no public SELECT policy, so the tables are write-only
--  from the browser — read your leads from the Supabase dashboard.
-- ============================================================================

-- ---- Leads (contact, supplier applications, store consultations) -----------
create table if not exists public.leads (
  id         uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  form_name  text not null default 'lead',
  name       text,
  email      text not null,
  page       text,
  payload    jsonb not null default '{}'::jsonb
);

alter table public.leads enable row level security;

-- Allow anonymous (and authenticated) inserts; no select/update/delete.
drop policy if exists "leads_insert_anon" on public.leads;
create policy "leads_insert_anon"
  on public.leads
  for insert
  to anon, authenticated
  with check (true);

-- ---- Newsletter subscribers ------------------------------------------------
create table if not exists public.newsletter_subscribers (
  id         uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  email      text not null unique,
  source     text
);

alter table public.newsletter_subscribers enable row level security;

drop policy if exists "newsletter_insert_anon" on public.newsletter_subscribers;
create policy "newsletter_insert_anon"
  on public.newsletter_subscribers
  for insert
  to anon, authenticated
  with check (true);
