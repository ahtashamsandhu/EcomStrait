# EcomStrait — Monorepo + Supplier Portal Implementation Plan

> Working plan derived from **Doc 09** (Supplier Onboarding & Experience),
> **Doc 12** (Technical Architecture), **Doc 13** (Database Design), and
> **Doc 14** (Auth & Security). Companion to `AI-Implementation-Plan.md` (the
> marketing site). Review target: agree on the locked decisions, then build
> phase by phase, foundation-first.

## 1. Decision — what we're building

A **real, authenticated Supplier Portal** (signup, login, onboarding, verified
dashboard, catalog/inventory/order management, AI assist, analytics) as a
**separate app inside this repo**, converted to a pnpm **monorepo** per Doc 12.
This is a product build, not a marketing preview — it is *not* bolted onto the
marketing site.

The current marketing site keeps its "simulated preview" positioning and moves,
unchanged in behaviour, to `apps/website`.

### Locked decisions (confirm before Phase 0)
- **Monorepo tooling:** pnpm workspaces (already present) + **Turborepo** for
  task caching / pipelines. Node 22, pnpm 10.
- **Auth:** **Supabase Auth** — email/password + **Google OAuth** (Microsoft
  later). We already run Supabase; it issues JWTs, integrates with RLS for
  multi-tenant isolation, and needs no new vendor. Satisfies Doc 12's "JWT +
  OAuth" and Doc 14's RBAC.
- **DB:** the existing Supabase project, extended with the supplier schema
  (Doc 13). Row-Level Security scopes every supplier row to its owner.
- **UI:** extract the current design system (tokens, `Button`, `Badge`,
  `Section`, `Icon`, `Reveal`, forms) into a shared `packages/ui` so both apps
  render identically.
- **Order model:** store owners send **product requests** to suppliers (Doc 09
  "Order & Request Management"). The merchant side that *creates* requests is a
  later app; for now the supplier portal consumes requests (seedable/admin-made)
  so the dashboard is real end-to-end.

### Open decisions (need your call)
1. **Move the website into `apps/website` now** (clean monorepo) vs. leave it at
   root and only add `apps/supplier` (less churn, messier). *Recommend: move it.*
2. **Supabase Auth** as above vs. Clerk/Auth.js. *Recommend: Supabase Auth.*
3. **Staff sub-roles** (`Supplier Staff`, Doc 14) in v1 or deferred. *Recommend:
   model the `role` from day one, build the staff UI later.*

## 2. Target monorepo structure

```text
EcomStrait/
  apps/
    website/            # current marketing site (moved from repo root, unchanged)
    supplier/           # NEW — the Supplier Portal (Next.js 16 App Router)
  packages/
    ui/                 # design tokens + shared components (Button, Section, forms…)
    auth/               # Supabase auth client, session helpers, RBAC guards
    db/                 # Supabase clients (browser/server), generated types, query helpers
    config/             # shared eslint, tsconfig, tailwind base, prettier
  supabase/
    migrations/         # existing + new supplier schema, storage buckets, RLS
  Docs/
  turbo.json
  pnpm-workspace.yaml   # packages: apps/*, packages/*
```

Shared imports become `@ecomstrait/ui`, `@ecomstrait/auth`, `@ecomstrait/db`.
Each app keeps its own `@/*` → `./src/*` path alias.

## 3. Data model (Supabase, from Doc 13)

New migrations, all `snake_case`, all with `id uuid`, `created_at`, `updated_at`,
and RLS. Ownership resolved via `auth.uid()`.

- `profiles` — one row per auth user: `user_id (=auth.uid)`, `role`
  (`supplier` | `supplier_staff` | `admin`), `full_name`. Auto-created on signup.
- `suppliers` — the business/tenant: `owner_user_id`, `business_name`,
  `business_type`, `status` (`pending`|`in_review`|`approved`|`rejected`),
  `quality_score`.
- `supplier_profiles` — extended details (years in business, description, website,
  logo, address).
- `supplier_documents` — `supplier_id`, `type`, `storage_path`, `status`
  (Supabase Storage private bucket).
- `supplier_verification` — the 5 levels (email/phone/docs/manual/badge) as
  boolean/timestamp columns; drives the Verified badge.
- `products` — `supplier_id`, title, description, category_id, images[],
  `wholesale_price`, `suggested_margin`, `status` (`draft`|`published`).
- `inventory` — `product_id`, `stock`, `reserved`, `low_stock_threshold`.
- `product_requests` — store-owner requests to a supplier: products, quantities,
  timeline, notes, `status` (`new`|`accepted`|`declined`|`fulfilled`).
- `supplier_ratings`, `categories` — supporting tables.

**RLS pattern:** a supplier reads/writes only rows where `supplier_id` belongs to
a `suppliers` row they own. Admin role bypasses via a policy. Storage bucket for
documents is private; signed URLs only.

## 4. Reused from the existing codebase
- **EcomAI engine** (`lib/ecomai.ts` + Groq client) → powers supplier AI assist
  (title/description/SEO/pricing) behind the same preset-fallback contract.
- **Notify/Resend** (`lib/notify.ts`) → verification + request emails.
- **Analytics** (`lib/analytics.ts` + `/api/track`) → supplier funnel events.
- **Design system** → extracted to `packages/ui`.

## 5. Phases

Foundation-first. Each phase ends buildable (`turbo build`) and demoable.

- **Phase 0 — Monorepo foundation** ✅ *DONE*
  - ✅ Turborepo added; `pnpm-workspace.yaml` = `apps/*` + `packages/*`; root
    `package.json` + `turbo.json` (with `globalEnv`).
  - ✅ Marketing site moved to `apps/website` (git-tracked move, content
    unchanged) → renamed `@ecomstrait/website`.
  - ✅ `packages/config` (`tsconfig.base.json`) + `packages/ui`
    (shared `theme.css` design tokens + `cn`). `packages/db` and `packages/auth`
    deferred to Phase 1, where they're first needed (kept P0 lean).
  - ✅ `apps/supplier` scaffolded (Next.js 16, Tailwind v4, port 3001,
    `transpilePackages: ["@ecomstrait/ui"]`, `noindex`) — consumes the shared
    theme + `cn` via a branded placeholder.
  - ✅ *Exit met:* `pnpm build` → 2/2 apps green; `pnpm lint` clean; website
    prerenders all 37 routes identically.

- **Phase 1 — Auth (signup / login)** ✅ *DONE (pending Supabase dashboard config)*
  - ✅ `packages/db` (typed `Database`/`Profile`, service-role admin client) and
    `packages/auth` (`@supabase/ssr` browser + server clients, `updateSession`
    proxy guard, `getUser`/`requireUser`/`getProfile` session helpers).
  - ✅ `profiles` migration: `user_role` enum, RLS (own-row read/update), a
    trigger that auto-creates a profile on `auth.users` insert, `updated_at`.
  - ✅ Supplier routes: `/signup`, `/login`, `/verify-email`, `/auth/callback`
    (OAuth + email-confirm PKCE exchange), protected `(app)` shell + `/dashboard`,
    sign-out server action, `proxy.ts` route guard (Next 16 convention).
  - ✅ *Exit met:* build 2/2 green, lint clean; unauthenticated `/dashboard` →
    307 `/login?redirect=/dashboard`; `/login` + `/signup` render.
  - ⏳ **Requires (to go live):** apply the `profiles` migration; set Supabase
    Auth **Site URL** + **Redirect URLs** to include each app's
    `/auth/callback`; (optional) enable **Google** provider; add the supplier
    Vercel project's env vars.

- **Phase 2 — Onboarding wizard (Doc 09 · 5 steps)** ✅ *DONE (pending migration)*
  - ✅ Migration: `suppliers` (all onboarding fields + status/step),
    `supplier_verification` (5 levels), `supplier_documents`, and a **private
    `supplier-documents` Storage bucket** with path-based RLS (`<uid>/…`).
  - ✅ 5-step wizard (`/onboarding`): Business info → Business details →
    Documents (direct-to-Storage upload) → Products → Review & terms. Config-
    driven fields, multiselect chips, stepper, per-step validation.
  - ✅ **Resumable** — progress upserts to `suppliers` each step
    (`onboarding_step`); the page rehydrates form + uploaded docs and jumps to
    the saved step. Submit sets `status = in_review`, records terms + marketing,
    seeds `supplier_verification` (email level from confirmed signup).
  - ✅ Status-aware dashboard banner (pending → in_review → approved → rejected).
  - ✅ *Exit met:* build + lint green; `/onboarding` guarded (307 → login);
    submit lands the supplier in "under review".
  - ⏳ **Requires:** apply `20260721110000_supplier_onboarding.sql`. Levels 3–5
    (doc/manual/badge) are tracked for the future admin review queue.

- **Phase 3 — Dashboard shell + overview** ✅ *DONE*
  - ✅ `AppChrome`: sidebar with active-link highlighting, mobile drawer,
    notifications popover, account menu (settings + sign out) — Doc 09 chrome.
  - ✅ Overview: status banner + stat tiles (real zeros / empty states) + a
    **live Verification Progress** widget reading the 5 levels from
    `supplier_verification`.
  - ✅ Nav destinations scaffolded: `/catalog` + `/requests` (branded empty
    states) and a real **`/settings`** (account + business profile from live data).
  - ✅ *Exit met:* build + lint green; protected pages render live data (no mock).

- **Phase 4 — Product catalog** ✅ *DONE (pending migration)*
  - ✅ Migration: `products` (pricing, stock, images, SEO, variants jsonb,
    draft/published) with RLS (owner writes; published rows world-readable) and a
    **public `product-images` bucket** (path-based write RLS).
  - ✅ CRUD: `/catalog` list (publish toggle, delete), `/catalog/new` +
    `/catalog/[id]/edit` form with multi-image upload to Storage.
  - ✅ **AI enrichment** (`lib/ai.ts`, Groq + preset fallback): one click fills
    description, SEO title/description, and a suggested retail price.
  - ✅ **CSV bulk import** (`/catalog/import`): built-in parser, auto column
    mapping + manual override, live preview, bulk insert as drafts.
  - ✅ *Exit met:* build + lint green; all catalog routes guarded; supplier can
    create products manually, via AI, and via CSV.

- **Phase 5 — Inventory** ✅ *DONE (pending migration)*
  - ✅ Migration: `products.reserved` + `inventory_adjustments` audit log (RLS
    via product→supplier ownership).
  - ✅ `/inventory`: summary tiles (products / in-stock / low / out), an
    editable table (inline stock + threshold, +/- quick adjust, **batch save**),
    a **low/out-of-stock filter**, and a **recent activity** history feed.
  - ✅ Every stock change logs an adjustment (delta + resulting level); available
    = stock − reserved drives the status badges.
  - ✅ Overview widgets now show real published-product + low-stock counts;
    "Inventory" added to the sidebar. (Warehouse/barcode = future, Doc 09.)
  - ✅ *Exit met:* build + lint green; stock levels drive availability + alerts.

- **Phase 6 — Requests & Orders** ✅ *DONE (pending migration)*
  - ✅ Migration: `product_requests` + `request_items` + `request_messages`
    (RLS: supplier-owned + admin; requests seeded by admin/service role).
  - ✅ **Requests and Orders are separate** (`20260722150000_orders.sql`):
    Requests is the inquiry inbox (**accept / decline / propose** + message
    thread); **accepting creates an Order**. `/orders` + `/orders/[id]` manage the
    fulfilment lifecycle (**processing → shipped → delivered / cancelled**) with
    line items, an estimated total, store-owner emails, and a link back to the
    originating request. Both approval-gated; "Orders to fulfil" in the bell.
  - ✅ Best-effort **email to the store owner** (Resend REST, no dep) on status
    changes and replies; system notes logged to the thread.
  - ✅ Admin **"Create sample request"** button seeds a request (until the
    merchant app exists); dashboard "Open requests" now shows the real count.
  - ✅ *Exit met:* build + lint green; routes guarded; end-to-end request flow works.

- **Phase 7 — Analytics, Quality Score, notifications** ✅ *DONE*
  - ✅ `/analytics` (Recharts): request volume (14-day trend), status breakdown,
    published-products-by-category, inventory health, and metric tiles
    (open requests, acceptance rate, avg. response time) — all from real tables.
  - ✅ **Supplier Quality Score (0–100)** (`lib/quality.ts`): profile
    completeness, verification, catalog depth, inventory health, response &
    acceptance rates → score + tier + factor breakdown; persisted to
    `suppliers.quality_score`, shown on the dashboard tile and admin list.
  - ✅ Notification centre: derived, actionable feed (onboarding, open requests,
    low stock) in the header bell with a count badge; email notifications for
    requests already ship (Phase 6).
  - ✅ *Exit met:* build + lint green; score + insights visible; nudges surfaced.

- **Admin review panel** ✅ *DONE (brought forward from Phase 8)*
  - ✅ `/admin` section in the supplier app, gated to `role = 'admin'`
    (`requireRole` in the layout; every admin action re-verifies role, then uses
    the **service-role client** to span tenants past owner-scoped RLS).
  - ✅ Review queue (`/admin/suppliers`, in-review first) + detail
    (`/admin/suppliers/[id]`): business info, **documents via signed URLs**,
    verification checklist, and **approve / reject / return** actions (approve
    grants the badge + verification timestamps and unlocks publishing).
  - ✅ Build + lint green; `/admin/*` guarded (unauth → login, non-admin → dashboard).

- **Roles & RBAC hardening** ✅ *DONE (pending migration)*
  - ✅ Role enum expanded to `admin | supplier | supplier_staff | business_owner
    | customer` (`profiles` is the single user/roles table).
  - ✅ DB-level RBAC: `is_admin()` / `current_user_role()` helpers + **admin RLS
    policies** on every table + document storage; secure signup (metadata can
    only self-assign non-privileged roles — never admin/staff).
  - ✅ **Dedicated `/admin/login`** (rejects non-admins) separate from the
    supplier `/login`; admin area regrouped under `(panel)` so login stays
    public; multi-guard proxy routes each area to its own login.
  - ✅ Admin **Users** page: list all accounts (email + role) with a role
    selector (`setUserRole`, self-lockout-guarded).

- **Phase 8 — Staff, support & polish** ✅ *DONE (pending migration)*
  - ✅ Migration: `supplier_members` + `is_member()` helper + **additive staff
    RLS** on the operational tables (owner policies untouched).
  - ✅ Team management (Settings → Team, owner-only): invite by email, list,
    remove. **Invites auto-link** on the teammate's next sign-in (email match,
    service-role). All app pages resolve the supplier via ownership OR active
    membership, so staff get full operational access (approval + owner-only
    actions still enforced).
  - ✅ Support: `/help` — FAQ + a support ticket form (emails the team,
    best-effort) — linked from the account menu.
  - ✅ Polish: app is `noindex`; shared reduced-motion CSS covers spinners/
    transitions; forms/icon-buttons are labelled; layouts are responsive.
  - ✅ *Exit met:* build + lint green; staff, support, and polish shipped.

## 6. Cross-cutting
- **Security (Doc 14):** RLS everywhere, JWT validation in middleware, permission
  checks server-side, audit log table for role/permission/verification changes,
  session revocation, private document storage with signed URLs.
- **Env:** reuse `NEXT_PUBLIC_SUPABASE_URL`/keys; add
  `NEXT_PUBLIC_SUPABASE_ANON_KEY` to the browser auth client; OAuth redirect URLs
  per app; document in each app's `.env.example`.
- **CI/deploy:** Turbo remote cache; deploy `apps/website` and `apps/supplier` as
  two projects (separate domains/subdomains, e.g. `app.ecomstrait.com`).

## 7. Risks & mitigations
| Risk | Mitigation |
|---|---|
| Monorepo move breaks the working site | Phase 0 is mechanical + verified by build before any feature work; git-tracked moves |
| Auth/RLS mistakes leak cross-tenant data | RLS-first, deny-by-default policies, tested with a second seed supplier |
| Scope explosion (full SaaS) | Strict phases; each ends demoable; merchant/admin apps explicitly out of scope |
| Requests have no producer yet | Seed `product_requests` + tiny admin/seed script until the merchant app lands |
| Design drift between apps | Single `packages/ui` + shared Tailwind tokens |

## 8. Needed from Shehzad
- Confirm the three **open decisions** in §1.
- Google OAuth credentials (client id/secret + redirect URIs) for Supabase Auth.
- Confirm domain/subdomain for the supplier app (e.g. `app.ecomstrait.com`).

---

**First deliverable on approval:** Phase 0 (monorepo restructure + `packages/*` +
`apps/supplier` scaffold) as one reviewable change, with both apps building
green — no supplier features yet, so the risky move is isolated and verifiable.
