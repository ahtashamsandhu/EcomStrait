# EcomStrait — Merchant & Supplier Credits and Settlement Plan

Status: **plan, not yet built.** Written 2026-08-29 against the current order
pipeline in `apps/merchant/src/lib/order-sink.ts` and the Supabase schema in
`supabase/migrations/`. Nothing described here exists in code yet — this is
greenfield. No Credit/Wallet/Ledger/Settlement/Payout table exists anywhere in
the repo today, and no fee/margin math is computed anywhere in the order path.

---

## 1. Decision — what we're building

Every order splits into exactly two payment paths, and the credits system's
only job is to guarantee EcomStrait and whichever party is owed money actually
get paid, regardless of which side (merchant or supplier) is holding the
customer's cash at any given moment.

**Prepaid order** (customer paid the merchant already, e.g. Shopify checkout):
the merchant is holding 100% of the sale. They owe the supplier's cost
(`products.wholesale_price`) and the EcomStrait fee. → **Deduct from the
merchant's credit balance.**

**COD order** (cash on delivery): the supplier is the one shipping and
packaging, so the supplier collects the cash directly from the customer at
delivery and keeps it — confirmed by Shehzad. The merchant never touches that
money, so EcomStrait instead deducts the merchant's margin and the EcomStrait
fee from the **supplier's** credit balance up front, at order time. This is
final — Shehzad confirmed there is no reversal once the supplier collects COD
cash; the upfront deduction is simply the cost of doing COD business. (See
§7 for the one case — a cancelled/undelivered COD order — where "final" needs
a second look.)

**Fee:** 0.05% for now, applied in both paths. Confirmed intentional, not a
typo for 5%. Treat it as a named constant (`ECOMSTRAIT_FEE_BPS = 5` i.e. 5
basis points), not a hardcoded literal, since it's explicitly "for the time."

**Insufficient credits:**
- Merchant short on a prepaid order → order holds in the merchant dashboard as
  **Unpaid / Low credits**, not sent to the supplier. Releases automatically
  the moment the merchant tops up enough to cover it.
- Supplier short on a COD order → order is **not** sent to the supplier;
  supplier gets a notification that orders are waiting and to add credits.
  Releases automatically once they top up.

**Settlement:** weekly. EcomStrait accumulates what it owes merchants (from
COD margin deductions) and what it owes suppliers (from prepaid cost
deductions) in a ledger, then pays out once every 7 days rather than per
order.

### Locked decisions (confirmed by Shehzad)

- Fee is 0.05%, applied both paths, treated as a placeholder constant.
- COD cash is the supplier's to keep; the upfront margin+fee deduction from
  supplier credits is **not** reversed later.
- Settlement cadence is weekly.
- Held-order behavior: merchant-side holds show `Unpaid / Low credits` in the
  merchant dashboard; supplier-side holds notify the supplier rather than
  showing a specific dashboard status (none was specified — see open
  decisions).
- **Naming: "wallet"/"balance", not "credits."** Confirmed. Avoids the
  collision with the existing unrelated "AI Credits" usage-quota concept
  (Doc 18 / Glossary, `usage_daily` + `ai_cost_ledger`). Tables:
  `merchant_wallets`, `supplier_wallets`, `wallet_transactions`. "Add
  credits" can still be the UI button label if that's the term merchants/
  suppliers expect to see.
- **Balance scope: per merchant, pooled across all their stores.**
  Confirmed. A merchant can own multiple `stores` (`stores.user_id`
  references `auth.users`); the wallet keys on that `user_id`, not on any
  single `store_id` — same grouping `subscriptions.user_id` already uses.
  Supplier side has no equivalent question: `suppliers` is already one row
  per owning user (`suppliers.owner_user_id unique`), so `supplier_wallets`
  keys on `supplier_id` directly.

### Newly discovered gaps (found while grounding Phase 1 against the real code)

Two things the original spec didn't anticipate, found by reading
`order-sink.ts` and the Shopify webhook route directly — both are
prerequisites for Phase 1, not later cleanup:

- **`orders` has no link back to the merchant at all.** The supplier-facing
  `orders` table (`supabase/migrations/20260722150000_orders.sql`) carries
  `store_name`, `store_owner_name`, `store_owner_email` — but
  `recordCustomerOrder` (`order-sink.ts:60-72`) populates
  `store_owner_name`/`store_owner_email` from `opts.customerName`/
  `opts.customerEmail`, i.e. the **end customer's** name/email, not the
  merchant's. There is no `store_id` (or any FK to `stores`) on `orders` at
  all, even though `opts.storeId` is sitting right there in the same
  function scope, three lines above where it's needed. Debiting the correct
  merchant's wallet requires knowing which store an `orders` row came from,
  so Phase 1 must add `orders.store_id` and thread `opts.storeId` into that
  insert. (The `store_owner_*` mislabeling is a pre-existing quirk unrelated
  to this feature — flagging it, not fixing it here.)
- **No prepaid/COD signal exists anywhere yet.** `recordCustomerOrder`
  has no `paymentType` parameter, and the Shopify webhook's `ShopifyOrder`
  type (`apps/merchant/src/app/api/shopify/webhooks/route.ts:8-14`) doesn't
  even parse `financial_status` or `payment_gateway_names` — the two fields
  Shopify actually uses to signal COD (a merchant-enabled "Cash on Delivery"
  payment method shows up in `payment_gateway_names`, and `financial_status`
  stays `pending` rather than `paid`). Own-platform Stripe-checkout orders
  (`storefront-orders.ts`) are inherently always prepaid — Stripe checkout
  doesn't have a COD mode — so `paymentType` is only ever ambiguous on the
  Shopify path. Phase 1 needs to extend the webhook parsing to derive
  `payment_type` from those two fields and pass it through to
  `recordCustomerOrder`.

### Open decisions (need your call)

1. **Fee base.** "0.05%" of what exactly — the order subtotal the customer
   paid, or something else? Default in this plan: 0.05% of the order's
   subtotal (`store_orders.subtotal` / the Shopify order total for that
   supplier's line items).
2. **COD cancellation/return.** Doc doesn't say what happens if a COD order
   is cancelled or the customer refuses delivery (`orders.status =
   'cancelled'` already exists as an enum value) — the supplier would have
   had margin+fee deducted for a sale that never actually completed, with no
   COD cash ever collected to cover it. Recommend: reverse the upfront
   deduction (credit the supplier back) when an order transitions to
   `cancelled` *before* `delivered`. Flag if intentional to leave suppliers
   eating that cost — it seems like an oversight to leave silent either way,
   so this plan builds the reversal but treats it as provisional pending your
   confirmation.
3. **Settlement payout mechanism.** "Settle the balance ledger" — by what
   rail? No Stripe Connect or payout integration exists today (only
   `subscriptions.stripe_customer_id` for merchant SaaS billing, which is a
   *charge* direction, not payout). Recommend starting with a **manual
   settlement MVP**: the weekly job freezes and totals each account's owed
   balance into a `settlement_batches` row that an admin reviews and pays out
   by bank transfer, then marks paid. Automating actual payouts (Stripe
   Connect or similar) is real infra work — propose as a later phase, not
   part of this MVP.
4. **Currency.** Every money column in the schema (`numeric(12,2)`) is
   currency-less — single-currency (USD) assumed throughout. Flag if
   multi-currency is a near-term need; it changes every table below.
5. **Top-up mechanism.** How do merchants/suppliers actually add credits —
   Stripe card charge, bank transfer reference, manual admin credit? This
   plan assumes a Stripe payment (reusing the Stripe integration already in
   `apps/merchant/src/lib/storefront-orders.ts`) for merchant top-ups, and
   leaves supplier top-ups as an open question since the supplier portal has
   no existing payment integration to reuse.

---

## 2. Data model (Supabase, new migrations)

All new tables `snake_case`, `id uuid default gen_random_uuid()`,
`created_at timestamptz default now()`, RLS scoped the same way existing
tables are (merchant reads/writes only rows where `user_id = auth.uid()`;
supplier only rows their `suppliers.owner_user_id` owns; service-role
bypasses for the webhook/cron paths).

- **`merchant_wallets`** — one row per merchant, pooled across stores.
  `user_id` (fk `auth.users(id)`, unique — same key as `subscriptions.user_id`
  and `stores.user_id`), `balance numeric(12,2) not null default 0`,
  `updated_at`.
- **`supplier_wallets`** — one row per supplier. `supplier_id` (fk
  `suppliers.id`, unique), `balance numeric(12,2) not null default 0`,
  `updated_at`.
- **`wallet_transactions`** — the ledger. Append-only. `account_type`
  (`merchant`|`supplier`), `account_id` (the `user_id` or `supplier_id`),
  `kind` (`topup`|`order_deduction`|`order_credit`|`reversal`|`settlement_payout`),
  `amount numeric(12,2)` (signed: positive credits the account, negative
  debits it), `balance_after numeric(12,2)`, `order_id` (fk `orders.id`,
  nullable — null for topups/payouts), `note text`, `created_at`. Every
  balance change must write one of these rows in the same transaction as the
  balance update — the ledger is the source of truth, `balance` on the
  wallet tables is a cached running total for fast reads.
- **New columns on `orders`** (the existing supplier-facing order table,
  `supabase/migrations/20260722150000_orders.sql`): **`store_id`** (fk
  `stores.id`, nullable — missing entirely today; see "Newly discovered
  gaps" above, this is what resolves an order to the merchant's
  `user_id` for wallet lookups), `payment_type` (`prepaid`|`cod`, not null),
  `cost_amount numeric(12,2)` (snapshot of `products.wholesale_price ×
  quantity` at order time — snapshotted because supplier pricing can change
  later and the ledger must reflect what was actually charged),
  `margin_amount numeric(12,2)` (snapshot of merchant's `store_products.price
  − products.wholesale_price`, summed per line), `platform_fee_amount
  numeric(12,2)`, `credit_status`
  (`deducted`|`awaiting_merchant_credits`|`awaiting_supplier_credits`|`reversed`,
  not null default `deducted`).
- **`payable_ledger`** — what EcomStrait owes each party, feeding weekly
  settlement. `account_type`, `account_id`, `order_id`, `amount
  numeric(12,2)` (what's owed *to* this account from this order — the
  supplier's cost on a prepaid order, or the merchant's margin on a COD
  order), `status` (`pending`|`settled`), `settlement_batch_id` (fk, nullable
  until settled), `created_at`.
- **`settlement_batches`** — one row per weekly run. `period_start`,
  `period_end`, `run_at`, `status` (`draft`|`paid`), `total_to_merchants
  numeric(12,2)`, `total_to_suppliers numeric(12,2)`, `paid_at`, `paid_by`
  (admin user id, manual MVP per open decision #3).

**Why cost/margin/fee get snapshotted onto `orders` rather than recomputed
later:** `products.wholesale_price` and `store_products.price` are both
independently mutable after an order ships (that's the whole point of
`cascadeSupplierPrice` in `product-propagation.ts`), so the ledger would
silently drift if it recalculated from current prices instead of what was
true at order time.

---

## 3. Flow logic

Both flows hook into `recordCustomerOrder`
(`apps/merchant/src/lib/order-sink.ts:19-105`), which already creates one
`orders` row per supplier per sale — the natural unit for a credit deduction,
since a single cart can span multiple suppliers and each supplier-order
settles independently.

### 3.1 Prepaid path

0. Resolve the merchant: `orders.store_id → stores.user_id` (both new/newly
   wired per "Newly discovered gaps" above) is the `merchant_wallets` account
   key — there is no shortcut via `store_owner_email`, since that column
   currently holds the *customer's* email, not the merchant's.
1. `recordCustomerOrder` computes, per supplier-order: `cost_amount` (sum of
   `wholesale_price × qty`), `platform_fee_amount` (0.05% of that
   supplier-order's subtotal, per open decision #1).
2. Atomically debit `merchant_wallets.balance` for
   `cost_amount + platform_fee_amount`, using a conditional update
   (`update merchant_wallets set balance = balance - :amt where user_id =
   :id and balance >= :amt`) so two concurrent orders can't both succeed
   against a balance that only covers one — see §7 for why this matters.
3. **If the debit succeeds:** write the `wallet_transactions` row, write a
   `payable_ledger` row crediting the supplier `cost_amount` (the fee is
   EcomStrait's revenue, not payable to anyone), set `orders.credit_status =
   'deducted'`, and proceed with order creation exactly as today.
4. **If the debit fails** (insufficient balance): still create the `orders`
   row (so the merchant sees the order exists) but with `credit_status =
   'awaiting_merchant_credits'`. The order does **not** get exposed to the
   supplier yet. Merchant dashboard surfaces it as **Unpaid / Low credits**.
5. **Release on top-up:** when a merchant's wallet top-up transaction posts,
   run a check across **all stores that merchant owns** (`stores.user_id`)
   for orders still `awaiting_merchant_credits`, oldest first, retrying the
   debit in step 2 for each until the balance runs out again — pooling means
   a top-up can release held orders from any of a merchant's stores, not just
   the one that triggered it. Successful ones flip to `deducted` and become
   visible to their supplier.

### 3.2 COD path

Same shape, mirrored onto the supplier's wallet:

1. Compute `margin_amount` (sum of `(store_products.price −
   wholesale_price) × qty`) and `platform_fee_amount` for the supplier-order.
2. Atomically debit `supplier_wallets.balance` for `margin_amount +
   platform_fee_amount`.
3. **Success:** `wallet_transactions` row, `payable_ledger` row crediting the
   **merchant** `margin_amount`, `orders.credit_status = 'deducted'`, order
   proceeds to the supplier as normal.
4. **Failure:** order stays at `credit_status = 'awaiting_supplier_credits'`,
   is **not** sent to the supplier's queue, and triggers a notification
   ("Orders waiting — add credits to receive them") rather than a dashboard
   status, per the spec.
5. **Release on top-up:** same retry sweep as 3.1.5, scoped to that
   supplier's held orders.

### 3.3 Held-order visibility

Both `awaiting_*` states need to actually surface somewhere a human acts on
them — a background deduction failure that just silently parks the order is
not enough:
- Merchant dashboard: an "Unpaid / Low credits" order list/filter (reuses the
  existing order list, filtered by `credit_status`).
- Supplier: the notification called for in the spec, plus — recommend adding
  even though not explicitly requested — a small "orders waiting on your
  balance" indicator in the supplier portal, since a notification alone is
  easy to miss and the order is otherwise invisible to them.

---

## 4. Weekly settlement job

A scheduled job (Vercel Cron calling a `apps/merchant` API route, e.g.
`/api/cron/settlement` — no existing cron infra was found in the repo, so
this is new) runs every 7 days:

1. Select all `payable_ledger` rows with `status = 'pending'`.
2. Group by `(account_type, account_id)`, sum `amount`.
3. Create one `settlement_batches` row for the run, with `total_to_merchants`
   / `total_to_suppliers` as the grand totals.
4. Mark every included `payable_ledger` row `status = 'settled'`,
   `settlement_batch_id = <this batch>`.
5. Per open decision #3 (MVP): stop here and surface the batch to an admin
   view for manual payout + a "mark paid" action, which stamps
   `settlement_batches.paid_at`/`paid_by`. Automated payout rails are a later
   phase.

This intentionally does **not** touch `wallet_transactions`/wallet balances —
settlement pays out the `payable_ledger` (money EcomStrait collected on
someone's behalf and now owes them), which is separate from the wallet
balance (money a merchant/supplier pre-funded to cover future deductions).
Conflating the two would mean a merchant's wallet top-up gets swept into a
payout meant for the supplier's cost recovery.

---

## 5. Reused from the existing codebase

- **`recordCustomerOrder`** (`apps/merchant/src/lib/order-sink.ts`) — the one
  hook point for both Shopify-webhook and own-platform Stripe-checkout
  orders; both flows above attach here rather than duplicating order-creation
  logic.
- **Entitlements pre-check pattern** (`apps/merchant/src/lib/entitlements.ts`,
  `assertTokenBudget` / `recordTokenUsage`) and its AI-ledger twin
  (`packages/ai/src/guardrails/cost.ts`, `assertCostBudget` /
  `recordUsage`) — same shape as what §3 needs (check-before-spend,
  discriminated-union result, then record), just swapped from a daily token
  counter to a money balance. Worth structuring `debitWallet()` as a direct
  sibling of `assertTokenBudget()` for consistency, though note the AI
  version **fails open** on DB error — wallet debits must fail **closed**
  (treat a DB error as insufficient balance, never let an order through
  un-debited).
- **`cascadeSupplierPrice`/`alertListingBelowCost`**
  (`apps/merchant/src/lib/product-propagation.ts:186-235`) — already the
  place margin gets computed against `wholesale_price`; the snapshot logic in
  §2 should live near this, not be reinvented.

---

## 6. Phases

1. **Schema + ledger primitives.** The migrations in §2, plus `debitWallet()`
   / `creditWallet()` / `getBalance()` helpers with the atomic
   conditional-update pattern from §3.1.2. No UI yet — testable directly
   against `recordCustomerOrder` in isolation.
2. **Prepaid flow end-to-end.** Wire §3.1 into `recordCustomerOrder`, add the
   merchant "Unpaid / Low credits" list, top-up flow (Stripe — open decision
   #5), and the release-on-topup sweep.
3. **COD flow end-to-end.** Wire §3.2, supplier notification, supplier
   top-up flow, release sweep. Needs open decision #5 resolved for suppliers
   specifically since there's no existing supplier payment integration to
   reuse.
4. **Weekly settlement (manual MVP).** §4's cron job + an admin view listing
   batches and a "mark paid" action.
5. **COD cancellation reversal** (open decision #2, if confirmed) —
   straightforward once §2/§3 exist: a reversal is just another
   `wallet_transactions`/`payable_ledger` pair keyed off the same `order_id`.
6. **(Later, out of scope for this plan)** Automated payout rails (Stripe
   Connect or equivalent) replacing the manual "mark paid" step.

---

## 7. Risks & mitigations

- **Concurrent-order race on a thin balance.** Two orders landing at once
  against a balance that covers only one must not both succeed. Mitigated by
  the conditional atomic update in §3.1.2 (`where balance >= amount`), not a
  read-then-write from application code.
- **Ledger/balance drift.** `wallet_transactions` is append-only and
  authoritative; `merchant_wallets.balance`/`supplier_wallets.balance` are
  caches. Any discrepancy should be resolved by resumming the ledger, and a
  periodic reconciliation check (recompute balance from
  `wallet_transactions`, compare to the cached value) is worth adding once
  this is live, not deferred indefinitely.
- **COD orders that never deliver** (open decision #2) — without a reversal
  rule, suppliers are charged margin+fee for sales that didn't happen. Real
  risk of supplier trust/complaints if left unresolved; this plan recommends
  building the reversal but it needs your confirmation before Phase 5.
- **Fee-base ambiguity** (open decision #1) — if 0.05% is meant to apply to
  something other than subtotal (e.g. only to the margin, or only to the
  cost), every fee number in the ledger is wrong until this is confirmed.
  Cheap to fix now, expensive to fix after real balances have compounded on
  the wrong base.
- **Manual settlement doesn't scale indefinitely** — fine at current/beta
  order volume, but flag now rather than after volume grows that Phase 4's
  admin-marks-it-paid step will need to become an automated payout rail
  eventually (Phase 6).

---

## 8. Needed from Shehzad

Naming and balance scope are resolved (see Locked decisions in §1).
Consolidated from §1's remaining open decisions — answer these before or
during Phase 1:

1. Confirm 0.05% fee applies to order subtotal (this plan's default).
2. Should a cancelled/undelivered COD order reverse the supplier's upfront
   margin+fee deduction?
3. Manual admin-run settlement for now, or is an automated payout rail (Stripe
   Connect or similar) needed from day one?
4. Single currency (USD) acceptable for now?
5. How do merchants top up (Stripe assumed)? How do suppliers top up (no
   existing payment integration in the supplier portal to reuse)?
