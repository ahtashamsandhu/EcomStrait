# Merchant App — Feature Summary (Non-AI)

Short summary of every merchant-facing feature and how it's built — deliberately **not**
exhaustive detail. AI-powered features (Store Builder's chat, Co-Founder, SEO Advisor, AI
product suggestions, AI blog drafting) are covered separately in
`Docs/ECOMAI Team members and their Abilities.md`; only the plain, non-AI mechanics are here.

---

## 1. Auth & Onboarding

- **Signup/Login** — email + password (Supabase Auth) or Google OAuth. Signup fields: full name,
  email, password. No email-confirmed session → `/verify-email` (static "check your inbox" page).
- **No onboarding wizard** — a merchant lands straight on `/dashboard` after signup; there's a
  "Build your first store" CTA, but no multi-step setup flow.
- **Route protection** — `src/proxy.ts` (Next middleware) gates a fixed list of dashboard routes
  behind login, and separately rewrites requests on a merchant's *connected custom domain* to the
  public storefront instead of the dashboard.

## 2. Find Suppliers (Catalog Browsing)

- Search box matches **`products.title` only** (not description/category).
- Filters: **supplier** (exact match) and **category** (exact match) — no price range, no sort
  option (always newest-first). 24 results/page.
- Only `published` products from approved suppliers are shown.
- **Selecting a product**: if the merchant has ≥1 real store, an "Add to store" menu lets them
  pick which existing store to list on, or "Start a new store" (queues it in a pre-launch basket).
  With zero stores, a plain Add button always queues it in that basket.

## 3. Listing Request Lifecycle

- Adding a product to a store creates a `store_products` row with **status `pending`** — nothing
  goes live until the supplier approves it (`approved`) or declines it (`declined`, with a reason).
- Merchant can set their own price per store, enforced against the supplier's **MAP (minimum
  advertised price)** — both client-side and by a DB trigger as the real guarantee.
- Merchant can add a one-line shipping/returns note, per store.
- Removing a listing that was already pushed to Shopify deletes the Shopify product first, then
  the local row.

## 4. Stores Management

- **Store types**: EcomStrait-hosted (`own_platform`) or Shopify (with our own theme, or the
  merchant's own Shopify theme).
- **Lifecycle**: draft → building → ready for review → live → archived.
- Rename anytime; delete requires typing the store's exact name to confirm — a store with any
  real orders is **archived** instead of deleted, to preserve order history.
- **Custom domain**: connect a domain, verify via live DNS lookup, auto-attach for SSL.
- **Theme**: 6 built Liquid themes exist (Aurora, Noir, Bloom, Cove, Forge, Marble); only Noir is
  currently offered (single-theme beta) — the gallery page is disabled.

## 5. Store Builder — non-AI mechanics

- **Autosave**: every change to the in-progress plan/products debounces ~1.2s then saves to the
  draft store row. Unlaunched drafts expire after 3 days (with their uploaded media cleaned up).
- **Launch**: promotes the draft to a real store and creates a `pending` `store_products` row per
  picked product (same approval queue as §3).
- **Version history**: every content edit snapshots the prior state first; up to 20 versions kept
  per store, restorable anytime (a restore is itself undoable).
- **Content Editor**: manual editing of the store's copy, brand colors, and a `sections` list
  (text/image/video/gallery/features/a curated "products" picker) — the same data the AI writes,
  editable by hand too.
- **Media upload**: images (≤8MB) and video (≤64MB), stored on Cloudflare R2 (or Supabase Storage
  as fallback).
- **Blog (manual)**: create/edit/publish/delete blog posts by hand — title, slug, excerpt, body,
  cover image, SEO fields. (AI drafting is a separate, AI-covered capability.)
- Custom pages themselves can only be created/edited through the AI chat — no manual page-builder
  form exists.

## 6. Orders

- Shows every `store_orders` row across the merchant's stores: customer, items, total, **payment
  status** (effectively always "Paid" today), and a separate **fulfilment status** (Processing /
  Shipped / Delivered / Cancelled) pulled from the linked supplier order(s).
- Orders on hold because the merchant's wallet couldn't cover the supplier's cost are flagged in
  red with a link to top up the wallet.

## 7. Sales / Analytics

- Plain JS aggregation (no AI) over paid/processing/fulfilled orders: total revenue, order count,
  average order value, units sold, revenue by store, top products by units sold, and a 14-day
  revenue bar chart.

## 8. Wallet

- Covers what the merchant owes suppliers (cost + platform fee) on prepaid orders.
- Top up via Stripe Checkout; balance changes always go through one atomic ledger function
  (never a direct table write), so a balance can never be double-debited by a race.
- An order that couldn't be covered at the time is held (`awaiting_merchant_credits`) and
  automatically released, oldest-first, the moment a top-up covers it.

## 9. Billing / Entitlements

- 4 plans (Free/Basic/Premium/Full) gate two things: **daily AI token budget** and **how many
  launched stores** a merchant can have (drafts don't count toward the limit).
- Upgrade/manage via Stripe Checkout + the Stripe customer portal; plan state is refreshed live
  from Stripe on every Billing page load, not dependent on a webhook to stay correct.

## 10. Settings

- Minimal: read-only account info (email/name), plus one card per store for renaming and domain
  connection. No password-change or notification-preferences UI in this app.

## 11. Shopify Integration

- Not per-merchant OAuth — stores draw from a **pool of pre-provisioned Shopify dev stores**;
  launching a Shopify store claims one, pushes approved products to it, and (for our-theme stores)
  uploads/publishes one of the 6 Liquid theme packages.
- An `orders/create` webhook (HMAC-verified) is the only Shopify webhook handled — it records the
  sale the same way an own-platform Stripe checkout does.
- A small embedded mini-app inside Shopify admin offers the same catalog-browsing/listing-request
  flow as Find Suppliers, from inside Shopify itself.

## 12. Other Pages

- **Dashboard** — plan/usage meters + "Build your first store" CTA.
- **Gallery** — disabled during the single-theme beta (redirects to Builder).
- Cron-triggered background jobs: expired-draft cleanup, weekly supplier/merchant settlement.
- A small internal API surface (media library, theme file serving, storefront product/cart/
  checkout endpoints) backs the pages above — not separate user-facing features.

## 13. Public Storefront

- `/store/[id]` (EcomStrait URL) or a connected custom domain renders the actual live shop: home,
  product listing/detail, blog, and a Stripe-backed checkout — for `own_platform` stores only.
  Shopify-path stores are served by Shopify itself. Only "ready for review" or "live" stores are
  ever publicly reachable; drafts and archived stores 404.
