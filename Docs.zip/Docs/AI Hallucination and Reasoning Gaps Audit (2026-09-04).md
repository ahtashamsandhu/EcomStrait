# AI Hallucination & Reasoning Gaps — Static Prompt Audit

**Date:** 2026-09-04
**Method:** Pure static review of every AI system prompt/tool description in the monorepo — no live LLM queries, no code changes. Six parallel reviews, one per AI surface, calibrated against real bugs already found and fixed earlier this session (ambiguous-delegation guessing, tool-description overlap causing misrouting, brittle regex backstops, the `workhorse`/`reasoning` role empty-content bug).

**Scope:** merchant app (Website Builder, Store Plan, Blog, Co-Founder orchestrator), supplier app (Co-Founder), shared `packages/ai` agents (Business Advisor, Analytics, Restock, routing orchestrator), public website (Ask EcomAI, Business Simulator), chat-memory summarization (shared by merchant + supplier), and `apps/ecom-strait-ai` (confirmed non-AI — a Shopify embedded app, no LLM calls).

**Total findings: 46**, across two failure classes:
- **Hallucination risk** — the prompt lets/encourages inventing facts, numbers, or capabilities with no real grounding.
- **Brittle/"dumb" behavior** — loose classification with no calibrating examples, regex backstops that miss natural phrasing, or malformed-output handling that silently does the wrong thing instead of failing visibly.

Nothing below has been fixed yet — this is the assessment. See the priority recommendation at the end.

---

## Cross-cutting themes (the same root cause shows up on multiple surfaces)

### Theme 1 — Self-contradictory "never invent" vs. "never mention what's missing" rules
**Where:** Merchant Co-Founder (`cofounder-orchestrator.ts`), Supplier Co-Founder (`cofounder-ai.ts`) — nearly word-for-word the same two rules in both files.
Both prompts say, in effect: (a) "never invent a number — say plainly you don't have that yet," and (b) "NEVER talk about what data/tracking the business doesn't have, not even in passing — don't narrate the gap." When a merchant/supplier asks about something genuinely absent from the snapshot (a specific order, a customer name, a returns figure), these two rules give the model **no compliant answer** — satisfying one means violating the other. The likely resolution, given an LLM under conflicting constraints, is fabricating a plausible-sounding answer rather than breaking either rule visibly.
**Severity: HIGH. Fix once, benefits both apps** — add an explicit precedence rule (accuracy > tone) and/or a stated exception: "zero is a real fact you can state plainly; a value that's genuinely unknown is what rule (a) is about."

### Theme 2 — Chat-memory summarization has no anti-invention guardrail, and its output is trusted like verified data
**Where:** `packages/ai/src/memory/chat-threads.ts` (shared by merchant + supplier), and every consumer that injects `thread.summary` into a system prompt.
Three compounding gaps: (1) the summarization prompt has no "only state what was actually said, preserve hedges" instruction — a hedged statement ("I might sell shoes") can compress into an asserted fact ("sells shoes"); (2) the summary's own output is validated only for non-emptiness (`content.trim() || previous`) — a garbled or off-task response passes straight through and gets persisted as "ground truth"; (3) once injected, no prompt anywhere distinguishes "this is my own recollection, could be imprecise" from real DB-measured numbers, and — worse — the Builder chat (`applyMerchantRequest`) has **no raw message history at all**, only the summary, so a bad summary has zero redundancy to be caught against.
**Severity: HIGH. This is the single highest-leverage fix in the whole audit** — one file, benefits every chat surface in both apps immediately.

### Theme 3 — The `workhorse`/`reasoning` role empty-content bug is inconsistently mitigated
**Where:** `packages/ai/src/agents/business-advisor.ts` (uses `reasoning` role, zero mitigation — no `maxTokens`/`timeoutMs`/retry, despite the orchestrator's own code comment documenting this exact agent hitting the bug in testing), `analytics-agent.ts` (uses `workhorse` with `reasoningEffort: "none"` but still no `maxTokens`/`timeoutMs`/retry). Contrast with `converseBuilder` and `restock-agent.ts`, which already carry the full fix (generous `maxTokens`, explicit timeout, `reasoningEffort` omitted/tuned).
**Severity: HIGH but mechanical** — this is copy the same three-line fix pattern to two more call sites, not a design problem.

### Theme 4 — Structured AI output is validated by exclusion/coercion, not an allowlist — malformed output silently becomes a different, wrong, undetected action
**Where:** three separate spots in `apps/merchant/src/lib/ecomai.ts`/`builder-actions.ts`:
- A page `action` field defaults to `"create"` for any unrecognized value. A model drift from `"delete"` to a synonym like `"remove"` causes the code to *update* the page with an empty title/body instead of deleting it — **silently wiping a real page's content** while reporting success.
- `applyMerchantRequest`'s `intent` field defaults unrecognized values to `"edit"` — a genuine question ("how do discount codes work?") can get silently reinterpreted as an edit request with a confusing non-answer.
- `converseBuilderOnce`'s `type` is checked by exclusion (`!== "show_products" && !== "other"` ⇒ treated as `"answer"`) rather than `=== "answer"` — a case/spelling drift in the model's output is silently accepted as a valid completed answer.
**Severity: HIGH for the page-deletion one specifically (real data loss), MEDIUM for the other two.** This is a pure code fix (validate against a closed enum, treat anything else as its own explicit failure case) — no prompt engineering needed, low risk, quick to do.

### Theme 5 — SQL/data-backed agents have no "the query came back empty/wrong" escape hatch
**Where:** `analytics-agent.ts` has no instruction for a 0-row result or a tool-returned `Error:` string — it's told to "explain the result with real numbers" unconditionally, so it can present a failed query as "$0 in sales" (false) rather than "the query didn't return an answer." The shared `supabase-query-tool.ts` gives both SQL-driven agents only table names, no columns/joins/tenant-scoping guidance, raising the odds of a wrong-but-plausible-looking query in the first place.
**Severity: HIGH.** `business-advisor.ts` already has the right instruction ("if a tool returns nothing relevant, say so") — this is porting an existing good pattern to `analytics-agent.ts`, plus enriching the shared tool description.

### Theme 6 — This session's "ask, don't guess" fix needs to be extended, not just applied to the one case tested
Three follow-on gaps to the ambiguous-delegation fix made earlier today:
- The explicit "don't literally store the delegation phrase" carve-out exists for `niche` and `storeName` but not for `audience`/`styleKeyword` — a clear "you decide" answer to "who's your audience?" has no rule stopping the model from writing `audience: "you decide"` literally, which then flows into the real store-plan prompt as if it were factual audience data.
- The deterministic regex safety-net for niche delegation (`DELEGATE_PATTERN`) only fires on the conversation's first user message (`history.length <= 1`) — per the prompt's own stated intent, delegation can happen "at ANY point in the conversation," so the backstop's coverage is narrower than the rule it exists to reinforce.
- The no-gateway fallback script's "is this a skip?" check (`isSkippedAnswer`) is a narrow anchored regex — "not sure," "I don't know," "doesn't matter" all fail to match it, so a merchant using any of those in a genuine gateway outage gets that literal text saved as the real store name.
**Severity: HIGH-MEDIUM.** All three are small, mechanical, and directly continue the fix already made this session.

### Theme 7 — The public website is the highest real-world-consequence surface, and has no guardrails equivalent to the internal apps
**Where:** `apps/website` (the "Ask EcomAI" FAQ chatbot and the "Business Simulator" that generates a fake business plan for anonymous visitors). This is qualitatively different from the internal merchant/supplier issues because there's no logged-in user, no human review, and the output is presented as the product's own value proposition:
- Numeric fields (margin %, revenue $/mo) from the model are accepted with **no bound-checking** against the real reference data they're supposed to be grounded in.
- Worse: a fabricated plan gets **cached in a single process-wide `Map` and served to every other visitor** who types a similar idea (including the exact example chips the UI itself suggests) for up to 10 minutes.
- No defined fallback for factual questions outside the tiny FAQ (refunds, guarantees, data/legal terms) — the model is told not to invent but given nothing to say instead, for questions a real prospective customer will actually ask.
- A "verified supplier ★ rating" badge is pure arithmetic with no relation to any real review system, displayed with a shield icon as if authentic.
- User free text is spliced into the prompt with no delimiting (a mild prompt-injection surface, compounded by the shared cache above).
**Severity: HIGH — this is the one theme I'd prioritize on business/legal risk grounds alone**, independent of the internal-tool polish issues elsewhere.

### Theme 8 — Confident recommendations built on thin/synthetic data
- `restock-agent.ts` computes a restock **quantity** from only three numbers (current stock, threshold, units just sold) with no sales-velocity or lead-time signal — the number is a guess wrapped in confident-sounding "reasoning" text, gated behind human approval but still the thing an approver reads to decide whether to trust it.
- The merchant Co-Founder's SEO commentary is driven by a single crude heuristic (about-text character count `< 80`) but delivered with the prompt's "no hedging, confident co-founder" tone as if it were a full audit.
- The Co-Founder snapshot has no explicit exception letting the model state "we're allowed to reason confidently from estimated data" separately from "we must disclose when asked about accuracy" — direct point-blank questions about whether traffic/customer data is real vs. estimated may get deflected past the letter of the rule.
**Severity: MEDIUM.**

---

## Full findings by surface (all 46, for reference)

Each numbered item below is one finding from its respective audit; severity and fix direction were assessed by the reviewing agent. Line numbers refer to file state as of 2026-09-04.

### Merchant — Website Builder / Store Plan / Blog (`apps/merchant/src/lib/ecomai.ts`, `builder-actions.ts`, `category-content.ts`)
1. **[HIGH]** `category-content.ts` category-page copy has no anti-invention guardrail and is cached forever, never human-reviewed before a customer reads it.
2. **[HIGH]** `BLOG_SYSTEM` is told to be "specific"/"concrete" from only a topic + store name, no real facts — can invent certifications, policies, materials. No equivalent to `MERCHANT_SYSTEM`'s existing "never invent a policy/claim" guardrail.
3. **[HIGH]** Page `action` field defaults to `"create"`/silently becomes an update-with-blank-content for any unrecognized value — can wipe a real page while reporting success. *(Theme 4)*
4. **[HIGH]** `isSkippedAnswer` regex too narrow — junk/hedge text ("not sure," "doesn't matter") becomes the literal store name in the no-gateway fallback path. *(Theme 6)*
5. **[HIGH]** Niche-delegation regex backstop (`DELEGATE_PATTERN`) only checked on the conversation's first user message, narrower than the rule's own stated "any point in the conversation." *(Theme 6)*
6. **[MEDIUM]** `converseBuilderOnce`'s `type` field validated by exclusion, not allowlist — malformed output can be silently treated as a completed answer. *(Theme 4)*
7. **[MEDIUM]** The "don't literally store the delegation phrase" carve-out exists for niche/storeName but not audience/styleKeyword. *(Theme 6)*
8. **[MEDIUM]** `applyMerchantRequest`'s `intent` field defaults unrecognized values to `"edit"`, turning a genuine question into a confusing non-answer. *(Theme 4)*

### Merchant — Co-Founder Orchestrator (`cofounder-orchestrator.ts`, `cofounder-tools.ts`, `cofounder-snapshot.ts`)
1. **[HIGH]** Self-contradictory rules on zero/absent data (customers/traffic silently omitted from the snapshot with no zero-value fallback, unlike `seoIssues`). *(Theme 1)*
2. **[HIGH]** Directive to withhold "this is an estimate" even under fairly direct questioning about data provenance (only triggers on "the exact raw number," not "is this real or an estimate?").
3. **[HIGH/MEDIUM]** The "one short final reply" brevity rule has no stated exception for a tool's own mandatory disclosure (e.g. `suggest_products`' "say plainly this is a fallback, not a match") — could get trimmed away to stay terse.
4. **[MEDIUM/HIGH]** "Never gate advice on missing infrastructure" pressures the model into confidently citing synthetic/estimated traffic data as the *reason* for a specific tactical recommendation.
5. **[MEDIUM]** No explicit guard against inventing/reusing a stale `storeId` when `list_my_stores` found nothing — currently caught only downstream by the DB ownership check, not by the prompt.
6. **[MEDIUM]** 12-turn history window has no sticky "which store is 'it'" memory — a long conversation can lose track of which store was resolved earlier and re-guess.
7. **[MEDIUM/LOW]** Crude length-based SEO heuristic (`about.length < 80`) delivered with full unhedged confidence as if it were a real audit finding. *(Theme 8)*
8. **[LOW/MEDIUM]** Fuzzy, example-free boundary between "ask_business_advisor" (one store) and "the snapshot already covers" (portfolio-wide) — a comparison question across stores has no clear rule for which path to take.

### Shared `packages/ai` agents (Business Advisor, Analytics, Restock, routing orchestrator)
1. **[HIGH]** `analytics-agent.ts` has no escape hatch for a 0-row or errored SQL result — told to "explain the result with real numbers" unconditionally. *(Theme 5)*
2. **[HIGH]** `restock-agent.ts` invents a restock quantity from only 3 numbers, no velocity/lead-time data, wrapped in confident "reasoning" text. *(Theme 8)*
3. **[HIGH]** `business-advisor.ts` uses the `reasoning` role in a multi-turn tool-calling loop with zero mitigation for the documented empty-content bug — no retry, no generous `maxTokens`/timeout. *(Theme 3)*
4. **[MEDIUM]** The analytics-vs-advisor routing classifier has no few-shot calibrating examples and a silent binary default on any non-matching output.
5. **[MEDIUM]** `analytics-agent.ts`'s `workhorse` call is partially mitigated (`reasoningEffort: "none"` set) but still lacks `maxTokens`/timeout/retry. *(Theme 3)*
6. **[MEDIUM]** `business-advisor.ts`'s persona + temperature 0.4 + no similarity floor on KB retrieval can blend a weak/irrelevant KB match with invented specifics in one confident paragraph.
7. **[MEDIUM]** Shared `supabase-query-tool.ts` gives only table names, no columns/joins/tenant-scoping column — raises the odds of a wrong-but-plausible query. *(Theme 5)*
8. **[LOW]** The orchestrator's fallback message is the only mitigation for the empty-content bug — no retry attempted first.

### Supplier app (`apps/supplier/src/lib/cofounder-ai.ts`, `ai.ts`)
1. **[HIGH]** Same self-contradictory missing-data rules as merchant Co-Founder. *(Theme 1)*
2. **[HIGH]** Prompt demands a "specific, named" recommendation (a product, an order) but the snapshot only ever has aggregate counts, no identifiers — the data pipeline itself would need to change, not just the prompt.
3. **[MEDIUM-HIGH]** No tool/grounding fallback at all when the snapshot runs out — supplier Co-Founder has nothing equivalent to merchant's `ask_business_advisor` escape valve, so the contradiction in #1 has no way out.
4. **[MEDIUM]** "Point to the closest real thing you can help with" has no grounding on the app's actual real features/navigation — can invent a plausible-but-wrong UI path.
5. **[MEDIUM]** Same summarization-trusted-as-fact issue as Theme 2 — supplier Co-Founder's prompt doesn't hedge summary-derived claims differently from real snapshot numbers.
6. **[LOW]** AI-suggested retail price from minimal input (title only) — appears mitigated by requiring supplier review before save, worth confirming in the UI.
7. **[LOW]** No few-shot calibrating examples anywhere in the prompt, same class as the fixed ambiguous-reply bug but without a concrete trigger identified.
8. **[LOW]** Token-budget precheck (700) doesn't match the role's actual ceiling (4000) — informational, not a correctness bug.

**Note (positive finding):** the supplier Co-Founder already correctly carries over the "don't push unsolicited recommendations using platform data" fix and the reasoning-role `maxTokens`/timeout mitigation from the merchant app — it did NOT independently regress on those two.

### Public website (`apps/website/src/lib/ask.ts`, `ecomai.ts`)
1. **[HIGH]** Numeric business-plan fields (margin %, revenue) accepted with no bound-checking against the real reference ranges they're meant to be grounded in. *(Theme 7)*
2. **[HIGH]** A hallucinated plan gets cached in a single process-wide `Map` and served to every other visitor with a similar input for up to 10 minutes. *(Theme 7)*
3. **[HIGH]** No defined fallback for real prospective-customer questions outside the 8-item FAQ (refunds, guarantees, data/legal terms) — told not to invent, given nothing to say instead. *(Theme 7)*
4. **[MEDIUM-HIGH]** `BRAND_FACTS` states "run marketing" as flat present-tense fact, inviting the model to improvise mechanism/pricing specifics if asked.
5. **[MEDIUM]** "★ Verified supplier" rating badge is pure arithmetic with no real backing, displayed as if authentic. *(Theme 7)*
6. **[MEDIUM]** Visitor free text spliced into the prompt with no delimiting — mild prompt-injection surface, compounded by finding #2's shared cache.
7. **[LOW-MEDIUM]** "Off-topic" handling is a vague "gently steer back," not an enumerated refuse-list (legal/medical/tax/competitor claims).
8. **[LOW-MEDIUM]** The tiny "simulated preview" disclaimer (10px, low contrast) is dwarfed by the confident chart/stat-tile UI built on the same unvalidated numbers.

### Chat-memory summarization (`packages/ai/src/memory/chat-threads.ts`, shared by merchant + supplier)
1. **[HIGH]** Summarization prompt has no "only state what was actually said, preserve hedges" instruction. *(Theme 2)*
2. **[HIGH]** Summary output validated only for non-emptiness — a garbled/off-task response is persisted as ground truth. *(Theme 2)*
3. **[HIGH]** Builder chat (`applyMerchantRequest`) receives ONLY the summary, no raw history at all — zero redundancy to catch a bad summary. *(Theme 2)*
4. **[MEDIUM]** Co-Founder's "never invent... stay confident" instruction doesn't distinguish digest-embedded summary claims (unverified) from real snapshot numbers (measured) — amplifies any hallucination already in the summary.
5. **[MEDIUM]** No precedence rule when the summary and the actual recent raw messages disagree.
6. **[LOW-MEDIUM]** Summary-of-summary compounding drift over many refresh cycles on a long-lived thread, with no periodic re-grounding against a fuller transcript.

**`apps/ecom-strait-ai`:** confirmed non-AI (a Shopify embedded OAuth/webhook app forked from Shopify's official template) — no findings, not in scope.

---

## Recommended priority order for fixing

1. **Theme 2 (chat-memory summarization)** — one shared file, benefits every chat surface in both apps immediately, currently the least-guarded link in the whole chain.
2. **Theme 7 (public website)** — highest real-world consequence (anonymous visitors, no human review, cached fabrications served at scale, refund/legal question gap).
3. **Theme 4 (malformed-output validation)** — cheap, mechanical, no prompt-engineering judgment calls, and one of them (page-action defaulting) causes real data loss today.
4. **Theme 6 (extend this session's ask-don't-guess fix)** — small, direct continuation of already-approved work.
5. **Theme 1 (contradictory missing-data rules) + Theme 5 (SQL escape hatch) + Theme 3 (role-bug mitigation)** — same fix pattern, several call sites each.
6. Everything else (Theme 8, and the remaining LOW/MEDIUM items) — worth doing but lower urgency.
