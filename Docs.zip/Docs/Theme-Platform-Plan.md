# Theme Platform Plan — Premium, Responsive, Page-Aware Themes

Status: **plan, not yet built.** Written 2026-08-03 against the six Liquid themes
in `apps/merchant/themes/` and the custom-website storefront in
`apps/merchant/src/components/storefront/`.

The goal this plan serves: **six themes, each suited to a different product
niche, that come out feeling like a premium store — fully responsive,
performance-optimised, and with pages the merchant can add and remove through
the EcomAI builder.**

---

# Part 1 — Where the themes actually stand today

Everything in this section is measured from the current files, not estimated.

## 1.1 Pages per theme

Every theme ships **8 templates**, identical across all six:

| Template | Covers |
| --- | --- |
| `index.liquid` | Home |
| `collection.liquid` | A collection listing |
| `list-collections.liquid` | All collections |
| `product.liquid` | Product detail |
| `cart.liquid` | Cart |
| `search.liquid` | Search results |
| `page.liquid` | Any Shopify page (About, Contact, policies) |
| `404.liquid` | Not found |

**Templates that do not exist in any theme:**

- `blog.liquid` and `article.liquid` — a merchant who publishes a blog post has
  nowhere for it to render.
- `customers/login.liquid`, `register`, `account`, `order`, `addresses`,
  `reset_password`, `activate_account` — if customer accounts are switched on,
  every account journey is unstyled or broken.
- `password.liquid` (and `layout/password.liquid`) — the page shown while a
  store is password-protected. Our provisioning pool uses password-protected
  dev stores, so this is the **first page** anyone sees on an unlaunched store.
- `gift_card.liquid` — gift card rendering.
- `templates/*.json` — none of the themes use Shopify's JSON template format
  (see 1.5, this is the root cause of the page-editing limitation).

So: **8 pages present, roughly 12 standard Shopify pages absent.**

## 1.2 Responsiveness — partial, not "fully responsive"

- `meta viewport` is present in all six layouts. ✅
- Media-query count per theme: aurora 7, noir 8, bloom 8, cove 8, forge 9,
  marble 9. Layouts do reflow, and grids collapse on small screens. ✅
- **No `srcset` or `sizes` anywhere across all six themes** (0 occurrences).
  Every image is served at one fixed width regardless of device.

That last point is the real problem. Fixed widths currently requested:

| Location | Width requested |
| --- | --- |
| `sections/hero.liquid` | 2000px |
| `sections/main-product.liquid` | 1200px |
| `snippets/product-card.liquid` | 600px |
| `templates/list-collections.liquid` | 600px |
| `sections/header.liquid` (logo) | 480px |
| `templates/cart.liquid` | 120px |

A phone on a mobile connection downloads the **2000px hero** and a grid of
600px thumbnails. The layout adapts; the payload does not. This is the single
biggest Lighthouse cost in the themes today.

## 1.3 Optimisation — good foundations, three real gaps

Genuinely good already:

- **Zero JavaScript.** No framework, no jQuery, no bundle. Nothing to parse or
  hydrate — an excellent starting point that most Shopify themes can't claim.
- **Small CSS**, inlined variables: 7.5KB (aurora) to 11.8KB (marble),
  unminified.
- `loading="lazy"` used on below-fold images; `loading="eager"` on the product
  hero image.
- Fonts loaded through Shopify's `font_face` with `font_display: swap`.
- Explicit `width`/`height` on images (Theme Check's `ImgWidthAndHeight` passes
  on all six), so no cumulative layout shift.

The gaps:

1. **No responsive images** — as above.
2. **Product pages show only one image.** `main-product.liquid` renders
   `product.featured_image` and nothing else; there is no loop over
   `product.media` in any theme (0 occurrences). We now sync multiple product
   images into Shopify via `backfillProductMedia` — **and none of the extra
   images are ever displayed.** For a premium feel this is the most visible
   miss.
3. **No AJAX cart.** `cart.liquid` is a plain `<form method="post">`. Every
   quantity change is a full page reload, and there is no cart drawer. Add-to-
   cart from a collection page isn't possible at all.

## 1.4 A latent variant bug worth recording now

`main-product.liquid` renders `options[...]` selects **and** a hidden
`id` field set to `product.selected_or_first_available_variant.id`. When both
are posted, Shopify's `/cart/add` honours `id` — so a customer's variant
selection would be silently ignored and they'd always receive the first
variant.

This is **not reachable yet**: every product we create through
`pushProductsToShopify` has a single default variant, so
`has_only_default_variant` is true and the selector never renders.

**Supplier variants are confirmed in scope (decision 3), so this is now a
scheduled bug, not a hypothetical one.** It has been pulled forward into
Phase 1 — the fix is small and independent of the cart work, and it must land
before variants ship or customers receive the wrong size.

## 1.5 Can EcomAI add or remove pages today? No.

Current capability, precisely:

- **Content within fixed pages: yes.** The builder's content editor writes
  `announcement`, `heroMedia`, `about`, `aboutMedia`, `footerText` and an
  ordered `sections[]` array into `stores.content`.
- **Custom sections on the home page: yes, one page only.**
  `lib/theme-content.ts` renders those sections to markup and writes them into
  `sections/custom-content.liquid` per store at upload time.
- **Adding, removing or reordering *pages*: no.** The set of templates is fixed
  in the theme package. Nothing in the builder creates a template, a Shopify
  Page object, or a navigation entry.

**Why it's blocked architecturally:** the themes use `.liquid` templates with
hardcoded `{% section %}` lists. Shopify's page-composition model — the one that
lets sections be added, reordered and configured per page — requires **JSON
templates** (`templates/index.json`) plus **Online Store 2.0 section groups**.
Until the themes convert to JSON templates, per-page composition can only ever
be faked by regenerating markup, which is what `custom-content.liquid` does for
the home page.

---

# Part 2 — What "premium" requires

Measured against the goal, four things separate the current themes from a
storefront that reads as a premium brand:

1. **Imagery that does the selling.** Multi-image galleries, responsive
   delivery, tasteful hover states. Currently one fixed-width image per product.
2. **Interaction that feels instant.** Cart drawer, quantity updates without
   reload, variant switching, sticky add-to-cart on mobile. Currently full page
   reloads.
3. **Pages a brand actually needs.** About, Contact, FAQ, Shipping & Returns,
   Size Guide, Blog. Currently one generic `page.liquid` and no way to create
   the pages themselves.
4. **Six genuinely distinct identities.** The tokens differ well already
   (`lib/theme-tokens.ts`), but the *layouts* are near-identical across the six
   — same hero, same grid, same value props. Niche fit needs structural
   difference, not just palette difference.

---

# Part 3 — The plan

Five phases, ordered so each one ships something usable on its own. Phases 1–3
are the quality bar; phases 4–5 are the builder capability.

## Phase 1 — Performance and imagery (highest value, lowest risk)

Scope, applied to all six themes:

- **Responsive images.** Add a `snippets/responsive-image.liquid` that emits
  `srcset` at 400/600/800/1200/1600/2000 with correct `sizes` per context.
  Replace every `image_url` call site (6 per theme, 36 total).
- **Product media gallery.** Loop `product.media` in `main-product.liquid`:
  main image plus thumbnails, with a CSS-only or minimal-JS switcher.
- **Preload the hero image**, and stop lazy-loading anything above the fold.
- **Minify `theme.css` at bundle time** in `scripts/bundle-themes.mjs`, so the
  source stays readable and the shipped asset is small.
- **Variant correctness (see 1.4).** Drop the hidden `id` field, or keep it in
  sync with the selected options. Pulled forward from Phase 2 because supplier
  variants are confirmed and this must not be live when they arrive. The
  *pleasant* variant switching (price/image updating without reload) stays in
  Phase 2; this is only about the customer receiving what they picked.

Deliverable: measurably faster stores, product pages that show every image we
already sync, and a product form that survives variants. **No new
dependencies.**

## Phase 2 — Interaction layer

- A single small vanilla-JS file per theme (`assets/theme.js`, target < 8KB),
  loaded `defer`. No framework.
- **Cart drawer** using Shopify's **AJAX Cart API** (`/cart/add.js`,
  `/cart/change.js`, `/cart/update.js`) — built into every Shopify store, no
  API key, no cost.
- **Add to cart from collection cards.**
- **Variant switching** via `product.variants` JSON — price, availability and
  image updating live. The correctness half of this ships in Phase 1; this is
  the experience half.
- **Sticky mobile add-to-cart bar.**

Deliverable: the storefronts stop feeling like static pages.

## Phase 3 — Missing pages and distinct layouts

- Add the absent templates: `blog`, `article`, all `customers/*`, `password`
  (plus `layout/password.liquid`), `gift_card`. Password first — it's the first
  page anyone sees on a pool store.
  **All confirmed in scope: customer accounts (decision 1) and blog
  (decision 2) are both required for beta, so nothing drops out of this phase.**
  That makes Phase 3 the largest single block of theme work: 12 templates × 6
  themes, plus the account layout each theme needs.
- **Differentiate the six layouts** so niche fit is structural:
  - *Aurora* (fashion) — editorial hero, lookbook grid
  - *Noir* (luxury/jewellery) — full-bleed imagery, generous whitespace, serif
  - *Bloom* (beauty/kids) — ingredient/benefit blocks, bright cards
  - *Cove* (home/wellness) — long-form storytelling, alternating image+text
  - *Forge* (tools/outdoor) — dense spec tables, comparison rows
  - *Marble* (premium accessories) — minimal grid, large type, muted motion

Deliverable: six themes a merchant would choose *between*, not six palettes.

## Phase 4 — JSON templates (the unlock for page editing)

This is the architectural change that makes Phase 5 possible.

- Convert `templates/*.liquid` to `templates/*.json` with named section
  instances and settings.
- Give every section a real `{% schema %}` with settings and blocks, instead of
  reading global `settings.*`.
- Move header/footer into **section groups** so they're editable too.
- Keep `.liquid` fallbacks during migration so no store breaks mid-rollout.

Deliverable: no visible feature, but sections become first-class, addressable
and configurable per page — and the Shopify theme editor starts working
properly for merchants who want it.

## Phase 5 — Pages in the EcomAI builder

Once Phase 4 lands:

- Extend the plan schema: `pages[]` — `{ handle, title, sections[], seo }` —
  alongside today's `sections[]`.
- Builder UI: add/remove/rename pages, drag sections between them, per-page SEO.
  **Decision 4: no restrictions** — arbitrary page creation rather than a fixed
  menu of page types. EcomAI still *proposes* a niche-appropriate set, but the
  merchant isn't limited to it. This costs a real navigation editor (a page
  nobody can reach is worse than no page) and per-page handle validation.
- **Shopify write path:** create Shopify Page objects via
  `pageCreate`/`pageUpdate` (Admin GraphQL, scope `write_content` — **a new
  scope we don't currently request**), generate matching JSON templates, and
  add navigation entries.
- **Custom-website write path:** a dynamic route in the merchant app that
  renders any page handle from `stores.content`, reusing the same section
  renderer as the storefront.
- **EcomAI:** teach the builder prompt to propose a page set per niche — e.g. a
  supplement brand gets Ingredients + FAQ + Shipping; a jewellery brand gets
  Care Guide + Sizing.

Deliverable: the answer to "can EcomAI add or remove pages" becomes yes, on both
selling paths.

---

# Part 4 — Do we need any external API?

**Short answer: almost nothing. This is engineering work, not a purchasing
decision.**

| Capability | What we need | Cost |
| --- | --- | --- |
| Cart, add-to-cart, quantity | Shopify **AJAX Cart API** | Built in, free |
| Product/collection data in themes | Liquid | Built in, free |
| Creating pages & navigation | Shopify **Admin GraphQL** `pageCreate`, `menuCreate` | Free — needs the **`write_content` scope**, added now (decision 5) |
| Image resizing on Shopify | Shopify CDN `image_url: width:` | Built in, free |
| Image resizing on our CDN | **Cloudflare Image Resizing** in front of R2 | Paid add-on — *see below* |
| Custom-website storefront | Our own `/api/storefront/*` | Already built |
| AI copy and page planning | Existing EcomAI/Groq path | Already built |

**The one genuine gap: R2 does not transform images.** Shopify-hosted product
images get `srcset` for free through the Shopify CDN, but hero and section media
uploaded to R2 are served at whatever size the merchant uploaded — a 4MB hero
photo stays 4MB on a phone. Three options:

1. **Resize on upload** in `/api/media` (e.g. `sharp`), storing 3–4 derivatives
   per asset. Free, no new vendor, more storage, and no retroactive fix for
   already-uploaded media.
2. **Cloudflare Image Resizing** in front of R2 — URL-based transforms on the
   existing custom domain, nothing to store. Paid, but it's the same vendor and
   the same domain we've already set up.
3. **Cloudflare Images** — full product with its own storage and variants.
   Overlaps what R2 is already doing for us.

Recommendation: **option 1 now** (it costs nothing and covers the launch), with
option 2 as the upgrade when media volume justifies it.

**Scope decision (5): add `write_content` to `shopify.app.toml` now**, ahead of
Phase 5 needing it. Adding a scope forces every installed store to re-authorise.
Today that is two dev stores and a `shopify app deploy`; after launch it is
every live merchant, each one a support conversation. The scope is inert until
Phase 5 uses it, so there is no cost to holding it early — only to adding it
late. Batch any other foreseeable scope with it in the same change.

**Not recommended:** a page-builder SaaS, a headless CMS, or a third-party
theme framework. Each adds a second source of truth against `stores.content`,
which is the same trade already rejected when choosing Postgres over a CMS.

---

# Part 5 — Sequencing and effort

| Phase | Outcome | Rough size | Depends on |
| --- | --- | --- | --- |
| 1 — Performance & imagery | Faster stores, full product galleries | Medium | — |
| 2 — Interaction layer | Cart drawer, variant switching | Medium | — |
| 3 — Pages & distinct layouts | Six real identities, no broken journeys | **Largest** — 12 templates × 6 themes | — |
| 4 — JSON templates | Sections become first-class | Large | 1–3 land first |
| 5 — Pages in the builder | Add/remove pages via EcomAI | Large | 4 |

Phases 1 and 2 are independent and could run in parallel. Phase 3's *missing
templates* half is independent of its *distinct layouts* half and is the
cheaper, more urgent of the two — `password.liquid` especially.

With decisions 1–2 confirmed, Phase 3 no longer shrinks. Worth splitting it in
delivery: **3a — missing templates** (password, then customers/*, then blog and
gift card) and **3b — distinct layouts**. 3a removes broken journeys; 3b is
brand work and can follow.

**If only one phase ships before launch, make it Phase 1.** It fixes the most
visible quality gap (single-image product pages), removes the worst performance
cost (2000px heroes on phones), and carries no risk of breaking a live store.

---

# Part 6 — Decisions (2026-08-03)

All five questions are resolved. Nothing in this plan is now blocked on product.

| # | Question | Decision | Effect |
| --- | --- | --- | --- |
| 1 | Customer accounts in beta? | **Yes** | All seven `customers/*` templates stay in Phase 3, plus an account layout per theme |
| 2 | Blog in beta? | **Yes** | `blog` + `article` templates stay in Phase 3, plus navigation |
| 3 | Supplier product variants? | **Yes** | The 1.4 fix moves to **Phase 1**; full variant switching stays in Phase 2 and must land before variants ship |
| 4 | How much page freedom? | **No restrictions** | Phase 5 builds arbitrary page creation, which requires a navigation editor and handle validation |
| 5 | When to add `write_content`? | **Now** | Two dev stores re-auth today instead of every live merchant later |

The net effect is that **Phase 3 grew and Phase 1 grew slightly**; nothing got
smaller. The launch recommendation is unchanged — Phase 1 first — but Phase 3a
(missing templates) is now more urgent than it was, because confirming customer
accounts means those journeys are broken rather than merely absent.

---

# Part 7 — Draft stores with a 3-day TTL

Decided 2026-08-03. Self-contained, and sequenced **before** Phase 1 because
Phase 1 assumes merchants can add media before launch — which today they cannot.

## 7.1 Why

A store row is currently created only when the merchant presses **Launch my
store**. But the content editor renders only when a store already exists, and
`/api/media` requires an owned `stores` row to attach uploads to. The result is
that a first-time builder **cannot upload an image or edit content until after
they have launched** — the exact opposite of what the builder is for.

Creating the row up front gives the builder a real `storeId` from the first
moment, so media, content and version history all work during the build. The TTL
is what stops abandoned drafts accumulating forever.

## 7.2 Behaviour

- A `stores` row is inserted with `status = 'draft'` **when EcomAI first
  produces a plan** — not when `/builder` is opened, or every idle visit leaves
  a row behind.
- Re-entering the builder reuses the merchant's newest draft rather than adding
  another.
- Content, theme and logo autosave to that row as the merchant works.
- **Launch** flips the draft to a live store; it does not insert a second row.
- A draft untouched for **3 days** is deleted, with its media.

## 7.3 What has to change first

Three of these are live defects the moment a draft row can exist.

1. **Plan limits must ignore drafts.** `getEntitlements` counts every row for
   the user with no status filter (`entitlements.ts:43`). Without a change, two
   abandoned drafts lock a merchant out of their own plan. The count excludes
   drafts, and `assertCanCreateStore` runs at **launch**, not at draft creation.
2. **Drafts must not be publicly shoppable.** `getStorefront` and
   `storefront-api` filter on `type === 'own_platform'` but never on status, so
   a draft would be browsable and purchasable at `/store/<id>` as soon as the
   row exists. Both read paths gate on status.
3. **`stores.updated_at` is never maintained.** `touch_updated_at` exists and is
   attached to `profiles`, `products` and `shopify_stores` — but not `stores`.
   A TTL keyed on `updated_at` would silently expire nothing. Falling back to
   `created_at` is worse: it deletes drafts the merchant is actively editing.
   The trigger lands first.

## 7.4 Why cleanup is not a SQL job

Deleting the row cascades `store_assets`, but:

- the **R2 objects survive** as orphans nothing can find or account for; and
- a draft that reached provisioning holds a `shopify_store_id`, which a raw
  `DELETE` would fail to release back to the pool.

So expiry runs as a secret-authed API route on a **Vercel cron**, reusing the
existing `deleteStore` path — which already wipes Shopify content and releases
the pool store — rather than a `pg_cron` statement. Neither `vercel.json` nor
pg_cron exists today, so this is new infrastructure either way; this is the
version that is correct.

## 7.5 Scope

- Migration: `touch_updated_at` trigger on `stores`, plus an index supporting
  the expiry query.
- `getEntitlements`: exclude drafts from the store count.
- `getStorefront` / `storefront-api`: gate public reads on status.
- `ensureDraftStore` server action: create-or-reuse, called once a plan exists.
- Builder: autosave on a debounce; launch promotes the draft in place.
- `/api/cron/expire-drafts`: secret-authed, reuses `deleteStore`.
- `vercel.json`: daily cron.
- `/stores`: a **"Draft · expires in N days"** badge. Silent deletion of
  someone's work is hostile even at three days.

## 7.6 Open

A warning email at day 2 via Resend — "your draft store expires tomorrow" is
genuine re-engagement rather than a nag. Not built in the first pass; the badge
covers the honesty requirement on its own.
