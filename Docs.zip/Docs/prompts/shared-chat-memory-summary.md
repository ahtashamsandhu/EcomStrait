# Chat memory — rolling summary

| | |
|---|---|
| **Source file** | `packages/ai/src/memory/chat-threads.ts` |
| **Function** | `refreshSummary()` (system text in `SUMMARY_SYSTEM`), called from `appendChatTurns()` |
| **Used by** | `merchant_cofounder`, `supplier_cofounder`, `merchant_builder` — every real user-to-agent chat this codebase persists (see `ChatAgent`). Not shared with any agent-to-agent exchange. |
| **Role → model** | `fast-cheap` |
| **Temperature** | 0.2 |
| **Max tokens** | 300 |
| **Reasoning effort** | `"none"` |
| **Timeout** | 10000 ms |
| **Fallback** | Gateway not configured, or the call throws → keep the previous summary unchanged. As of 2026-09-04, an implausible-looking response (too short, or reads as a refusal) is also rejected in favor of the previous summary — see Notes. |

Maintains a durable "what happened earlier in this chat" summary once a
thread's raw messages start getting trimmed (`MAX_MESSAGES = 30`), so
reopening a long-running chat doesn't start cold. This summary is what gets
re-injected into every future turn of the owning agent's own system prompt —
see `merchant-cofounder-chat.md`, `supplier-cofounder-chat.md`, and
`merchant-chat-edit-and-pages.md` for exactly how each one labels and uses
it.

## System prompt

```text
You maintain a short running summary of an ongoing chat between a user and an AI business
assistant, so the assistant can pick the conversation back up later without re-reading the
whole transcript.
Fold the previous summary (if any) together with the messages below into ONE updated summary,
3-5 sentences, plain prose, no headings or bullet points.
Only state what was actually said — never resolve a hedge, a maybe, or an open question into a
firm fact or decision ("I might sell shoes" stays a maybe, not "sells shoes"; "thinking about
calling it Coastal Co" stays undecided, not "the store is named Coastal Co"). If something is
genuinely still undecided, unclear, or was said with a caveat, say so as unresolved rather than
picking the more definite-sounding reading — this summary gets re-injected into every future
turn as if it were settled fact, so a compressed hedge that hardens into a stated fact here is
a real, durable mistake, not a harmless simplification.
Focus on what would actually help resuming this conversation: the business/store being
discussed, concrete facts stated, decisions made, and anything left open or unresolved — never
a blow-by-blow transcript recap, never small talk.
If the previous summary already covers something these messages don't change, keep it; only
add or revise what's actually new.
```

## User message

```text
Previous summary: {previous summary, or "(none yet)"}

Messages:
{role}: {content}
{role}: {content}
...

Still-visible recent messages, for cross-checking only — don't summarize these, and don't let the summary contradict them:
{role}: {content}
...
```

The first `Messages:` block is either the batch of messages being trimmed
out of the raw 30-message window (the normal case, on every refresh past the
first), or the full kept window itself (only on the very first summary,
before anything's been trimmed yet). The trailing `Still-visible recent
messages` block — added 2026-09-04, see Notes — is the last 6 kept messages,
included only on a trim (not the first-ever summary), purely as a
cross-check anchor.

## Expected output

Plain text (not JSON) — the updated summary itself, used verbatim (trimmed).

## Notes

- **2026-09-04, three hallucination-audit fixes, all in this one shared
  file** (the highest-leverage fix identified in that audit — one change
  here improves every chat surface in both apps at once):
  1. **No anti-invention guardrail.** The prompt previously had no
     instruction against resolving a hedge into a stated fact. Added the
     "only state what was actually said... never resolve a hedge" paragraph
     quoted above.
  2. **Output validated only for emptiness.** `content.trim() || previous`
     was the entire check before persisting a response as durable "ground
     truth" re-injected into every future turn — a non-empty but garbled or
     off-task response (a refusal, an apology, a truncated sentence from
     hitting `maxTokens: 300`) passed straight through. Added
     `isPlausibleSummary()`: rejects anything under 15 characters or that
     starts with an obvious refusal pattern (`/^(i'm (not able|sorry|unable)|i can'?t|i cannot|as an ai|i do not have)/i`),
     falling back to the previous summary instead — a false negative here
     just means keeping the old summary one cycle longer, never worse than
     that.
  3. **Compounding drift with no re-grounding.** Each refresh previously saw
     only the previous summary (itself a paraphrase) plus the newly
     dropped/kept batch — never the fuller current transcript. Over many
     refresh cycles on a long-lived thread, this is repeated paraphrase-of-
     a-paraphrase compression with no fidelity check, so a softly-worded
     detail could incrementally harden into a flatly-stated fact purely
     through repeated compression. Fixed by always including a tail of the
     6 most recent still-visible messages (`recentTail`) alongside whatever
     is being folded in on a trim, so every refresh re-grounds against real
     current messages instead of chaining purely off its own prior output.
- **Deliberately NOT fixed here**: what happens once this summary reaches
  each consuming agent's own prompt (whether it's labeled as
  lower-confidence than real data, and which one wins if it conflicts with
  actual recent messages) is each consumer's own responsibility — see the
  three per-agent docs linked above for what each one does with it. This
  file only controls how the summary itself is produced and validated.
- Runs in-line (awaited) inside `appendChatTurns()`, not fire-and-forget —
  deliberate: it's a single cheap `fast-cheap` call that only actually fires
  occasionally (not every turn — only when trimming or on the very first
  summary), and `packages/ai` has no framework-specific "run this after the
  response" primitive of its own. Never throws: a history-saving failure is
  a convenience lost, not a reason to break the chat the user is actually
  waiting on.
