# Category page — AI copy

| | |
|---|---|
| **Source file** | `apps/merchant/src/lib/category-content.ts` |
| **Function** | `ensureCategoryDescription()` (system text in `SYSTEM`) |
| **Role → model** | `fast-cheap` → Claude Haiku (via the AI Gateway) |
| **Temperature** | 0.7 |
| **Max tokens** | 200 |
| **Timeout** | 10000 ms |
| **Fallback** | `presetDescription(storeName, label)` — a one-line deterministic sentence, used when the gateway isn't configured, the tenant is over budget, or the call fails |

Generates the short intro paragraph shown at the top of a storefront category
page. Generated **once** per `(store, category)` pair and cached forever in
`store_category_content` — never regenerated automatically, and never on the
request that's actually rendering the page for a customer (the call site
wraps this in `after()`).

## System prompt

```text
Write one short, natural paragraph (2-3 sentences) introducing a product category page for an online store. Warm, confident, no hype, no emojis, no headings, no markdown. Mention the category naturally — never say "category page." Never state a specific fact about the products or the store that isn't implied by the category name or the product titles given — no material, certification, warranty, guarantee, sourcing claim, or count you weren't actually told. This is cached and shown to real customers indefinitely, with no review before the first time it's shown — write generally enough to stay true rather than specifically enough to risk being wrong.
```

## User message

```text
Store: {storeName}
Category: {label}
Some products in it: {up to 10 product titles, comma-separated, or "(none listed)"}
```

## Expected output

Plain text (not JSON) — the paragraph itself, used verbatim (trimmed).

## Notes

- **2026-09-04, anti-invention guardrail (hallucination audit)**: this
  prompt had no guardrail against inventing a specific fact about the
  products/store — flagged as high-severity precisely because the output is
  cached forever and shown to real customers with no human review of the
  first-ever generation. Fixed with the sentence quoted above.
- Cost is attributed to the store owner via the tenant-scoped cost ledger
  (`assertCostBudget`/`recordUsage` from `@ecomstrait/ai`'s guardrails) —
  the same mechanism the restock agent and business advisor use for AI work
  that isn't a merchant clicking a button in the moment.
- Upserts on `(store_id, category)`, so two near-simultaneous first visits to
  the same never-generated category can't both write — the second write is a
  no-op update, not a duplicate row or a constraint error.
