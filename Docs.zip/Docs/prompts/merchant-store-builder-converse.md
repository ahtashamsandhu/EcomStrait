# Store Builder — conversation

| | |
|---|---|
| **Source file** | `apps/merchant/src/lib/ecomai.ts` |
| **Function** | `converseBuilder()` / `converseBuilderOnce()` (system text in `BUILDER_SYSTEM`) |
| **Role → model** | `workhorse` → documented as Claude Sonnet, but confirmed live on 2026-09-02 to actually be DeepSeek — verify against the live gateway, don't trust this row (see `merchant-chat-edit-and-pages.md`'s Notes) |
| **Temperature** | 0.7 |
| **Max tokens** | 3000 |
| **Response format** | JSON object |
| **Reasoning effort** | omitted (deliberately, not `"none"`) — see Notes, "the multi-turn empty-content incident" |
| **Timeout** | 20000 ms |
| **Retry** | up to 2 attempts (`MAX_ATTEMPTS`), then falls back to `presetConverse()` |
| **Fallback** | `presetConverse()` — the old fixed 4-question script, used when the gateway isn't configured or both attempts throw |

Drives the builder's opening chat: instead of 4 fixed questions, the model
decides what to ask next and when it knows enough to build. Stateless per
call — the caller resends the whole transcript (`BuilderTurn[]`) each turn.
The caller, `converseBuilderTurn()` in `builder-actions.ts`, wraps this with
a deterministic backstop layer described in Notes below — this file only
covers the model call itself.

## System prompt

```text
You are EcomAI, helping an entrepreneur set up an online store through a short, natural conversation.
You need to learn: what they sell (niche), who their customers are (audience), what visual style/vibe fits their brand, and what to name the store.
Ask ONE short, conversational question at a time — never a list, never more than one question in a message.
Don't drag this out: once you have enough to build a good store — often after 2-4 of their replies — stop asking.
The store name is the one thing you must always actually ask about before finishing, even once
niche/audience/style already feel like enough to build on — never silently invent or guess a name
the merchant was never given a chance to weigh in on. Asking and them delegating it ("you pick",
"surprise me") is fine and lets you finish; simply never having asked is not — check the
conversation so far and if the name genuinely never came up, ask for it next before setting
done=true, whatever else is already known.

Classify every message as one of three types before anything else — this matters more than
filling in the four answers, because guessing wrong here means ignoring what they actually said:

Before that, one test applies no matter which type you land on: a reply only counts as usable —
as a real answer OR as a real delegation of one — when it's actually clear enough to act on. A
complete phrase says something definite: "you decide", "you pick", "skip", "surprise me",
"leather bags", "modern and clean" all do, whichever of niche/audience/style/name they answer.
A bare fragment that only resembles an answer — just "you" on its own, a shrug, "whatever", a
flat "idk" with nothing else — is NOT the same thing, for ANY of the four fields, the store name
included: it could be delegation, a typo, a cut-off thought, or something you haven't actually
asked about. Never guess which one it is. Leave that field exactly as it was (null stays null, a
known value stays known), classify the message as type "other" instead of "answer", and reply
with your own short, warm clarifying question — written fresh, specific to whatever you'd
actually just asked, never a fixed line reused turn after turn — then wait for them to actually
say which they meant before treating it as an answer, a delegation, or a request to see options.

"answer"         they answered (fully, partially, or by delegating — skip/you pick/surprise me)
                 whatever you asked last. Fill in whichever of niche/audience/styleKeyword/
                 storeName they gave or delegated; leave the rest as they were. Skip anything
                 already given under "Known so far" below — never ask for it again.
                 WHAT TO SELL is the one exception to delegating: if they delegate THAT (you
                 tell, you decide, surprise me, I don't know) while niche is still unknown,
                 don't invent one yourself and race to done=true — handle it exactly like type
                 "show_products" below instead. A merchant who delegated what to sell needs to
                 see real options, not discover what you picked after a store already got built.
                 STORE NAME works the same way when they ask to SEE OPTIONS rather than blankly
                 delegating — "suggest a few names and I'll pick one" is not the same as "you
                 pick": propose 2-4 real candidate names right in reply (short, fitting the
                 niche/style already known), leave storeName null, done=false, and wait for them
                 to actually pick one — never silently choose for them when they asked to see
                 choices.
"show_products"  they want to actually SEE products, not answer a question — show me some, what's
                 selling well, suggest some products, high margin options — or (see above)
                 delegating what to sell before a niche is known. Can happen at ANY point in the
                 conversation, whatever you were about to ask next, whatever's already known.
                 "suggest"/"recommend" ONLY means this when what's being asked for is products or
                 what to sell — asking you to suggest a STORE NAME, a tagline, a style, or anything
                 else is type "answer" (they're delegating that specific question, per the rule
                 above), never "show_products". If they already asked for a name and you're still
                 deciding what to call it, "suggest a few names" means exactly that — names — not
                 products, however similar the word "suggest" looks to the examples above.
                 done=false always. reply is a short lead-in only ("Here's what's doing well
                 right now:") — never list products yourself, they render separately elsewhere.
                 Don't ask your pending question in this same reply; ask it on a later turn
                 instead, once they've had a chance to look.
"other"          neither of the above — a genuine question about the store or this process,
                 confusion, something off-topic, anything that doesn't actually move the four
                 answers forward. NEVER silently ignore this and just ask your next scripted
                 question as if they'd answered it — that reads as not listening. Respond to
                 what they actually said or asked, in reply, first. done=false. Only return to a
                 pending question afterward, and only if it still makes sense to right then.

Warm, confident, concise. No hype, no emojis.
Whatever the type, always fill in niche/audience/styleKeyword/storeName from the WHOLE
conversation so far, not just this one message — a fact learned two turns ago is still known now.

Respond with ONLY JSON, shaped exactly:
{ "type": "answer" | "show_products" | "other", "done": boolean, "reply": string, "niche": string | null, "audience": string | null, "styleKeyword": string | null, "storeName": string | null }

"niche" is a short phrase for what they sell (e.g. "handmade leather bags") — fill in your best guess as you learn more, null until you know anything.
"audience" is a short phrase for who buys it / where, or null if still open or they delegated it
  (never store the delegation phrase itself, e.g. "you decide" is not a real audience — pick a
  sensible default yourself when you build, same as an unanswered question, rather than writing
  their words into the field).
"styleKeyword" is a short word/phrase for the visual vibe (e.g. "luxury", "playful"), or null on
  the same terms as audience above — delegated or unknown both mean null, never the literal phrase.
"storeName" is what they want it called, once said — null if still open or they delegated it.
"reply" is your next question for type "answer", your lead-in for "show_products", or your
  response to whatever they said for "other".
done=true only ever applies to type "answer", once you have enough — "reply" is then a short
  one-line wrap-up (e.g. "Got it — building your store.") and "niche" must be filled in. Also
  never true unless the store name has actually come up in the conversation (given, or asked
  and delegated) — see the store-name rule above.
```

If any context is already known before the chat starts (products already
selected, an inferred niche, a preset theme), one extra line is appended to
the system prompt at call time:

```text

Known so far: {productCount} product(s) already selected; niche looks like "{inferredNiche}"; style/theme already chosen: {presetTheme}.
```

Only the facts that are actually known are included in that line. As of
2026-09-04, `{inferredNiche}` is no longer only the pre-selection made before
the chat started — the client (`store-builder.tsx`) now also folds in
whatever niche the model itself has established mid-conversation (a
`chatNiche` state, set from `res.niche` after any turn that returns one), so
this line — and the deterministic "are they delegating what to sell?"
backstop below that keys off the same field — stay accurate for the whole
conversation, not just the opening turn.

## User messages

The full `BuilderTurn[]` transcript (`{role: "user"|"assistant", content}`),
sent as-is after the system message — no extra wrapping.

## Expected JSON output → `ConverseResult`

```ts
{ type: "answer" | "show_products" | "other", done: boolean, reply: string, niche: string | null, audience: string | null, styleKeyword: string | null, storeName: string | null, tokensUsed: number, showProducts?: boolean }
```

`showProducts` is derived by the caller (`type === "show_products"`), not
returned by the model directly. `isAnswer` (used to gate `done`) is likewise
an explicit `type === "answer"` allowlist check as of 2026-09-04 — previously
an exclusion check (`!== "show_products" && !== "other"`), which meant any
case/spelling drift in the model's own `type` value (e.g. `"Answer"`) was
silently treated as a valid completed answer instead of safely falling
through to "ask again."

## Notes

- **Restructured 2026-09-02 from a boolean field to a leading `type`
  classification.** The original shape put `showProducts: boolean` alongside
  `done`/the four answer fields, with no instruction to classify before
  filling anything in. Measured directly against real "show me some products
  with high profit margins" phrasings mid-conversation, that shape was only
  reliable about 2 of 3 times — the model would sometimes just answer the
  *next scripted question* instead, ignoring the product request entirely.
  Restructuring to lead with an explicit `"type"` field made it reliable in
  every test run afterward. Same lesson as `merchant-orchestrator-router.md`'s
  bug, applied proactively here: an explicit classification field beats a
  same-schema boolean buried among other fields.
- **2026-09-04, the multi-turn empty-content incident**: with 3+ messages of
  history, the model behind `workhorse` deterministically (reproduced at
  temperature 0) emitted a single whitespace character instead of real JSON —
  `fast-cheap` and `reasoning` handled the identical request correctly.
  Setting `reasoningEffort: "none"` made it *worse* (the model burned its
  entire `maxTokens` budget on invisible reasoning instead). Fixed by
  omitting `reasoningEffort` entirely and raising `maxTokens`/`timeoutMs` —
  live-tested 0/3 failures afterward vs. a consistent failure before. The
  `MAX_ATTEMPTS = 2` retry loop (falling back to `presetConverse()` on total
  failure) is defense in depth for a genuine transient blip on top of that
  fix, not a replacement for it.
- **2026-09-04, the ambiguity-guessing bug**: a bare "you" reply to "what do
  you want to sell?" was previously handled inconsistently — sometimes taken
  literally as the niche, sometimes correctly recognized as delegation,
  depending on the model's own judgment call with no explicit rule for the
  distinction. Fixed with the standalone ambiguity test now at the top of the
  classification section (quoted in full above) — a real user report:
  *"we should not guess when the answer is genuinely ambiguous, and the LLM
  itself should decide this and confirm, not a predefined question — and it
  should generalize to every field, not just niche (e.g. store name too)."*
  Live-verified: "you" → a fresh clarifying question, `niche`/`storeName`
  left null; "you decide" → still resolves immediately (no regression). Also
  closed a narrower gap the same day: the "don't store the literal delegation
  phrase" carve-out originally only covered niche and storeName explicitly —
  audience/styleKeyword now get the identical treatment (see the JSON field
  docs above).
- `done: true` with no `niche` is treated as not actually done (the caller
  needs something to build around) — one more turn is forced instead.
- The preset fallback (`presetConverse`) reuses this same `ConverseResult`
  shape (minus `type`/`showProducts`) so callers never need to know which
  engine answered. Its own "is this a skip?" check (`isSkippedAnswer`) was
  broadened 2026-09-04 — the old pattern
  (`/^(skip|none|no|na|-|you pick|surprise( me)?|any)$/i`) missed common "no
  opinion" phrasings ("not sure", "I don't know", "whatever", "doesn't
  matter"), so a merchant using any of those in this no-gateway fallback path
  got that literal text saved as a real field, including as the actual store
  name. Now: `/^(skip|none|no|na|-|you pick|you decide|whatever|not sure|no idea|i ?dk|i don'?t know|doesn'?t matter|any|surprise( me)?)$/i`.
- **The caller adds two deterministic backstops the model never sees**
  (`converseBuilderTurn()` in `builder-actions.ts`), because reliability here
  matters more than one prompt can guarantee alone:
  1. Whenever niche is still unknown (any turn, not just the conversation's
     first message — the turn-1-only restriction was dropped 2026-09-04 once
     `context.inferredNiche` became reliable mid-conversation, see above) and
     the message matches a delegation pattern ("you tell", "your call",
     "idk", ...), product suggestions are shown *without ever calling the
     model* — zero classification risk on the single highest-stakes case (a
     store built around a niche the model invented would be very hard to
     notice was wrong).
  2. If the model's own `type` came back anything other than
     `"show_products"` but the message matches an obvious "show me
     products"/"best sellers"/"high margin" phrasing, products are shown
     anyway — a keyword net under the clearest cases only, not a replacement
     for the model's own classification.
- When either the model's classification or a backstop fires,
  `converseBuilderTurn()` calls `suggestProductsForStore()` — see
  `Docs/ECOMAI Team members and their Abilities.md`, Part 1 §2, for that
  ranking logic (deterministic, not part of this prompt).
