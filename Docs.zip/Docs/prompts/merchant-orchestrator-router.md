# Orchestrator — router

| | |
|---|---|
| **Source file** | `packages/ai/src/agents/orchestrator.ts` |
| **Function** | `runOrchestrator()`'s `"router"` graph node |
| **Role → model** | `fast-cheap` → Claude Haiku (via the AI Gateway), through `createChatModel` |
| **Temperature** | 0 |
| **Framework** | Raw `createChatModel` call (`.invoke`), not a tool-calling agent — this node only classifies, it never calls a tool itself |
| **Fallback** | None — a budget check (`assertCostBudget`) runs before this, so the only failure mode is the graph call itself throwing, which propagates up |

The entry point of the LangGraph `StateGraph`: a single classification call
that decides whether a merchant's message goes to the Business Advisor or
the Analytics Agent.

## Prompt

```text
Classify the merchant's message as "analytics" (asking about sales, orders, revenue, numbers, or performance) or "advisor" (general business advice, product, marketing, or strategy questions — this includes any question that also needs a recommendation or judgment call, even one that starts from a number, since the advisor has the same SQL query tool available and can look the number up itself before advising).
Examples:
"What was my total revenue last month?" -> analytics (a pure numbers question, nothing to recommend)
"How many orders came in this week?" -> analytics (a pure numbers question)
"How can I get more repeat customers?" -> advisor (strategy/advice, no specific number needed)
"Why did my revenue drop last month, and what should I do about it?" -> advisor (mixed/ambiguous case: it needs a real number to open with, but also a recommendation — route the whole thing to advisor rather than splitting one question across two specialists, since advisor can query the same data itself)
Reply with exactly one word: analytics or advisor.
```

## Input

The last message in the conversation (`state.messages[state.messages.length - 1]`)
as plain text.

## Output

A route decision (`"analytics" | "advisor"`), parsed by checking whether the
model's one-word answer contains the substring `"analytics"` — anything else
(including a malformed or verbose reply) defaults to `"advisor"`.

## Notes

- **2026-09-04 hallucination-audit fix**: previously a one-line prompt with
  no calibrating examples and no mixed/ambiguous case addressed — flagged as
  likely inconsistent on boundary phrasings run-to-run. Added the four
  few-shot examples above, including the required mixed case ("why did my
  revenue drop and what should I do about it?" → `advisor`, since the
  advisor agent already carries `run_sql_query` too and a diagnose-then-
  recommend question shouldn't be split across two specialists).
- **2026-09-04, one retry before the generic fallback**: if the chosen
  specialist's final synthesis turn comes back empty (the documented
  `reasoning`/`workhorse` empty-content bug — see `merchant-business-advisor.md`
  and `merchant-analytics-agent.md`), `runOrchestrator()` now drops that
  empty message and re-invokes the same specialist agent on the remaining
  transcript (which still ends in a real `ToolMessage`/`HumanMessage`) once
  before falling back to "I looked into that but couldn't put together a
  clear answer." Previously this generic message was the only mitigation,
  discarding a correctly-computed answer whenever the bug hit. Usage/tool-
  call persistence reads from the post-retry message list, so cost and the
  audit trace stay accurate either way.
- `contentToText()` explicitly extracts text parts from the response rather
  than `String(content)` — a real bug this fixed: some gateway responses
  return `content` as an array of content parts, and `String()`-ing that
  array produced the literal text `"[object Object]"`, which never matched
  `"analytics"` and silently routed every message to the advisor regardless
  of what was actually asked.
- This is a genuine LangGraph handoff (`StateGraph` with a conditional edge
  to one of two agent nodes), not an if/else dressed up as one — see
  `Docs/AI-Native-Migration-Plan.md`, Phase 4.
