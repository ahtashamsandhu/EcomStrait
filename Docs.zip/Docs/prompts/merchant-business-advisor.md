# "Ask my Store" advisor agent

| | |
|---|---|
| **Source file** | `packages/ai/src/agents/business-advisor.ts` |
| **Function** | `createBusinessAdvisorAgent({ tenantId, extraTools })` |
| **Called from** | `apps/merchant/src/lib/agents/business-advisor.ts` → `askBusinessAdvisor()` → `runOrchestrator()` (see `merchant-orchestrator-router.md`) — itself called from the Co-Founder orchestrator's `ask_business_advisor` tool (see `merchant-cofounder-chat.md`) whenever a message names one specific store |
| **Role → model** | `reasoning` → Claude Opus (via the AI Gateway), through `createChatModel` |
| **Temperature** | 0.4 |
| **Max tokens / timeout / reasoning effort** | 4000 / 45000 ms / `"low"` — added 2026-09-04, see Notes |
| **Framework** | LangGraph `createReactAgent` (tool-calling agent, not a raw `chat()` call) |
| **Fallback** | If this throws when called as the `ask_business_advisor` tool, the Co-Founder orchestrator's own outer try/catch returns its generic "couldn't reach the AI advisor" reply rather than crashing the turn (see `merchant-cofounder-chat.md`) |

Answers a merchant's open-ended business questions, grounded in tools rather
than the model's own guesses — never SQL or knowledge invented on the spot.

## Prompt

```text
You are EcomAI, a merchant's AI business co-founder. Ground every answer in the search_knowledge_base and run_sql_query tools (and any store-specific tools available) — never guess at numbers or claims you haven't looked up. If a tool returns nothing relevant, say so plainly rather than inventing an answer. search_knowledge_base results each include a similarity score in parentheses (0 to 1, higher is a closer match). Treat anything below about 0.75 as a weak match: say plainly that you found something related but not a strong match, rather than presenting it with full confidence — never blend a weak match with invented specifics into one confident-sounding paragraph. Before stating a number from run_sql_query as fact, check that it actually returned rows and that the shape matches what you expected (not an empty result, an "Error: ..." string, or an unexpected set of columns) — a query that came back empty or malformed means you don't have an answer yet, not that the answer is zero. Be concise, warm, and specific. You have NO ability to edit this store's own content — headline, tagline, colours, about text, SEO, announcement bar, footer, or a whole page. That happens through this exact same chat, just by asking directly in plain terms (e.g. "change the hero headline to ...") — never through a theme editor or admin dashboard. If you're ever asked to change something like that, say in one line that you can't but the chat itself can, and ask them to rephrase it as a direct instruction — never invent steps in Shopify Admin, a theme customizer, or any other dashboard. Only mention Shopify at all if the store context given to you says this store's type is a Shopify type; a store with no Shopify connection has nothing to point them to there.
```

## Injected context (system message, prepended by the caller)

Built by `describeStore()` in `apps/merchant/src/lib/agents/business-advisor.ts`:

```text
You are discussing the following store: store id: {storeId}, store name: {name}, store type: {type}[, Shopify domain: {shop_domain}]. Filter every query to this store.
```

## Tools available

| Tool | Source | Purpose |
|---|---|---|
| `search_knowledge_base` | `packages/ai/src/agents/tools/retrieve-tool.ts` | RAG search over the niche KB blended with this tenant's own indexed content |
| `run_sql_query` | `packages/ai/src/agents/tools/supabase-query-tool.ts` | Read-only (`SELECT`/`WITH`) SQL against the platform DB, via a `bypassrls` read-only Postgres role |
| `get_shop_status`, `list_locations` | `apps/merchant/src/lib/mcp/shopify-server.ts` (via `createShopifyTools`) | Read this store's live Shopify state |
| `propose_set_product_price`, `propose_set_product_status` | `apps/merchant/src/lib/agents/shopify-write-tools.ts` | **Never writes directly** — creates a pending `ai_approvals` row; a human must approve before Shopify is actually changed |

## Notes

- **2026-09-04 hallucination-audit fixes**: this agent runs the `reasoning`
  role across a multi-turn tool-calling loop (one reasoning turn per tool
  call plus the final synthesis) with the same documented empty-content bug
  as `merchant-cofounder-chat.md`'s orchestrator — previously with zero
  mitigation here (no `maxTokens`/timeout/`reasoningEffort`), despite the
  routing layer's own runtime comment (`merchant-orchestrator-router.md`)
  documenting this exact agent hitting the bug in testing. Fixed with the
  same `reasoningEffort: "low"`/`maxTokens: 4000`/`timeoutMs: 45000` pattern
  already proven on `runCofounderOrchestrator`. Also added: a similarity-
  floor instruction for `search_knowledge_base` (it already returns a score
  inline, no new plumbing needed) so a weak match gets caveated instead of
  blended confidently with invented specifics, and a row-count/shape sanity
  check before asserting a `run_sql_query` number as fact (mirrors the
  identical fix in `merchant-analytics-agent.md`).
- One conversation thread per store (`threadId = storeId`); a merchant with
  several stores gets separate advisor context per store.
- `assertCostBudget(tenantId)` is checked **before** the graph even runs — a
  tenant over their daily token cap never reaches the model.
- **Real bug this prompt addition fixed**: this agent has no store-content
  editing tool, so a content-edit-shaped question that reached it (a routing
  bug — see `merchant-chat-edit-and-pages.md`'s Notes) got answered by
  checking Shopify tools, finding no connected store, and still confidently
  telling the merchant to go find the hero section in "Shopify Admin →
  Online Store → Themes → Customize" — on a store with no Shopify connection
  at all. The routing bug is fixed at the call site, but this prompt now
  also refuses to invent Shopify-flavored instructions unless the store
  context it was given actually says the store is a Shopify type, as
  defense in depth for whatever content-shaped question does legitimately
  reach it.
- Every run (input, output, and the full tool-call trace) is persisted to
  `ai_agent_runs`, whether it routed here or to the Analytics Agent.
