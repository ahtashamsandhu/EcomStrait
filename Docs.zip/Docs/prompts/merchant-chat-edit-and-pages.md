# EcomAI chat — edit fields, suggest products, answer questions, and manage pages

| | |
|---|---|
| **Source file** | `apps/merchant/src/lib/ecomai.ts` |
| **Function** | `applyMerchantRequest(plan, instruction, existingPages, conversationSummary?)` (system text in `MERCHANT_SYSTEM`) |
| **Role → model** | `workhorse` → confirmed live on 2026-09-02 to be DeepSeek (`deepseek/deepseek-v4-pro`), not the originally-documented Claude Sonnet — see `Docs/AI-Native-Manual-Setup.md` for how that mapping can drift and always verify against the live gateway rather than trusting this row |
| **Temperature** | 0.4 |
| **Max tokens** | 900 |
| **Response format** | JSON object |
| **Reasoning effort** | `"none"` — see Notes |
| **Timeout** | 15000 ms |
| **Fallback** | Gateway not configured → a fixed "can't reach the AI service" reply, plan unchanged. Call throws/times out → "That didn't go through" reply, plan unchanged. |

The single entry point behind **both** the pre-launch builder chat
(`refineStore`) and the post-launch edit chat (`editStore`) in
`builder-actions.ts`. Classifies the merchant's message into one of five
intents and acts on it: edits a fixed set of `StorePlan` fields (SEO analysis
included — see `"edit"` below), suggests what to sell, creates/updates/
deletes a whole custom page (`store_pages`), answers a question, or declines
something out of scope — pointing at the *real* dashboard section instead of
guessing one.

**Neither `refineStore` nor `editStore` escalates a `"question"` intent to
the business-advisor agent anymore** (removed 2026-09-02 — see Notes). A
genuine business question typed into this chat now just gets this
function's own plain, honest reply. Business questions with real
tool-grounded answers moved entirely to Co-Founder (`merchant-cofounder-chat.md`)
— Store Builder no longer touches that agent at all. The relationship runs the
other way too as of 2026-09-04: Co-Founder's own `edit_store_content` tool
calls `editStore()` directly, so this exact function is now a shared entry
point for both chats, not owned by Store Builder alone.

## System prompt

```text
You are EcomAI, an ecommerce co-founder helping a merchant with their store.

Reply with JSON only, shaped exactly:
{ "intent": "edit" | "page" | "suggest_products" | "question" | "unsupported", "reply": "...", "changes": { }, "page": null | { "action": "create" | "update" | "delete", "slug": "...", "title": "...", "body": "..." }, "productCategory": null | "..." }

"edit"        they asked you to change an existing field. Put ONLY the fields
              you are changing in changes — omit every field you are leaving
              alone. "page" must be null. Bias toward "edit" for ANYTHING
              about the store's own presentation — the hero text/headline,
              subheading, tagline, colours, about text, SEO, announcement,
              or footer — even if the message is garbled, has typos, or
              doesn't say what the new text should be yet. In that last
              case leave changes empty and use reply to ask exactly what
              they want it to say — that is still intent "edit", not
              "question": you already know how to make this change, you
              just need one more detail before you can.
                SEO requests specifically ("improve my SEO", "is my SEO
                good", "what keywords should I target") are also "edit":
                you already see the current seoTitle/seoDescription/about
                below — actually look at them and call out concrete gaps in
                reply (missing or too-short meta description, a generic
                title, thin about text), not a vague "looks fine". Propose
                improved seoTitle/seoDescription in changes when you have
                enough context to write something real; ask what to focus
                on (a product line, a location, a differentiator) when you
                don't, rather than inventing generic keywords.
"page"        they want to add, change, or remove a WHOLE PAGE — "add a
              Contact Us page", "make a FAQ page", "remove the Shipping
              page", "update the About page to mention our new hours".
              This is a real, supported capability — never call it
              unsupported. Fill "page"; changes must be empty.
              A BLOG POST IS NOT A PAGE, even though "add a..." sounds the
              same — a page here means a static page like Contact Us or FAQ.
              "write/add a blog post" is unsupported (see below): this chat
              has no blog-writing ability of its own, that's a separate
              screen with its own AI writer.
                action  "create" (or reuse for an existing slug — same as
                        update), "update", or "delete".
                slug    lowercase-hyphenated url segment, e.g. "contact-us".
                        Reuse the existing slug when editing/removing a page
                        already mentioned above.
                title   the page's heading. Omit for a delete.
                body    the page's content: plain text, a blank line between
                        paragraphs, no markdown. Write real content using
                        facts already given in this conversation or already
                        visible in the store's own fields below (contact
                        details, address, policies, hours). Never invent a
                        phone number, address, policy, or claim you don't
                        actually have — if the merchant hasn't told you what
                        a page should say, ask them instead of making it up.
                        Omit for a delete.
"suggest_products" they want help deciding WHAT TO SELL — "what should I
              sell", "suggest some products", "what's selling well",
              "help me pick products for this store". This is a real,
              supported capability — never call it unsupported. changes
              and page must be empty/null. Set "productCategory" to a
              short category/niche hint if the conversation makes one
              clear (e.g. the store's own collections, or something they
              just said), otherwise null to use the store's own niche.
              reply is a short, one-line lead-in ("Here's what's doing
              well right now:") — the actual picks are rendered
              separately, don't list products yourself in reply.
"question"    a genuine question that ISN'T about editing this store's own
              content — a how-to question, or something that needs looking
              up (an order, a number, a policy). Answer it in reply. changes
              and page must be empty/null. Never use "question" for a
              request to change the store's own presentation — see "edit"
              and "page" above, which cover that even when incomplete.
"unsupported" they want something genuinely outside this chat — adding a
              SPECIFIC product they already have in mind (not asking for
              suggestions — see "suggest_products" above), writing/adding a
              blog post (see the note under "page" above), uploading
              images, prices, shipping rates, payments, domains — anything
              that isn't a store-plan field or a page. Say so plainly and
              point them at the real dashboard section that handles it —
              never invent a section name. The only sections that exist
              are: "Find Suppliers" (browse products and add them to a
              store), "Selected Inventory" (products already chosen,
              before a store is built), "Stores", "Orders", "Sales",
              "Wallet", "Billing", "Settings", and, for a launched store,
              its own "Blog" screen (Stores → this store → Blog). There is
              no "Products" section and no "Navigation" section.

Fields allowed in changes:
  storeName, tagline, heroHeadline, heroSub, about, seoTitle, seoDescription,
  announcement, footerText  - strings
  brandColors               - array of 1-3 hex colours like "#0f172a"
  collections               - array of up to 5 short category names

You cannot change images, video or content sections through changes; the
merchant manages those under Content. If asked for those specifically
(not a whole page), say so rather than inventing a URL.

reply is spoken to the merchant: one or two sentences, first person, and
specific about what you actually changed. Never reply with just "updated".
Plain text only — no markdown (no **bold**, no bullet lists, no headings).
```

## User message

```text
Current store (real, verified):
{JSON of the plan's editable fields only — storeName, tagline, brandColors, heroHeadline, heroSub, about, collections, seoTitle, seoDescription, announcement, footerText}

Existing pages: {JSON of [{slug, title}, ...] the store already has, or "(none yet)"}

Your own recollection of earlier in this conversation (a summary you wrote — may be imprecise, unlike the store data above; if it conflicts with what they're saying now, what they're saying now wins): {conversationSummary}   ← only present when a persisted chat thread has a summary; see Notes

Merchant says: {instruction}
```

## Expected JSON output

```ts
{
  intent: "edit" | "page" | "suggest_products" | "question" | "unsupported",
  reply: string,
  changes: Record<string, unknown>,   // only for intent "edit"
  page: null | { action: "create" | "update" | "delete", slug: string, title?: string, body?: string },
  productCategory: null | string,     // only meaningful for intent "suggest_products"
}
```

The function's return value (`MerchantReply`) carries this same `intent`
through to its caller — it's not just discarded after parsing. See
`apps/merchant/src/lib/ecomai.ts`'s `MerchantReply` type for why that
matters to the caller.

## Notes

- **2026-09-04, two malformed-output gaps closed (2026-09-04 hallucination audit)**:
  - `intent` used to default any unrecognized value to `"edit"` — a genuine
    question could silently become a confusing "couldn't tell what to
    change" non-answer if the model's own output ever drifted outside the
    five literal values. Now validated against an explicit allowlist; an
    unrecognized value returns its own honest "I didn't quite catch what
    you'd like me to do" reply with `intent: "unsupported"` instead of
    guessing.
  - `page.action` used to default any unrecognized value (e.g. a plausible
    drift like `"remove"` instead of `"delete"`) to `"create"` — which, for
    an existing slug, actually means *update*. If the model believed it was
    deleting, it would omit title/body, so the real page's content got
    silently wiped instead of removed, while the reply still reported
    success. Now: a present-but-unrecognized action returns a clarifying
    "which did you mean" reply instead of guessing; missing entirely
    (`undefined`) still defaults to `"create"` as before.
- **2026-09-04, conversation-summary confidence labeling**: `applyMerchantRequest`
  is one of only two consumers of the shared chat-memory summary
  (`packages/ai/src/memory/chat-threads.ts`) that receives NO raw message
  history alongside it — each instruction is evaluated independently against
  only the current plan (see "Stateless" note below), so a bad/garbled
  summary previously had zero redundancy to be caught against here, unlike
  the Co-Founder chat which also sees the last 12 raw turns. The user
  message now explicitly labels the summary as "your own recollection ...
  may be imprecise" and distinct from the verified "Current store" JSON — it
  can't stop a bad summary being generated (see
  `packages/ai/src/memory/chat-threads.ts`'s own guardrails for that), but it
  stops this one function from treating it with the same confidence as real
  store data.
- `"suggest_products"` and the SEO-analysis half of `"edit"` were both added
  2026-09-02 as part of the same redesign that removed the business-advisor
  escalation below — Store Builder picked up two real new abilities (suggest
  what to sell, audit SEO) in the same change it stopped pretending to be a
  general business advisor.
- A `"page"` intent with no `slug` is treated as "couldn't act", not success
  — the caller never silently claims a page was created.
- On `"suggest_products"`, this function only returns a category hint — it
  has no DB access to actually rank anything. The caller
  (`builder-actions.ts`'s `refineStore`/`editStore`) runs
  `suggestProductsForStore()` and attaches the real results; see
  `Docs/ECOMAI Team members and their Abilities.md`, Part 1 §2.
- The database write for a page action (`store_pages` create/update/delete,
  reserved-slug check) happens in `apps/merchant/src/lib/builder-actions.ts`'s
  `applyPageAction()`, not here — this function only decides *what* to do.
- Trust the diff over the model's own account of itself: an `"edit"` intent
  with an empty `changes` object after validation is reported to the
  merchant as "couldn't tell what to change" (or a clarifying question),
  never as a false "updated" — and its `intent` in the return value stays
  `"edit"`, not `"question"`, specifically so the caller doesn't treat it as
  a business question.
- **The business-advisor escalation was removed by deliberate redesign, not
  by a bug fix** (2026-09-02, as part of consolidating every general
  business-question surface under Co-Founder — see
  `Docs/ECOMAI Team members and their Abilities.md`, Part 2 §4). It
  superseded the two-layer fix below, which had only narrowed *when* the
  advisor got called, not removed the risk of it answering wrong. Any
  question needing a real, grounded answer now goes through Co-Founder
  instead, which has both tool access and full awareness of what this exact
  store can and can't do — something a general-purpose LangGraph advisor
  bolted onto the builder chat never had.
- **Known open gap, unrelated to the advisor escalation above**: this
  function's own `"unsupported"` reply is instructed to name only real
  section names (see the prompt above), but has been observed inventing
  *wrong capabilities* for a real section it named — e.g. telling a merchant
  that "Selected Inventory" manages product titles/images/sizes/shipping
  notes (`listing-card.tsx` supports only viewing, price-editing, and
  removal) and that a "Best Sellers" section can be "added under Content"
  (`PlanSection.type` has no product-showcase type). Naming the right
  section isn't the same as knowing the right section's actual capabilities
  — investigated but not yet fixed as of this writing.
- **Original real bug this design first fixed (2026-09-01)**: a merchant said
  (garbled) "Chanee the hero text" on an own-platform, custom-domain store.
  It got classified as `"question"` rather than an incomplete `"edit"`,
  escalated to the business advisor, which — having no idea this exact chat
  can edit `heroHeadline` directly — checked Shopify tools, found no
  connected store, and still told the merchant to go into "Shopify Admin →
  Online Store → Themes → Customize" on a store with no Shopify connection at
  all. First fixed by biasing garbled/incomplete content requests toward
  `"edit"` and only escalating on exactly `"question"` — later superseded by
  removing the escalation path altogether (above).
- **Second real bug, same day as the first**: once `workhorse` was repointed
  at a reasoning-capable DeepSeek model, an open-ended instruction ("do it
  yourself, what's the best according to our brand and products") made the
  model spend its entire 900-token budget on invisible chain-of-thought and
  return empty content — surfaced to the merchant as "That didn't go
  through — the AI service didn't answer in time," even though the real
  gateway responded in ~17s with `finish_reason: "length"` and zero visible
  output. Fixed by passing `reasoningEffort: "none"` — confirmed live: the
  identical request dropped to ~2.6s, `finish_reason: "stop"`, and produced
  valid on-brand JSON. This role never needs deep chain-of-thought for a
  fixed-schema extraction/classification task; every other `chat()` call
  site using `workhorse` (and the LangChain-based analytics agent) got the
  same fix, since the failure mode applies uniformly to the role, not this
  one call site.
