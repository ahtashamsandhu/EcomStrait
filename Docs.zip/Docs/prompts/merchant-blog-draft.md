# Blog — AI draft generation

| | |
|---|---|
| **Source file** | `apps/merchant/src/lib/ecomai.ts` |
| **Function** | `generateBlogDraft(topic, storeName)` (system text in `BLOG_SYSTEM`) |
| **Role → model** | `workhorse` — do not trust "Claude Sonnet" as current fact; confirmed live to have moved to other vendors more than once (see `merchant-chat-edit-and-pages.md`'s Notes) — verify against the live gateway |
| **Temperature** | 0.7 |
| **Max tokens** | 1200 |
| **Response format** | JSON object |
| **Reasoning effort** | `"none"` — see `merchant-chat-edit-and-pages.md`'s Notes: a reasoning-capable model behind this role can otherwise spend its whole token budget "thinking" and return empty content |
| **Timeout** | 20000 ms |
| **Fallback** | `presetBlogDraft(topic, storeName)` — short deterministic placeholder post |

The AI-authored half of the blog system (`blog-actions.ts`'s
`generatePostDraft`) — a merchant can also write a post from scratch instead.
The draft is always saved as a normal editable post; nothing here publishes
automatically.

## System prompt

```text
You are EcomAI, writing a blog post for an online store.
Write genuinely useful, specific content for the topic given — not generic filler.
3-5 short paragraphs, plain text, a blank line between paragraphs. No markdown headings, no bullet lists, no emojis.
Warm, confident, concrete — mention real specifics implied by the topic and the store rather than vague generalities.
"Concrete" means write with authority in how you explain general, genuinely-true things about the
topic itself (how a material behaves, what to look for, common mistakes) — it does NOT mean
inventing specifics about THIS store or its products that you weren't given: no material,
certification, warranty, guarantee, return policy, sourcing claim, or statistic about the store's
own products unless it's implied by the topic/store name in an obviously generic way. This is
published as a real draft a customer may read — a fabricated claim about the store itself is a
real, durable mistake, not harmless color. When the topic needs a specific store fact to feel
complete, write around it in general terms rather than inventing the specific.
Respond with ONLY JSON using these exact keys:
{
  "title": string,
  "excerpt": string,        // one sentence, shown in the blog list
  "body": string,           // the full post
  "seoTitle": string,       // <= 60 chars, so a search result never truncates it
  "seoDescription": string  // 120-155 chars — same convention apps/supplier/src/lib/ai.ts uses
}
```

## User message

```text
Store: {storeName}
Blog post topic: {topic}
```

## Expected JSON output → `BlogDraft`

```ts
{ title: string, excerpt: string, body: string, seoTitle: string, seoDescription: string }
```

## Notes

- **2026-09-04, anti-invention guardrail (hallucination audit)**: this prompt
  previously had no equivalent to `MERCHANT_SYSTEM`'s existing "never invent
  a phone number, address, policy, or claim you don't actually have" rule for
  page bodies — combined with the instruction to be "specific"/"concrete"
  from only a topic and store name (no real product/company facts given),
  this was a real gap: a merchant entering a topic like "our new organic
  cotton line" could plausibly get an invented certification or a fabricated
  returns policy in a real, published draft. Fixed with the paragraph quoted
  above.
- **`seoTitle`/`seoDescription` length, added 2026-09** — see
  `merchant-store-plan-generate.md`'s Notes for the full explanation: this
  prompt instruction is a request, not the actual guarantee, which lives in
  `storefrontMetadata()` (`apps/merchant/src/lib/storefront-seo.tsx`) and
  applies regardless of whether this prompt, `presetBlogDraft()`'s fallback,
  or something else produced the text.
- `body` uses the same minimal-markup convention as `about`/section `body`
  elsewhere in a `StorePlan`: plain text, paragraphs separated by a blank
  line, no markdown.
- Each missing/invalid field is backfilled individually from
  `presetBlogDraft()`, same per-field merge pattern as the store-plan prompt.
