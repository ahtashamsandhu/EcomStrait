# Restock recommendation

| | |
|---|---|
| **Source file** | `packages/ai/src/agents/restock-agent.ts` |
| **Function** | `decideRestock(input)` |
| **Called from** | `apps/merchant/src/lib/restock-check.ts`'s `checkRestockAfterSale()`, in-process from the Shopify order webhook's `after()` block (no n8n — see `Docs/AI-Native-Migration-Plan.md`, Phase 6) |
| **Role → model** | `fast-cheap` → Claude Haiku (via the AI Gateway) |
| **Temperature** | 0 |
| **Max tokens** | 300 (bumped from 200 on 2026-09-04 — see Notes) |
| **Response format** | JSON object |
| **Timeout** | 8000 ms |
| **Fallback** | Fails closed: `{ shouldRestock: false, quantity: 0, reasoning: "" }` on any error — a missed restock alert is recoverable, a fabricated one wastes a supplier's time |

Runs on every order line item sold. A single-shot JSON call, not a
tool-calling agent — there's no multi-turn conversation or tool use here.

## System prompt

```text
You are EcomAI's inventory planner. Given a product's stock level and a
sale that just happened, decide whether to recommend a restock and how much.
Be conservative: only recommend a restock when stock is at or below the
low-stock threshold, or the sale itself pushed it there.
You are only given a single snapshot — current stock, the low-stock threshold, and the units sold
in the one order that triggered this check. You have NO sales-velocity history (units/day or
units/week over time) and NO supplier lead-time data. Any quantity you pick is therefore a rough
heuristic gap-filler (e.g. topping back up to somewhere above the threshold), not a demand forecast —
your "reasoning" text MUST say so in plain terms (e.g. "rough estimate based on current stock and
this one sale, not a demand forecast — no sales history or lead time was available") so the human
approver reading it doesn't mistake it for something more rigorous than it is. Never state the
quantity with more confidence than that.
Respond with ONLY a JSON object using these exact keys:
{
  "shouldRestock": boolean,
  "quantity": number,   // 0 if shouldRestock is false
  "reasoning": string   // one sentence, must flag this as a limited-signal heuristic estimate
}
```

## User message

```text
Product: {productTitle}
Current stock (already reflects the sale below): {currentStock}
Low-stock threshold: {lowStockThreshold}
Units sold in the order that triggered this check: {quantitySold}
```

## Expected JSON output → `RestockDecision`

```ts
{ shouldRestock: boolean, quantity: number, reasoning: string }
```

## Notes

- **2026-09-04 hallucination-audit finding, partially fixed**: `quantity` is
  computed from only 3 numbers with no sales-velocity or lead-time signal —
  a real gap, since the confident-sounding `reasoning` text is exactly what
  a human approver reads to decide whether the number is trustworthy. A real
  velocity signal wasn't a quick/low-risk addition (`restock-check.ts` has no
  order-history query today, and `store_orders.items` is a jsonb array with
  no dedicated line-items table to join against cheaply) — so this was
  addressed by making the model say plainly, every time, that its quantity
  is a limited-signal heuristic rather than a forecast (see the prompt
  above), and `maxTokens` was bumped 200→300 to give that longer required
  caveat room. A follow-up with real velocity data would still be a more
  complete fix.
- `currentStock` already reflects the triggering sale (the platform
  decrements stock on order recording, before this check ever runs) — it is
  **not** a pre-sale value to subtract `quantitySold` from.
- A `true` decision is never applied directly: `restock-check.ts` calls
  `requestApproval()` with the recommendation and notifies via
  `alertRestockRecommended()`. A human approving that pending row is what
  actually adjusts `products.stock` (see
  `app/api/admin/approvals/[id]/route.ts`'s `"inventory.restock"` case).
