# Analytics agent (text-to-SQL)

| | |
|---|---|
| **Source file** | `packages/ai/src/agents/analytics-agent.ts` |
| **Function** | `createAnalyticsAgent()` |
| **Called from** | `packages/ai/src/agents/orchestrator.ts`'s `runOrchestrator()`, when the router classifies a message as `"analytics"` |
| **Role → model** | `workhorse` (via `createChatModel`) — do not trust "Claude Sonnet" as current fact; confirmed live to have moved to other vendors more than once (see `merchant-chat-edit-and-pages.md`'s Notes) — verify against the live gateway |
| **Temperature** | 0.2 |
| **Reasoning effort** | `"none"` (passed via `createChatModel`'s `modelKwargs`) — see `merchant-chat-edit-and-pages.md`'s Notes: a reasoning-capable model behind this role can otherwise spend its whole token budget "thinking" and return empty content |
| **Max tokens / timeout** | 1500 / 20000 ms — added 2026-09-04, see Notes |
| **Framework** | LangGraph `createReactAgent` |
| **Fallback** | None of its own — a failure surfaces as the orchestrator's generic "couldn't put together a clear answer" reply (as of 2026-09-04, only after one retry — see `merchant-orchestrator-router.md`) |

Turns a merchant's question about sales/orders/performance into a read-only
SQL query and explains the result in plain language.

## Prompt

```text
You are EcomAI's analytics agent. Answer questions about sales, orders, and store performance by writing a read-only SQL query against the platform database via run_sql_query, then explaining the result in plain language with real numbers. Always filter by the tenant/store id given in the question — never return figures across stores that aren't the one being asked about.
Before explaining a result, check it first: if run_sql_query returns zero rows, or a string starting with "Error:", say plainly that the query didn't return an answer — never state a number like "$0" or "0 orders" as if it were a real, verified result just because the query came back empty or failed. Also sanity-check that the row count and shape match what you expected (e.g. a single-row/single-value result for a total, not an empty set or a pile of unrelated columns) before asserting any number as fact — an unexpected shape usually means the query needs fixing, not that you've found the answer.
```

## Tools available

| Tool | Source | Purpose |
|---|---|---|
| `run_sql_query` | `packages/ai/src/agents/tools/supabase-query-tool.ts` | Read-only (`SELECT`/`WITH`) SQL against `stores`, `store_orders`, `store_products`, `products`, `suppliers`, `orders`, `order_items` — description enriched 2026-09-04 with real columns and each table's tenant-scoping column (see Notes) |

## Notes

- **2026-09-04 hallucination-audit fix**: previously had no instruction for
  an empty or errored `run_sql_query` result — told to "explain the result
  in plain language with real numbers" unconditionally, so a subtly wrong
  filter returning 0 rows, or the tool's own `Error: ...` string, could be
  presented as a real "$0 in sales" rather than "the query didn't return an
  answer." Fixed with the escape-hatch paragraph quoted above (mirrors
  `merchant-business-advisor.md`'s equivalent instruction). Also added the
  same generous `maxTokens`/`timeoutMs` mitigation for the shared
  `workhorse`/`reasoning` empty-content bug that the other agents already
  carry, since this one had only `reasoningEffort: "none"` and nothing else.
- `run_sql_query`'s own tool description was enriched the same day — it used
  to list only bare table names with no columns, joins, or which column
  scopes each table to a tenant, raising the odds of a wrong-but-plausible
  join path. Now includes real columns and the tenant-scoping column per
  table (sourced from `packages/db`'s types and migration comments).
- The tenant/store filter is enforced by the *prompt*, not the database role
  — the read-only Postgres role has no row-level tenant restriction of its
  own. The context message the orchestrator prepends (see
  `merchant-business-advisor.md`'s "injected context") is what actually
  supplies the store id to filter by.
- Shares the exact same SQL-execution guard
  (`packages/ai/src/mcp/supabase-query.ts`) as the Supabase MCP server —
  regex-gated to `SELECT`/`WITH` only, capped at 100 rows (hard max 200).
