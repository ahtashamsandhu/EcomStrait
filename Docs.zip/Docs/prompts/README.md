# AI prompt reference

One file per AI prompt in the codebase — the exact system prompt text, the
model role it runs on, its call parameters, and its fallback behavior. This
is documentation of what's actually in the code, not a spec of what it
should be: it exists so a prompt can be reviewed, audited, or tuned without
reading every `.ts` file that calls `chat()`.

See `Docs/ai-architecture.png` (source: `ai-architecture.dot`) for how these
fit together, and `Docs/AI-Native-Migration-Plan.md` / `AI-Native-Manual-Setup.md`
for the gateway/role/vendor setup behind all of them.

## ⚠️ Keep this in sync

**Whenever a system prompt string changes in code, update its file here in
the same change** — same commit/PR, not a follow-up. A stale prompt doc is
worse than no doc: it looks authoritative and lies. Each file's prompt block
should be copy-pasteable back into the source if it were ever lost.

If a prompt is renamed, moved, or removed, rename/remove its file to match.
If a genuinely new AI prompt is added anywhere in the codebase, add a new
file here following the same template, and link it below.

## Index

### apps/merchant

| File | What it does | Role |
|---|---|---|
| [merchant-store-builder-converse.md](merchant-store-builder-converse.md) | Builder chat that decides what to ask next | workhorse |
| [merchant-store-plan-generate.md](merchant-store-plan-generate.md) | Idea + products → full store plan | workhorse |
| [merchant-chat-edit-and-pages.md](merchant-chat-edit-and-pages.md) | Post-launch/builder EcomAI chat — field edits + page create/update/delete | workhorse |
| [merchant-blog-draft.md](merchant-blog-draft.md) | Topic → full blog post | workhorse |
| [merchant-business-advisor.md](merchant-business-advisor.md) | "Ask my Store" advisor agent (tools + RAG) | reasoning |
| [merchant-analytics-agent.md](merchant-analytics-agent.md) | Text-to-SQL sales/orders agent | workhorse |
| [merchant-orchestrator-router.md](merchant-orchestrator-router.md) | Classifies advisor vs. analytics (inside the specific-store advisor) | fast-cheap |
| [merchant-cofounder-chat.md](merchant-cofounder-chat.md) | Dashboard co-founder — orchestrator with real tools (suggest/build/launch/edit a store, delegate to the Business Advisor) | reasoning |
| [merchant-category-content.md](merchant-category-content.md) | Cached AI copy for category pages | fast-cheap |
| [merchant-restock-agent.md](merchant-restock-agent.md) | Restock yes/no + quantity, on every order | fast-cheap |

### apps/supplier

| File | What it does | Role |
|---|---|---|
| [supplier-product-enrichment.md](supplier-product-enrichment.md) | Product title → description/SEO/price suggestion | workhorse |
| [supplier-cofounder-chat.md](supplier-cofounder-chat.md) | Dashboard co-founder chat (snapshot-grounded, no tools) | reasoning |

### apps/website

| File | What it does | Role |
|---|---|---|
| [website-ask-ecomai.md](website-ask-ecomai.md) | Marketing-site FAQ chatbot | workhorse |
| [website-business-plan-simulator.md](website-business-plan-simulator.md) | Idea → simulated business plan | workhorse |
| [website-niche-kb-embeddings.md](website-niche-kb-embeddings.md) | Niche KB → `ai_embeddings` (no chat prompt — ingestion only) | embeddings |

### Shared (packages/ai)

| File | What it does | Role |
|---|---|---|
| [shared-chat-memory-summary.md](shared-chat-memory-summary.md) | Rolling conversation summary for every persisted user-to-agent chat (merchant Co-Founder, supplier Co-Founder, Store Builder) | fast-cheap |
