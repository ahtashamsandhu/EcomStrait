# Product enrichment (supplier)

| | |
|---|---|
| **Source file** | `apps/supplier/src/lib/ai.ts` |
| **Function** | `enrichProduct(input)` |
| **Role → model** | `workhorse` — do not trust "Claude Sonnet" as current fact; confirmed live to have moved to other vendors more than once (see `Docs/prompts/merchant-chat-edit-and-pages.md`'s Notes) — verify against the live gateway |
| **Temperature** | 0.6 |
| **Max tokens** | 500 |
| **Response format** | JSON object |
| **Reasoning effort** | `"none"` — see `Docs/prompts/merchant-chat-edit-and-pages.md`'s Notes: a reasoning-capable model behind this role can otherwise spend its whole token budget "thinking" and return empty content |
| **Timeout** | 8000 ms |
| **Fallback** | `presetEnrichment(input)` — a template description + a wholesale-price × 1.8 markup, used when the gateway isn't configured, `title` is empty, or the call fails |

Suggests listing copy for a wholesale product a supplier is adding — the
supplier can edit or accept it before publishing.

## System prompt

```text
You are EcomAI, helping a wholesale supplier list a product.
Write concise, honest, conversion-friendly copy. No hype, no emojis.
Respond with ONLY a JSON object using these exact keys:
{
  "description": string,        // 2-3 sentences
  "seoTitle": string,           // <= 60 chars
  "seoDescription": string,     // <= 155 chars
  "suggestedRetailPrice": number // a sensible retail price, or 0 if unknown
}
```

## User message

```text
Product: {title}[ · category: {category}][ · wholesale price: ${wholesalePrice}]
```

(Bracketed segments are only included when that field was provided.)

## Expected JSON output → `Enrichment`

```ts
{ description: string, seoTitle: string, seoDescription: string, suggestedRetailPrice: number | null, source: "groq" | "preset", tokensUsed: number }
```

## Notes

- Each field falls back individually to `presetEnrichment()`'s value if the
  model's response is missing or the wrong type — same per-field merge
  pattern used across every other structured-JSON prompt in this codebase.
- `suggestedRetailPrice` from the model is only used if it's a positive
  number; a `0` or missing value falls back to the wholesale-price-based
  preset calculation.
