# Niche KB → embeddings (ingestion, not a chat prompt)

| | |
|---|---|
| **Source file** | `apps/website/src/app/api/admin/seed-niche-kb/route.ts` |
| **Function** | `POST()` → `upsertEmbeddings()` (`packages/ai/src/rag/store.ts`) |
| **Role → model** | `embeddings` → Voyage AI `voyage-3` (via the AI Gateway) |
| **System prompt** | None — there is no chat completion here, only raw content embedded and stored |
| **Auth** | Gated by an `x-admin-secret` header matched against `SUPABASE_SERVICE_ROLE_KEY` |

Not a prompt in the chat-completion sense — included here because it's the
ingestion step that makes the niche KB retrievable by
`merchant-business-advisor.md`'s `search_knowledge_base` tool. One-off /
re-run-on-demand: not wired into any build step, invoked by hand after
editing `apps/website/src/content/niches.ts`.

## Content embedded per niche (`source_type: "niche_kb"`)

```text
Niche: {n.label}
Keywords: {n.keywords.join(", ")}
Margin: {n.margin[0]}-{n.margin[1]}%
Suppliers: {n.suppliers[0]}-{n.suppliers[1]}
Monthly revenue: ${n.monthlyRevenue[0]}-${n.monthlyRevenue[1]}
Product ideas: {n.productIdeas.join(", ")}
Typical countries: {n.countries.join(", ")}
```

`source_id` is the niche's `slug` — re-running the seed after editing a
niche replaces its existing vector (upsert on `(tenant_id, source_type,
source_id)`) rather than accumulating duplicates.

## Notes

- Stored under `GLOBAL_TENANT_ID` (a sentinel UUID, never a real tenant) —
  shared content every tenant's Business Advisor can retrieve, not scoped to
  one store.
- Retrieved via `retrieve()` (`packages/ai/src/rag/retrieve.ts`), which
  embeds the *query* with the same `embeddings` role and does a cosine
  search via the `match_ai_embeddings` Postgres RPC.
