# Store Builder — plan generation

| | |
|---|---|
| **Source file** | `apps/merchant/src/lib/ecomai.ts` |
| **Function** | `generateStorePlan(answers, productTitles)` |
| **Role → model** | `workhorse` — routed to Gemini on 2026-09-02 (depleted credits, see Notes), then repointed to DeepSeek the same day; treat the documented vendor mapping in `Docs/AI-Native-Manual-Setup.md` as unverified until the gateway config is checked directly |
| **Temperature** | 0.7 |
| **Max tokens** | 900 |
| **Response format** | JSON object |
| **Reasoning effort** | `"none"` — added the same day `workhorse` moved to DeepSeek: that model spent its whole token budget "thinking" and returned empty content on some prompts otherwise (see Notes) |
| **Timeout** | 12000 ms |
| **Retries** | 1 retry on failure (2 attempts total) before giving up — added 2026-09-02, same principle as `askCoFounder`'s retry: a merchant's whole storefront content rides on this one call |
| **Fallback** | `presetPlan(answers)` — deterministic template, used when the gateway isn't configured, the niche is too short, or both attempts throw |

Called once the builder conversation (`converseBuilder`) reports `done`, or
directly with `useSelected` products from Find Suppliers — turns the
gathered niche/audience/products into the actual `StorePlan` the storefront
renders.

## System prompt

```text
You are EcomAI, building an online store for an entrepreneur.
Given a business idea and their selected products, return a concise, on-brand
store plan. Warm, confident, no hype, no emojis in text fields.
Respond with ONLY JSON using these exact keys:
{
  "storeName": string,
  "tagline": string,
  "brandColors": string[],      // 3 hex colors
  "heroHeadline": string,
  "heroSub": string,
  "about": string,              // 2-3 sentences
  "collections": string[],      // 3-5 names
  "seoTitle": string,            // <= 60 chars, so a search result never truncates it
  "seoDescription": string       // 120-155 chars — same convention apps/supplier/src/lib/ai.ts uses
}
```

## User message

```text
Business idea: {describeIdea(answers)}
Selected products: {first 20 product titles, comma-separated, or "(none yet)"}
```

`describeIdea()` builds one line from the structured answers — e.g.
`"Business: shoes. Customers: Pakistan. Style: minimal. Preferred name:
G4Shoes"` — omitting whichever of audience/styleKeyword/storeName weren't
given. This concatenated line is fine as *context for the model*; see Notes
for why it must never again be handed to the deterministic fallback as-is.

## Expected JSON output

The nine keys listed in the system prompt. Any missing/invalid field falls
back to `presetPlan(answers)`'s value for that field individually — this is
a per-field merge, not an all-or-nothing response.

## Notes

- **`seoTitle`/`seoDescription` length, added 2026-09 (Ahrefs Site Audit —
  "title too long" / "meta description too short/too long" flagged across a
  live storefront)**: the prompt now asks for `<= 60` / `120-155` chars,
  matching `apps/supplier/src/lib/ai.ts`'s `enrichProduct` convention. This
  is belt-and-suspenders, not the actual guarantee — a length instruction in
  a prompt is a request, not an enforcement, and this same gap existed
  identically in `presetPlan()`'s deterministic fallback (never prompt-based
  at all). The real guarantee is in `storefrontMetadata()`
  (`apps/merchant/src/lib/storefront-seo.tsx`): it clamps every title/
  description to range — truncating an over-long one, and appending a
  generic store-named closer to a too-short one — for every storefront page,
  regardless of whether the text came from this prompt, its fallback, or a
  future page type that forgets to think about length at all. Tightening
  this prompt only reduces how often that safety net has to do the work.
- `brandColors` is capped to 3 entries, `collections` to 5, regardless of
  what the model returns.
- Successful AI output is tagged `source: "groq"` on the plan (a legacy
  label from the pre-gateway implementation — it means "AI-generated", not
  literally Groq); the preset fallback is tagged `source: "preset"`.
- **Real bug this fixed**: `generateStorePlan` used to take one pre-joined
  `idea: string` (the same `describeIdea()` line now built internally), and
  `presetPlan(idea)` interpolated that *whole line* verbatim into the
  tagline, hero headline, and about text — fine back when `idea` was a
  short phrase a merchant typed directly, broken once the conversational
  builder started assembling it from separate niche/audience/style/name
  answers. A merchant's hero text read, verbatim: "Discover Business:
  Shoes. Customers: Pakistan and my brand name g4shoes. Preferred name:
  g4shoes" — because the AI call fell back to preset and the preset
  template had no separate notion of "niche" vs. "the whole answer set."
  Fixed by taking the structured `PlanAnswers` directly and having
  `presetPlan` build only from `answers.niche` (+ `answers.storeName` for
  the store name) — never the full concatenated line. This applies whether
  the *entire* call fell back (gateway down) or just one field did (model
  omitted a key and the per-field merge above pulled from `presetPlan`).
- **Root cause behind why the fallback fired at all, found investigating
  this report**: the gateway's `workhorse` **and** `fast-cheap` roles were
  returning `429 RESOURCE_EXHAUSTED` from a Gemini backend — "Your
  prepayment credits are depleted" — confirmed via a direct curl to
  `ai-gateway.ecomstrait.com` with no app code involved. `reasoning` and
  `embeddings` were unaffected (different vendor accounts). This is a
  billing issue on whatever Google AI Studio project backs those two role
  aliases in `litellm_config.yaml` — needs prepaid credits topped up there
  (or the alias repointed at a funded provider) to actually restore
  AI-generated content; the fix in this file only makes the *fallback*
  honest, it doesn't restore AI generation while credits stay depleted.
- **Third finding, same day**: `workhorse` was then repointed at DeepSeek —
  which turned out to also be a reasoning-capable model, and hit the exact
  same "spent the whole token budget thinking, returned empty content"
  failure other `workhorse` call sites did (see
  `merchant-chat-edit-and-pages.md`'s Notes for the full incident and the
  fix, `reasoningEffort: "none"`, applied here too).
