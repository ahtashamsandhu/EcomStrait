# AI-Native Migration — Manual Setup Checklist

Companion to `AI-Native-Migration-Plan.md`. Everything here is an account,
infra, or dashboard step — not code — needed before or during each phase.
Ordered to match the plan's phases.

---

## Before Phase 1 — Gateway

1. **Anthropic API key** — console.anthropic.com → create a key. This backs
   the `reasoning` and `workhorse` roles initially.
2. **Deploy the LiteLLM proxy.** Pick one host (Railway or Fly.io are the
   fastest to stand up; a small always-on VPS works too — it must not be a
   cold-start serverless function, since agents call it synchronously).
   - Use the official `ghcr.io/berriai/litellm` Docker image.
   - Write `litellm_config.yaml` with the four role aliases pointing at real
     models, e.g.:
     ```yaml
     model_list:
       - model_name: reasoning
         litellm_params: { model: claude-opus-latest, api_key: os.environ/ANTHROPIC_API_KEY }
       - model_name: workhorse
         litellm_params: { model: claude-sonnet-latest, api_key: os.environ/ANTHROPIC_API_KEY }
       - model_name: fast-cheap
         litellm_params: { model: claude-haiku-latest, api_key: os.environ/ANTHROPIC_API_KEY }
       - model_name: embeddings
         litellm_params: { model: voyage-3, api_key: os.environ/VOYAGE_API_KEY }
     ```
   - Generate a **proxy master key** (LiteLLM's own auth) — this becomes
     `AI_GATEWAY_API_KEY`. It is not any vendor's key; rotating a vendor key
     later never touches this value.
3. **Set env vars** in each app's `.env.local` and in the Vercel project
   settings for `apps/website` and `apps/merchant`:
   `AI_GATEWAY_URL`, `AI_GATEWAY_API_KEY`, `AI_MODEL_REASONING=reasoning`,
   `AI_MODEL_WORKHORSE=workhorse`, `AI_MODEL_FAST_CHEAP=fast-cheap`,
   `AI_MODEL_EMBEDDINGS=embeddings`.
   (Note: the app-side env values are the *role aliases* above, not vendor
   model names — the vendor mapping lives only in `litellm_config.yaml`.)
4. Leave `GROQ_API_KEY` set on the proxy host (not the apps) if you want a
   Groq option available as a future role target — no urgency to remove it.

## Before Phase 2 — RAG

5. **Enable `pgvector`** in the Supabase dashboard: Database → Extensions →
   search "vector" → Enable. (The migration also runs `create extension if
   not exists vector;`, so this is a safety net if the migration runs with a
   role that lacks extension-create privilege.)
6. **Voyage AI key** — dashboard.voyageai.com → create a key → set
   `VOYAGE_API_KEY` on the proxy host only.
7. Run the new migration: `supabase db push` (or paste
   `supabase/migrations/20260829120000_ai_native.sql` into the SQL editor if
   the CLI isn't linked in this environment).

## Before Phase 3 — MCP servers

8. **Create a read-only Postgres role** in Supabase for the Supabase MCP
   server's `query` tool, so a prompt-injected query can't write:
   ```sql
   create role ai_readonly login password '...';
   grant usage on schema public to ai_readonly;
   grant select on all tables in schema public to ai_readonly;
   ```
   Store this connection string as `MCP_SUPABASE_READONLY_URL` (merchant app
   only, server-side).
9. No new account needed for the Shopify MCP server — it reuses the existing
   Shopify app credentials already configured for `apps/ecom-strait-ai`.

## Before Phase 4 — Orchestrator

10. Nothing new to provision — this phase is pure code against what's already
    set up. Optional: create a **LangSmith** account (smith.langchain.com)
    and set `LANGCHAIN_API_KEY` + `LANGCHAIN_TRACING_V2=true` on the merchant
    app if you want traces there in addition to the `ai_agent_runs` table.

## Before Phase 5 — Guardrails

11. Decide who the initial **approver** is for pending `ai_approvals` rows
    (likely you, via a simple admin list page) — no external account needed,
    just confirm the workflow before it's built.

## Before Phase 6 — nothing manual

Revised from the original plan: n8n was evaluated and dropped for the
restock check (see Phase 6 in `AI-Native-Migration-Plan.md`) — it runs
in-process from the existing Shopify webhook handler instead. No new
account or infra needed for this phase.

## Before Phase 7 — Portability proof ✅ done

What we actually ran, for reference — a `reasoning-oss` alias in
`litellm_config.yaml`:
```yaml
  - model_name: reasoning-oss
    litellm_params:
      model: groq/openai/gpt-oss-120b
      api_key: os.environ/GROQ_API_KEY
```
This proves "swappable to an open-weight model," not "zero vendor
dependency" (it's still Groq-hosted). The stronger claim — genuinely no
vendor dependency — needs Ollama self-hosted (e.g. a second Railway service
in the same project, using private networking so it's never publicly
exposed) instead of a hosted-API alias. Not done here; worth doing later if
that specific claim ever matters.

**Two gotchas hit getting here, worth knowing before doing this again:**

1. **Check the account's real model list first**, don't guess a name:
   `curl https://api.groq.com/openai/v1/models -H "Authorization: Bearer $GROQ_API_KEY"`.
   Two guessed names failed in a row before this (`llama-3.1-8b-instant` no
   longer existed on the account; `groq/compound` resolves but only supports
   `json_mode`, not `tools` — useless for the Business Advisor's function
   calling, confirmed from that same list before wasting more time on it).
2. **LiteLLM's `<provider>/<model>` parsing needs both prefixes** when the
   model id itself contains a slash: `model: openai/gpt-oss-120b` alone gets
   read as "call OpenAI's real API" (wrong — gpt-oss isn't hosted there),
   not as part of a Groq model name. The correct form for a Groq-hosted
   model whose own id has a prefix is `groq/<groq's-own-model-id>` —
   here, `groq/openai/gpt-oss-120b`.

To re-run this check again later: temporarily set `AI_MODEL_REASONING` to
the alias (in `apps/merchant/.env.local` for a local test, or a preview
environment), re-run the Phase 4 Business Advisor acceptance test, then
revert — never leave the live `reasoning` alias pointed at a proof fixture.

---

## Ongoing / not tied to one phase

- **Cost monitoring:** check `ai_cost_ledger` weekly once Phase 4 is live;
  this is the data that justifies any future model swap decision.
- **Key rotation:** rotating `ANTHROPIC_API_KEY` or `VOYAGE_API_KEY` only
  ever touches the proxy host's env, never app code or app deploys.
- **Rate limits:** LiteLLM supports per-key rate limits/budgets — worth
  setting a hard monthly cap on `AI_GATEWAY_API_KEY` once real traffic starts,
  mirroring the existing "hard monthly cost cap" pattern already planned for
  Groq in `AI-Implementation-Plan.md`.
