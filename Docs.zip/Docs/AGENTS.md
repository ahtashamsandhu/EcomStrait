<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

# EcomStrait — project conventions

**Brand:** the company is **EcomStrait**; the AI product is **EcomAI**. Never
write "Bacho" or "Becho". URLs/paths/package name use lowercase `ecomstrait`.

**Stack:** Next.js 16 (App Router, Turbopack), React 19, TypeScript, Tailwind v4
(CSS-first `@theme` tokens — no `tailwind.config`), Framer Motion, Recharts, Lucide.

**Design tokens** (`src/app/globals.css`): `ink-*` (navy), `brand-*` (emerald),
`ai-*` (blue). Prefer `Section`/`SectionHeading` (`src/components/ui/section.tsx`)
for page rhythm, `Reveal` for scroll animation, `Button`/`Badge` primitives, and
the `Icon` registry (`src/components/ui/icon.tsx`) so content stays serializable.
Lucide 1.x has **no brand icons** — use `src/components/ui/social-icons.tsx`.

**Content:** all copy is typed data in `src/content/*` and `src/lib/site.ts`,
shaped to move to Sanity later. Add a page = new `src/app/<route>/page.tsx`
composing existing sections + `PageHeader` + `CtaBanner`; register it in
`src/lib/site.ts` nav and `src/app/sitemap.ts`.

**Verify** changes with `pnpm build` (typechecks + prerenders all routes).
