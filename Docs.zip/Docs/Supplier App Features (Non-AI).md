# Supplier App — Feature Summary (Non-AI)

Short summary of every supplier-facing feature and how it's built — deliberately **not**
exhaustive detail. AI-powered features (Co-Founder chat, AI product-description/price
enrichment) are covered separately in `Docs/ECOMAI Team members and their Abilities.md`; only
the plain, non-AI mechanics are here.

---

## 1. Auth & Onboarding

- **Signup/Login** — email + password or Google OAuth, same shape as the merchant app.
- **5-step onboarding wizard**: (1) Business info (name, type, contact, phone, country/city,
  website), (2) Business details (years in business, catalog size, manufacturing type, product
  categories, description), (3) Documents (business registration, national ID, address proof
  required; tax registration and logo optional), (4) Fulfilment details (inventory size, lead
  time, MOQ, shipping regions), (5) Review + accept terms → submit.
- **Approval workflow**: `pending` → `in_review` → `approved` (or `rejected`). An admin can also
  return an application to `pending` with specific reasons for the supplier to fix. Every page
  except Settings/Help is blocked until approved.
- Verification is tracked across 5 levels (email, phone, documents, manual review, badge) — feeds
  both the onboarding progress bar and the Quality Score (§10).

## 2. Product Form

- **Fields**: title* (only required field), description, category, SKU, wholesale price, retail
  price (MSRP), MAP (minimum advertised price — a price floor merchants can't undercut), stock,
  status (draft/published), images (multi-upload), SEO title/description, sizes (free text, not a
  structured variant system), material, fit note.
- Editing price/title/images on a published product automatically pushes the change out to every
  store already selling it (Shopify stores get updated live; custom-website stores' prices
  cascade too).
- Adding a new product is capped by the plan's catalog-size limit (§9).

## 3. CSV Import

- Own lightweight CSV parser (no external library). Auto-detects and maps columns for title
  (only required column), description, category, SKU, wholesale/retail/MAP price, and stock —
  each mapping is overridable before import, with a live preview of the first 5 rows.
- Imported products always land as **drafts**, never auto-published, and are inserted in one
  all-or-nothing batch (capped by the same catalog-size limit as manual adds).

## 4. Catalog Management

- Search matches **title, category, or SKU**. No sort option — newest first only.
- Row actions: publish/unpublish toggle, edit, delete.
- Bulk actions (multi-select): publish, unpublish, set/adjust stock, delete.

## 5. Inventory

- A stock-focused view separate from Catalog: available (stock − reserved), reserved, editable
  stock and low-stock threshold per product, and a computed status badge (Out of stock / Low
  stock / In stock).
- Edits are staged and saved in one batch; every stock change is written to an audit log
  (`inventory_adjustments`) and shown in a "recent activity" panel.

## 6. Requests

Two distinct things share this area:

- **Product Requests** (`/requests`) — a merchant asking the supplier to fulfil a specific
  quantity of named products directly (more like a quote/procurement inquiry than a storefront
  listing). Has its own message thread with the requester. Accepting one automatically creates a
  real order.
- **Listing Requests** (`/listings`) — the actual "a merchant wants to sell one of my products on
  their store" queue (this is what §2 in the merchant doc calls "Add to store"). Approve pushes it
  live (and to Shopify, if that store is Shopify-based); decline can include a reason. An
  "approve all" bulk action exists.

## 7. Orders

- Statuses: Processing → Shipped → Delivered (or Processing → Cancelled). Only orders whose
  wallet deduction has already succeeded are shown — a COD order the supplier's wallet can't yet
  cover stays hidden until they top up (§8).
- Search matches store/customer name; active orders always sort to the top.
- Bulk status changes are only offered when every selected order can make the same move.
- Cancelling an order automatically reverses its earlier COD wallet deduction.

## 8. Wallet

- Covers the merchant's margin + platform fee on **Cash-on-Delivery** orders, deducted from the
  supplier's wallet up front (the supplier keeps the cash collected at delivery).
- Top up via Stripe Checkout; an order that couldn't be covered is held and released automatically
  once a top-up covers it — same ledger mechanism as the merchant wallet.

## 9. Billing / Entitlements

- 4 plans (Free/Basic/Premium/Full) gate: daily AI token budget, and **catalog size** (100 / 500 /
  10,000 / unlimited products).
- Same Stripe Checkout + billing-portal flow as the merchant app; plan state refreshes live from
  Stripe on every page load.

## 10. Quality Score

- A 0–100 composite, recomputed on every Analytics page load: profile completeness, verification
  level, catalog depth, inventory health (in-stock ratio), response rate, and acceptance rate on
  requests. Shown as a tier (Excellent/Good/Fair/Needs work) on the dashboard and to admins.

## 11. Settings

- Read-only account and business-profile info. Owner-only **team management**: invite staff by
  email, remove them; an invite auto-links the moment that person signs in. No password-change or
  notification-preferences UI.

## 12. Admin Section

- Separate `/admin` login, restricted to accounts with an admin role.
- **Suppliers** — review and approve/reject/return applications, view uploaded documents, verify
  phone manually, seed a test product request.
- **Users** — list every account, search, change platform roles (can't self-demote).
- **Shopify stores** — manage the pool of pre-provisioned Shopify dev stores: password-lock
  status, ownership-transfer tracking, flag stores needing reconnection, pool-health metrics.

## 13. Other Pages

- **Dashboard** — status banner, key stat tiles (open requests, published products, low stock,
  quality score), verification checklist.
- **Analytics** — combined revenue and catalog/quality dashboard: revenue trend, orders-by-status,
  COD vs. prepaid mix, top products, inventory breakdown, requests trend.
- **Help** — static FAQ plus a "contact support" form that emails the support address.
