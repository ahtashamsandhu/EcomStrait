# EcomAI Team Members and Their Abilities

Two chat surfaces a merchant actually talks to — **Store Builder** and **Co-Founder** — plus a
roster of specialists working behind them, some reachable only through those two chats, some
running silently with no chat interface at all. This document covers each member's abilities and,
in Part 4, the mechanics of how they actually work together.

This is the plain-language overview — *why* each ability exists and what it's for. For the exact
system prompt text, model role, and call parameters behind any of it, see `Docs/prompts/` (one
file per AI prompt in the codebase, kept in sync with the code itself — this doc links to the
relevant file at the end of each section below).

---

# Part 1 — ECOMAI Store Builder

Store Builder is scoped to one job: build and edit *this store*. It never fields general business
questions anymore — those go to Co-Founder (see Part 2) — but within its own scope it now does
more than it used to: it can suggest what to sell and audit SEO, not just take dictation.

## 1. Pre-Launch: Build a Store from a Conversation

* **Conversational discovery, not a script** — No fixed question order. The model decides what to
  ask next (niche, audience, style, name), skips what it already knows, and stops once it has
  enough — typically 2–4 replies. Every message is classified first as an **answer**, a
  **product request**, or **something else** (a genuine question, confusion, off-topic) — see Part
  4 for why that classification exists and what breaks without it.
* **Never silently guesses what to sell** — If a merchant delegates that specific decision ("you
  tell", "surprise me", "I don't know"), the AI does not invent a niche and race ahead to building
  a store around its own guess. It shows real, ranked product suggestions instead (see below) and
  waits.
* **Starts from an existing product basket** — Arriving with products already selected via Find
  Suppliers (including "Start a new store" from an existing store's catalog view) builds around
  those exact products. Otherwise it auto-picks ~8 published products matching the stated niche.
* **One-shot store plan generation** — store name, tagline, 3 brand colors, hero headline +
  subheading, about text, 3–5 collection names, SEO title + description.
* **Six premium themes** — inferred from a style keyword ("luxury" → Noir, "playful" → Bloom,
  etc.) or pre-selected from the theme gallery.
* **Two selling paths** — an EcomAI-hosted website (optional custom domain) or a Shopify store
  (auto-provisioned theme + product push on launch).
* **Draft-safe** — autosaves continuously, remembers an unlaunched draft across sessions, warns
  before it expires, and Discard genuinely starts over (a hard page reload, not a soft navigation —
  the fix for a real bug where discarding left every field, the chat, and the preview still on
  screen).

*Prompt reference: `Docs/prompts/merchant-store-builder-converse.md`.*

## 2. Product Suggestion Agent (new)

Available in **both** pre-launch building and post-launch editing — the same capability, two
entry points.

* **Triggered by asking** — "what should I sell", "show me some products", "what's selling well",
  "high margin options" — at any point in the conversation, not just the opening question.
* **Real ranking, not a guess** — deterministic, SQL-driven: platform-wide units sold (every
  merchant, every supplier — never one merchant's own numbers) combined with margin
  (retail − wholesale). No LLM involved in the ranking itself, only in presenting it — same split
  as the Analytics Agent (SQL for facts, the model narrates).
* **Falls back gracefully** — a niche too new to have platform sales history yet falls back to the
  published catalog ranked by margin; a freeform niche phrase that matches no product's exact
  category (e.g. "women's garments" vs. whatever the catalog's actual category strings are) falls
  back to genuine platform-wide results rather than returning nothing.
* **Renders as real product cards** with a working **Add** button — pre-launch, this both updates
  the live preview *and* writes to the same `selected_products` basket Find Suppliers uses (so the
  eventual build step actually includes it, not just the on-screen preview); post-launch, it's a
  real listing request.

*Prompt reference: `Docs/prompts/merchant-store-builder-converse.md` (pre-launch) and
`Docs/prompts/merchant-chat-edit-and-pages.md` (post-launch). Also reachable from Co-Founder as
the `suggest_products` tool (Part 2) — same ranking function, a second entry point.*

## 3. SEO Advisor (new)

Not a separate chat or a separate agent — the *existing* edit intent, made smarter. The model
already sees a store's current `seoTitle`/`seoDescription`/`about`/`collections` on every message,
so this needed no new plumbing:

* **Asking "how's my SEO" gets real analysis** — concrete gaps called out by name (missing or
  too-short meta description, a generic title, thin about text), not a vague "looks fine."
* **Can propose the fix in the same turn** — improved `seoTitle`/`seoDescription` through the exact
  same field-edit mechanism as any other change, when there's enough context to write something
  real; asks what to focus on (a product line, a differentiator) rather than inventing generic
  keywords when there isn't.

*Prompt reference: `Docs/prompts/merchant-chat-edit-and-pages.md`. Also reachable from Co-Founder
as part of the `edit_store_content` tool (Part 2) — same underlying function, a second entry
point; a merchant can ask for an SEO pass from either chat.*

## 4. Post-Launch: Edit a Live Store Entirely by Chat

* **Direct field edits in plain English** — "change the hero text to…", "use a deep green",
  "shorten the tagline." Supported fields: store name, tagline, brand colors, hero headline +
  subheading, about text, collections, SEO title/description, announcement bar, footer text.
  Applied immediately and auto-propagated (EcomAI-hosted stores update live; Shopify stores
  re-sync).
* **Whole custom pages** — create, update, or delete a standalone page (Contact Us, FAQ,
  Shipping…). Writes real content from facts already in the conversation; never invents contact
  details or policies, asks instead of guessing.
* **Honest about its limits, mostly** — can't touch images/video/content sections (that's the
  separate Content Editor) or anything outside those fields. When it declines, it names the *real*
  dashboard section, never an invented one (a real bug this fixed: it used to say "Navigation
  section" and "Products section," neither of which exist). **Known open gap**: naming the right
  section isn't the same as knowing that section's actual capabilities — it has been observed
  telling a merchant that "Selected Inventory" manages product titles/images/sizes/shipping notes
  (it only supports viewing, price-editing, and removal) and that a "Best Sellers" section can be
  "added under Content" (no such section type exists). Investigated, not yet fixed.
* **No longer escalates questions to a business advisor.** This moved entirely to Co-Founder (Part
  2) — a genuine business question asked here now just gets a plain, honest reply pointing at the
  right place to ask it, never a tool-using agent inventing instructions for a platform this store
  isn't even on (the original bug report that started this whole redesign: a non-Shopify store
  being told to go into "Shopify Admin").
* **Version history** — every edit snapshots the prior look first; anything is restorable.

*Prompt reference: `Docs/prompts/merchant-chat-edit-and-pages.md`.*

## 5. Around the Edges

* AI-drafted blog posts from just a topic (separate screen, same writing engine — see Part 3).
* Auto-generated, cached SEO copy for storefront category pages.
* Full JSON-LD structured data, sitemap, and robots.txt generated automatically.

---

# Part 2 — EcomAI Co-Founder

Co-Founder is the dashboard-wide "ask about the business" chat — and, since it became an
orchestrator, the one place a merchant can also discuss an idea end-to-end and have it actually
happen: pick products, build a store, tune its SEO, launch it, or drill into one specific store's
real numbers, all in one conversation, without switching to Store Builder.

## 1. What It's Grounded In

Before every message, the server builds a fresh snapshot of real business data and hands it to the
model as plain text — the model never queries anything itself for a broad question (a
*specific-store* question is different; see §3 below). The snapshot is now cached for 15 minutes
(recomputing revenue/order/customer aggregation on every single message was real, repeated work)
and fails open — a cache problem degrades to computing live, never to a broken reply.

## 2. Merchant Co-Founder: What's in the Snapshot

| Category | What's included |
|---|---|
| Stores | Total vs. live count, names |
| Revenue | All-time total, order count, avg order value, units sold (paid/processing/fulfilled) |
| Revenue by store | Per-store breakdown |
| Top products | Top 6 by revenue |
| Wallet | Current balance |
| Credit holds | Orders on hold for insufficient credits — count + value |
| Customers *(estimated)* | Total, repeat count/%, average lifetime value |
| Traffic mix *(estimated)* | % by channel, last 30 days |
| Store design | Theme + brand colors per store |
| SEO gaps | Concrete, per-store — the same checks the SEO Advisor uses |
| Platform top-sellers | Real, platform-wide — market context, never presented as this merchant's own numbers |
| Plan | Current tier + remaining daily AI token budget |

**On the two "estimated" fields**: there's no real traffic/referrer tracking or customer-profile
system yet — deliberately built with the real shape those will eventually have, but populated for
now by a synthetic generator that runs on every order (see Part 4). Co-Founder reasons from them
freely for strategy; it only ever flags them as estimates if asked point-blank for the exact raw
number.

## 3. Supplier Co-Founder: What's in the Snapshot

Financial performance (revenue, order volume), COD vs. prepaid mix, credit holds, catalog size and
stock levels, quality score and its contributing factors, request/inbox activity, top products by
revenue. All real — no synthetic fields on the supplier side today.

## 4. Orchestrator: One Agent, Six Tools

This is new. Co-Founder used to be a hand-coded router in front of two disconnected paths (a
pre-classification step deciding broad-vs-one-store *before* the model ever ran). It's now a
single tool-calling agent (LangGraph `createReactAgent`, the same primitive the Business Advisor
already used) that decides for itself, per message, whether it needs to look something up or
actually do something — and can chain several of these in one turn for a compound ask ("suggest
some products and build me a store around them" fires `suggest_products` then `build_store`
without the merchant having to ask twice):

| Tool | Delegates to | What it does |
|---|---|---|
| `list_my_stores` | — | This merchant's own stores — resolves "which store" for the others |
| `suggest_products` | **Product Consultant** | Real, ranked product picks (Part 1 §2) |
| `build_store` | **Website Builder** | Generates a plan and saves it as a real draft — never live on its own |
| `launch_store` | **Website Builder** | Promotes a draft to live — only when explicitly asked |
| `edit_store_content` | **Website Builder / SEO Advisor** | Field edits, SEO, or a whole custom page on an existing store (Part 1 §3/§4) |
| `ask_business_advisor` | **Business Advisor** | A deep, grounded answer about one specific store's real numbers (Part 3) |

A store built this way is a genuine, persisted draft the merchant can open and review — not
instantly live — mirroring how Store Builder's own chat already works (build → review → a
separate, explicit launch). Co-Founder will launch it in the same conversation if asked to, it
just doesn't default to that with zero chance to look at it first.

*Prompt reference: `Docs/prompts/merchant-cofounder-chat.md` (the orchestrator's own tools file,
`cofounder-tools.ts`, is linked from there) and `Docs/prompts/merchant-business-advisor.md` (what
`ask_business_advisor` delegates to).*

## 5. What It Can Actually Do

* **Answer open-ended questions** — "how do we grow," "what should I fix first" — reasoning over
  real data, never guessing.
* **Lead with something specific**, unprompted — an underperforming store, thin SEO, a slow
  product, a channel worth doubling down on — never generic advice that could apply to any store.
* **Actually do things, not just describe them** — suggest products, build a store around an idea,
  launch it, edit an existing one's content or SEO, all from the conversation itself.
* **Never just refuses.** Asked for something no tool here does (running paid ads, issuing a
  refund), it says so in one brief, warm line and immediately offers the closest real thing it can
  do instead — the merchant's own goal outranks a rigid "that's not supported."
* **Hold a conversation** — last 12 turns retained for follow-ups, including resolving "that store"
  or "it" against something built or discussed earlier in the same conversation.
* **Talk like an actual co-founder**, not a report — see Part 4 for exactly what that means and why
  it needed real prompt work, four times over.

## 6. Guardrails — What Still Doesn't Happen Without a Human

* **A new store is a draft until launched.** `build_store` never goes live on its own — the
  merchant either reviews it in Builder or tells Co-Founder to launch it explicitly.
* **A live Shopify storefront's own settings are never touched directly.** `ask_business_advisor`
  can *propose* a Shopify price or publish-status change through its own tools, but never apply
  one — a human approves it first, exactly as before (Part 4).
* **Never invents a number** — if something isn't in the snapshot or a tool's real result, it says
  so plainly rather than guessing.
* **Never talks about what it doesn't have**, as advice-hedging. A real bug report: early replies
  opened with "we're flying blind," "we don't have proper tracking yet" — accurate, and also
  exactly what a merchant doesn't want to hear from a co-founder. Fixed at both layers: the
  snapshot no longer states data gaps as facts to comment on, and the prompt forbids narrating the
  gap or gating a recommendation on infrastructure that isn't built. (This is a different rule from
  the "never just refuses" line above, deliberately — one is about hedging *advice*, the other
  about declining an *action*; conflating them would have undone this fix.)
* **Token-budget controlled** — checked before the model is ever called, same as everywhere else.
  Worth watching: this agent is markedly more expensive than the plain-completion version it
  replaced, since a compound request means several reasoning turns, not one.

## 7. Reply Format

Written for a chat bubble, not a memo: a short lead-in (what's actually going on), then — whenever
there's more than one concrete number or option — a short bulleted list with the key fact bolded
per line. Not forced into a list when a couple of plain sentences reads faster; never three-plus
dense paragraphs restating the same point.

## 8. Reasoning Performance

This role runs on a genuinely reasoning-capable model, which can spend real, variable time
"thinking" before it answers — a single reply taking 15–45 seconds is expected, not a bug, and a
compound request that chains several tools can take longer still (one reasoning turn per tool call
plus the final synthesis, not a single call). A real bug that *was* here: that same reasoning could
consume its entire token budget internally and return nothing at all, surfacing as "I couldn't
reach the AI advisor" even though the gateway had actually responded successfully. Fixed by capping
how much the model reasons before answering and giving it real headroom to still write the answer
afterward — confirmed fixed against the live gateway, including for the tool-calling version.

## 9. Core Product Principle

**Co-Founder is a grounded business-reasoning partner with real hands, not an autonomous agent
that acts on its own initiative.** It only ever acts on a direct, in-the-moment instruction from
the merchant themselves — the same standard Store Builder's own chat already operates under, just
now available from a second entry point. Its safety model: give it only fresh, real data; a new
store is always a draft until explicitly launched; a live Shopify storefront's own settings still
require human approval to change; never let it invent a number.

*Prompt reference: `Docs/prompts/merchant-cofounder-chat.md` and
`Docs/prompts/supplier-cofounder-chat.md` (supplier Co-Founder's own, still plain-completion,
persona); see Part 4 below for how the persona was arrived at.*

---

# Part 3 — Other Team Members

Reachable only through Store Builder or Co-Founder, or running with no chat interface at all.

**Business Advisor** — the tool-using specialist Co-Founder routes a specific-store question to
(Part 2 §4). Has real tools: a knowledge-base search, read-only SQL scoped to that one store, and
(for a Shopify store) live shop-status/shipping/location checks. Can *propose* a Shopify price or
publish-status change — never apply one; a human approves it first (Part 4).

**Analytics Agent** — the specialist Business Advisor's own router hands sales/orders/performance
questions to specifically ("what's my best-selling product," "how much did I make last week").
Writes its own read-only SQL, explains the result in plain language, strictly scoped to the one
store being asked about.

**Restock Recommendation** — fully automatic, no chat. Runs on every order: checks the product
against its low-stock threshold and decides whether to recommend a restock and how much. Never
restocks anything itself — only proposes, pending human approval.

**Category-Page Copy** — automatic. First real visit to a storefront category page generates a
short intro paragraph in the background; cached forever afterward, never regenerated, never slows
down the page a customer is looking at.

**Blog Draft Writer** — same writing engine as Store Builder, different screen. Topic in, full
draft out (title, excerpt, body, SEO fields); the merchant reviews and publishes it themselves.

**Product Enrichment** *(supplier app)* — when a supplier adds a product, suggests a description,
SEO title/description, and a retail price from the wholesale price. A suggestion to accept or edit,
never an automatic listing.

**Ask EcomAI** *(public website, no login)* — the marketing site's FAQ chatbot, grounded entirely in
a fixed FAQ list. Answers questions about the product itself; never presents a number as live data.

**Business-Plan Simulator** *(public website)* — the homepage's "type your idea, get a simulated
business" demo. Grounded in reference data for the matched niche; explicitly labeled a simulated
preview, never a real projection.

Prompt references, in the same order: `merchant-business-advisor.md` +
`merchant-orchestrator-router.md`, `merchant-analytics-agent.md`, `merchant-restock-agent.md`,
`merchant-category-content.md`, `merchant-blog-draft.md`, `supplier-product-enrichment.md`,
`website-ask-ecomai.md`, `website-business-plan-simulator.md` — all under `Docs/prompts/`.

---

# Part 4 — How They Actually Work Together

## The gateway: one call site, vendor-agnostic

Every single AI call in the codebase — Store Builder, Co-Founder, every specialist above — goes
through one shared client that talks to a self-hosted LiteLLM proxy, never a vendor SDK directly.
Code asks for a *role* (`reasoning`, `workhorse`, `fast-cheap`, `embeddings`); the proxy's own
config maps that to whatever real model is behind it. This is what let the underlying vendor be
swapped (twice, live) with zero app-code changes for most of it — and it's also where a real class
of bug turned up: a reasoning-capable model can spend its *entire* token budget on invisible
internal "thinking" and return nothing, which used to surface as a dead-looking chat. Fixed by
capping how much a role is allowed to reason before it has to answer, applied everywhere a role
doesn't need deep reasoning (which is almost everywhere — `workhorse`, in particular, never needs
it).

## Classify first, act second — and don't trust one mechanism alone

Both Store Builder's opening conversation and its edit chat work the same way: one model call
classifies the message's *intent* before doing anything else (an answer vs. a product request vs.
something else, in the builder; edit vs. page vs. suggest-products vs. question vs. unsupported, in
the edit chat) — mirroring the same successful pattern the shared orchestrator already used. That
classification is what lets a merchant say "show me some products" in the *middle* of answering
unrelated questions and actually get products, instead of the message being silently forced into
answering whatever was being asked.

Reliability mattered enough here that the highest-stakes cases aren't left to the model alone: a
merchant delegating "what to sell" on the very first reply is caught deterministically (a pattern
match, zero model calls, zero chance of the model just not doing it), and a keyword backstop
catches the clearest "show me products" phrasings even if the model's own classification misses —
which, measured directly, it did about a third of the time before the classification was
restructured to lead with an explicit type field, after which it was reliable in every test run.

## Co-Founder's orchestration, concretely

Unlike the classify-then-route pattern everywhere else in this document, Co-Founder doesn't
pre-classify a message at all anymore — it hands the whole thing to one tool-calling agent and
lets normal tool selection decide what's needed, including calling several tools in sequence for
one message. This is a deliberate, different choice from the "classify first" pattern above: the
earlier hand-coded router (a single fast-cheap classification deciding broad-vs-one-store *before*
the model ran) was replaced specifically because it couldn't express "look up a store, THEN act on
it" as one decision — collapsing that into a single reasoning agent with a `list_my_stores` tool is
what makes a compound, multi-step request like "pick some products and build me a store" possible
in one turn. If a tool call fails for any reason, the agent's own reasoning decides how to recover
(try something else, or explain the gap honestly) rather than a hard-coded fallback path.

## Guardrails: what needs a human, and what doesn't

Two different safety models coexist, by design, not by accident. A tool touching a **live,
external, customer-facing platform** — a Shopify price change, an inventory restock — never
executes directly: it creates a pending, reviewable proposal, and a human approves it before
anything actually changes. A tool touching **this store's own EcomStrait-side content** — building
a draft, editing a headline, launching a store — executes immediately, with no separate approval
step, because a merchant typing that instruction into a chat *is* the human approval, the same
standard Store Builder's own edit chat has always operated under; Co-Founder just inherited it once
it gained the same abilities. Every AI call anywhere also checks a per-tenant daily token budget
*before* the model is invoked, not after, so a runaway conversation can't spend past the cap it's
already over.

## The synthetic-data seam

Customer profiles and traffic-source data don't have a real collection pipeline yet. Rather than
leave Co-Founder with nothing to reason about until that's built, every real order generates a
plausible value for both — written into the same tables and shape a real tracking system will
eventually populate, each row explicitly marked as synthetic. The day real tracking ships, it
starts writing real rows into the same place, and nothing downstream — the snapshot, Co-Founder's
prompt, the caching layer — has to change.
