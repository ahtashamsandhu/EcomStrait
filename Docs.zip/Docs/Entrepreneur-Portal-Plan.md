# EcomStrait — Entrepreneur Portal & Shopify Automation (BETA plan)

> Scope: **BETA** — build the bases and a working end-to-end system to demo, not
> the full product. We improve and add features after. Supersedes the high-level
> `shopifystoreIntegration.md`. Companion to `Supplier-Portal-Plan.md` — same
> monorepo, shared packages, and it reuses the **supplier portal's Orders** as
> the fulfilment loop.

---

## 1. Locked decisions

- **Stack:** Supabase + Next.js 16 + **Inngest** (durable jobs/webhooks/sync).
  New app **`apps/merchant`** (the Entrepreneur Portal), reusing
  `packages/{auth,db,ui,config}`. AI = Groq/Llama behind our swappable interface.
- **Three build paths:**
  1. **Shopify + Shopify theme** — a real Shopify **development store** we build
     with EcomAI, populated with our supplier products.
  2. **Shopify + our custom theme** — same, but with an **EcomStrait theme built
     natively in Liquid** (uploaded via the Theme API).
  3. **Own website (our platform)** — **not** Shopify. Our own hosted storefront
     + checkout + orders + inventory, synced via **our APIs**; the user just
     **attaches their domain** (DNS).
- **Shopify model:** we're a Shopify Partner. EcomAI builds the dev store, lists
  our supplier products, and does a **two-way inventory sync** (+/-) with supplier
  stock. Customer orders are **recorded in our DB and routed to the supplier**
  (as a supplier Order) to fulfil. We then **transfer the store to the user**
  (they pay Shopify); **our app stays installed** for ongoing sync, EcomAI theme
  updates, and (later) EcomAI as a business consultant.
- **Billing:** FREE / BASIC $10 / PREMIUM $30 / FULL $100 per month; daily AI
  tokens 10K / 50K / 1M / 10M; store limits 1 / 2 / 10 / 50. **First 100 signups
  get all features free for one month.** Stripe.

---

## 2. Architecture (beta)

```
apps/merchant (Next.js)  ─ entrepreneur dashboard + build wizard + the SYNC ENGINE
apps/supplier            ─ suppliers (already built): catalog, inventory, ORDERS
apps/website             ─ marketing (already built): "Build a business" CTA
apps/ecom-strait-ai      ─ the Shopify app (React Router 7): OAuth, webhooks, embedded UI
packages/{auth,db,ui}    ─ shared Supabase auth, typed DB, design system
Supabase                 ─ Postgres + RLS, Auth, Storage (single source of truth)
Inngest                  ─ AI build pipeline, webhook processing, 2-way sync, cron
Stripe                   ─ subscriptions + first-100 promo
Groq                     ─ EcomAI engine (branding, copy, SEO, consultant)
Shopify Admin/Theme API  ─ dev-store build, Liquid theme, transfer
Our hosting              ─ Path-3 storefronts (subdomain in beta → custom domain)
```

**How the Shopify app plugs into the beta architecture (Next.js + Supabase +
Inngest):** the Shopify app is the *Shopify surface* (install + webhooks +
embedded UI); all business logic lives in our Next.js + Inngest + Supabase engine.

```
Shopify store ──install/OAuth──▶ apps/ecom-strait-ai
   │                                   │  afterAuth: POST shop + token + scopes (signed)
   │                                   ▼
   │                          apps/merchant  /api/shopify/connect ──▶ Supabase shopify_stores
   │
   └─ order/inventory/product webhooks ──HMAC──▶ apps/merchant /api/shopify/webhooks
                                                      │ send Inngest event
                                                      ▼
                                                   Inngest fn ──▶ Supabase (store_orders,
                                                      │             inventory) + supplier orders
                                                      ▼
                                                   Shopify GraphQL Admin API
                                                   (build/sync using stored token)
```

---

## 3. Plans, billing & token metering (beta)

- **Stripe** products/prices per tier; **Checkout** to subscribe; **Customer
  Portal** for changes. **First-100 promo** = FULL entitlements free for 1 month
  (trial or 100%-off coupon), tracked by a `promo_eligible` flag while a counter
  < 100.
- **Entitlements** as a typed constant in `packages/db` (tokens/day, store limit).
- **Token metering:** `usage_daily(user_id, date, tokens_used)`; a guard checks
  remaining before each AI call and records after; over-quota → upgrade prompt.
  Daily rollover is automatic (the quota is "today's row"). Store creation checks
  `stores_used < limit`. A **usage meter** shows on the dashboard.
- Beta simplification: run Stripe in test mode; promo + entitlements fully wired.

---

## 4. Entrepreneur dashboard IA (beta subset)

Overview · **Find Suppliers** · **Store Gallery** · **EcomAI Store Builder** ·
**Selected Inventory** · **Stores** · **Store settings** · **Theme** · **Orders**
· **Sales** · **Billing**. (Same `AppChrome` pattern as the supplier portal.)

---

## 5. COMPLETE FLOW — Entrepreneur: signup → live store

1. **Discover** — on the marketing site, "Build a business" → the merchant app
   signup.
2. **Sign up** — Supabase Auth (email/password or Google) → email verify →
   `profiles.role = 'entrepreneur'`.
3. **Choose a plan** — FREE/BASIC/PREMIUM/FULL. Stripe Checkout subscribes them
   (or, if within the first 100, the **free-month promo** grants FULL). Return to
   dashboard; entitlements active.
4. **Overview** — usage meters (tokens today, stores used), empty "no stores yet"
   with a "Build your first store" CTA.
5. **Describe the business** — EcomAI Store Builder: the user types their idea
   ("luxury candles for gifting"). EcomAI proposes a niche, positioning, and a
   starter product set (token-metered).
6. **Find Suppliers & Selected Inventory** — the builder pulls matching products
   from **our supplier catalog** (the supplier portal's published products). The
   user adds products to **Selected Inventory** (the working set to sell).
7. **Choose build path** — Shopify + Shopify theme · Shopify + our Liquid theme ·
   Own website (our platform). Store-limit checked against the plan.
8. **AI build** (Inngest pipeline, live "building" timeline, token-metered):
   branding → logo → homepage → pages (about/contact/FAQ/policies) → import
   selected products (titles/descriptions/SEO/images) → collections → navigation
   → footer → apply theme → publish → **READY_FOR_REVIEW**.
   - Paths 1–2 **claim the next `AVAILABLE` store** from the admin-seeded
     `shopify_stores` pool (→ `ASSIGNED` → `BUILDING`) and build via the
     Admin/Theme API.
   - Path 3 builds our storefront and deploys to **our hosting**.
9. **Review** — the user previews the generated store (live link).
10. **Go live:**
    - **Shopify (1–2):** "Go Live" → buy a Shopify plan (our referral) → we
      **transfer store ownership** → the user accepts in Shopify → status
      `ACTIVE`; **our app stays installed** for sync + EcomAI theme updates.
    - **Own website (3):** pick a subdomain (beta) or **attach a domain** → we
      deploy the storefront → the user adds a **DNS CNAME** to us → SSL issued →
      live.
11. **Selling** — inventory is **synced from the supplier** (two-way); customer
    orders flow into **Orders**; **Sales** shows revenue. EcomAI is available for
    theme updates and (later) as a consultant.

*Beta cut:* the Shopify ownership transfer may be **admin-assisted** (a guided,
semi-manual step) rather than fully automated; custom domains may start as a
subdomain and be upgraded.

---

## 6. COMPLETE FLOW — Supplier: signup → receiving orders

*(Mostly already built in `apps/supplier`; the new part is store orders creating
supplier orders.)*

1. **Sign up** — marketing "Become a Supplier" → supplier app signup → verify →
   `role = 'supplier'`.
2. **Onboarding** — 5-step wizard + document upload → status `in_review`. *(built)*
3. **Verification** — admin reviews in `/admin/suppliers/[id]` → **approve** →
   verified badge; features unlock. *(built)*
4. **Publish catalog** — add products (manual, **AI enrich**, or **CSV**), set
   **inventory** + low-stock thresholds. *(built)*
5. **Get discovered** — published products appear in the entrepreneur's **Find
   Suppliers**; an entrepreneur adds them to a store's Selected Inventory.
6. **Store goes live** — the entrepreneur's Shopify/own store now sells the
   supplier's products.
7. **Receive an order** — a customer buys on a store → the order is **recorded in
   our DB** → **routed to the supplier as a supplier Order** (the Orders section
   we built), grouped by supplier, with items, quantities, and the customer's
   shipping details. Supplier is notified (bell + email). *(orders UI built; new:
   store→supplier order creation + shipping fields)*
8. **Fulfil** — supplier moves the order **processing → shipped (tracking) →
   delivered**; the store/customer is notified. *(built)*
9. **Inventory two-way sync** — the sale **decrements** supplier stock and the
   store's available quantity; a supplier **restock increments** store
   availability. Runs as an Inngest sync on inventory changes and on order events.
10. **See performance** — supplier dashboard: orders, quality score, low-stock
    alerts, analytics. *(built)*

---

## 6.1 The EcomStrait AI Shopify app — `apps/ecom-strait-ai`

**What it is:** the Shopify custom app (already scaffolded). Stack: **React
Router 7 + `@shopify/shopify-app-react-router` + Prisma (session storage) +
Polaris/App Bridge**, driven by the **Shopify CLI** (`shopify app dev` tunnels to
a development store). `client_id` is set; scopes today are
`write_products,write_metaobjects,write_metaobject_definitions`; only
`app/uninstalled` + `app/scopes_update` webhooks exist.

**Repo/workspace:** developed **independently** — **excluded from our pnpm/turbo
workspace** (`!apps/ecom-strait-ai`), so `pnpm dev`/`build` never touch it and
its React 18 / npm-lock / CLI flow stays clean. Run it with
`cd apps/ecom-strait-ai && npm install && npm run dev` (attaches to a dev store).

**Its job — thin Shopify surface, no business logic:**
1. **Install / OAuth** on our Partner dev stores (and on the customer's store
   after transfer — our app **stays installed** for ongoing sync).
2. On `afterAuth`, **push `shop_domain` + (encrypted) `access_token` + `scopes`
   to our platform**: `POST ${MERCHANT_URL}/api/shopify/connect` (signed with a
   shared secret) → our Next.js upserts into Supabase `shopify_stores`. *This
   replaces the manual admin token paste.*
3. **Register commerce webhooks** — `orders/create`, `orders/updated`,
   `orders/fulfilled`, `products/update`, `inventory_levels/update` — pointed at
   **our Next.js endpoint** `${MERCHANT_URL}/api/shopify/webhooks` (HMAC verified
   there). Keep `app/uninstalled` + `app/scopes_update` in the app.
4. **Embedded Polaris UI** (in Shopify admin): sync status + EcomAI actions
   (regenerate theme, enrich products) — for the owner after transfer.
5. **Session storage** stays the app's own concern (Prisma → **Postgres** in
   prod); it does **not** share our Supabase-migrated schema — only OAuth tokens
   flow across via the `/connect` call.

**Scopes to expand (B5):** `read_products,write_products,read_inventory,
write_inventory,read_orders,read_themes,write_themes,read_content,write_content,
read_files,write_files` (+ metafields as needed).

**What `apps/merchant` (Next.js) adds to complete the loop:**
- `POST /api/shopify/connect` — verify shared secret → upsert `shopify_stores`.
- `POST /api/shopify/webhooks` — verify Shopify **HMAC** + dedupe → emit an
  **Inngest** event (`shopify/order.created`, `shopify/inventory.updated`, …).
- `GET/PUT/POST /api/inngest` — Inngest serve (the sync/build functions).
- The **AI build + two-way sync** call the **Shopify GraphQL Admin API directly**
  from **Inngest** using the token in `shopify_stores` — the app is not in that
  path.

> Net: the Shopify app does *install + webhooks + embedded UI*; **Next.js +
> Inngest + Supabase do all the work**. Keeps Supabase creds out of the app and
> gives us one sync engine for all build paths.

**Nested git:** the app was scaffolded with its own `.git`. Decide: keep it a
separate repo, adopt it as a **git submodule**, or remove its `.git` and track it
in the monorepo. *(Recommend submodule or de-git for one history.)*

---

## 7. Data model (beta additions; Supabase + RLS)

- `subscriptions` — user_id, plan, status, stripe ids, current_period_end,
  trial_ends_at, promo_eligible.
- `usage_daily` — user_id, date, tokens_used (unique user_id+date).
- `stores` — user_id, type (`shopify_shopify_theme|shopify_liquid_theme|
  own_platform`), name, status, domain/subdomain, theme, shopify_store_id, live_url.
- `shopify_stores` — the **development-store pool**. Stores are created manually
  on the **Shopify Partner dashboard** (+ our custom app installed), then their
  details are **added by an admin** so the pool has `AVAILABLE` inventory to
  assign. Columns (snake_case in Postgres; camelCase names shown for reference):
  - `id`
  - `shop_domain` (shopDomain)
  - `shopify_shop_id` (shopifyShopId)
  - `access_token` (accessToken — **encrypted at rest**)
  - `scopes`
  - `status` — enum below
  - `owner_user_id` (ownerUserId — null until assigned)
  - `assigned_at` (assignedAt)
  - `transferred_at` (transferredAt)
  - `theme_id` (themeId)
  - `sync_status` (syncStatus)
  - `notes`
  - `created_at`, `updated_at`

  **`status` enum:** `AVAILABLE → ASSIGNED → BUILDING → READY_FOR_REVIEW →
  CLIENT_APPROVED → WAITING_FOR_TRANSFER → TRANSFERRED`, plus `ARCHIVED`
  (retired / decommissioned). RLS: admin-managed; an entrepreneur can read only
  the store assigned to them (`owner_user_id = auth.uid()`).
- `store_products` — store_id, supplier product_id, external_product_id (Shopify
  or own), price, status, last_sync.
- `store_orders` — store_id, source (`shopify|own`), external_order_id, customer,
  shipping, totals, status. → creates supplier `orders` (reuse) for fulfilment.
- `store_inventory` — store_product_id, quantity, last_sync (two-way).
- `custom_sites` — store_id, deployment ref, domain, dns_verified, ssl.
- `webhook_events` — topic, shop/source, hmac_ok, dedupe_key, processed_at.
- Reuse supplier `suppliers`/`products`/`orders`/`order_items` for Find Suppliers
  and fulfilment.

---

## 8. Sync & jobs (Inngest, beta)

- **AI build pipeline** — one durable function, resumable steps, token-metered,
  emits progress for the live timeline.
- **Shopify webhooks** — orders/products/inventory; HMAC verified; idempotent;
  auto-retried by Inngest → write `store_orders` + create supplier `orders`.
- **Two-way inventory sync** — supplier inventory change → update store products;
  store sale → decrement supplier stock. Debounced, idempotent.
- **Own-platform** — same order/inventory logic via our APIs (no Shopify webhook;
  our checkout writes `store_orders` directly).

---

## 9. Beta roadmap (phases)

- **B0 — Foundation:** ✅ *DONE* — `apps/merchant`, signup (`business_owner`),
  subscriptions/usage/stores + `shopify_stores` schema, dashboard shell.
- **B1 — Billing & promo:** ✅ *DONE (needs Stripe price IDs + webhook secret)* —
  Stripe **Checkout** + **Customer Portal** + **webhook** (`/api/stripe/webhook`)
  syncing the subscription; **Billing page** plan picker; auto-subscription on
  first load with the **first-100 free FULL month** promo; effective-plan resolver
  (expired trial → Free). Token/store *meters* shown; hard *enforcement* is B2.
- **B2 — Entitlements & token metering:** ✅ *DONE (backbone)* —
  `lib/entitlements.ts`: `getEntitlements()` (effective plan + tokens used today
  + stores used + remaining), `assertTokenBudget()` / `recordTokenUsage()` (AI
  gate), `assertCanCreateStore()` (store-limit gate). Dashboard meters now read
  this single source. Enforcement fires at the call sites in B3 (AI) and B5
  (store create).
- **B2b — Find Suppliers + Selected Inventory + Store Gallery:** ✅ *DONE* —
  `/find-suppliers` browses published supplier products (search, supplier names,
  add/remove); `/inventory` shows the selected working set (`selected_products`);
  `/gallery` presents store themes. Feeds the builder (B3).
- **B3 — EcomAI Store Builder (path-agnostic core):** ✅ *DONE* — `/builder`:
  describe → **EcomAI generates a store plan** (name, brand colors, hero, about,
  collections, SEO via Groq + preset fallback) with a **live build timeline** →
  choose path (own-platform / Shopify) + theme → **create store**. **Token-metered**
  (`assertTokenBudget` before, `recordTokenUsage` after) and **store-limit-gated**
  (`assertCanCreateStore`). Writes a `stores` row (`ready_for_review`); `/stores`
  lists them. Provisioning/deploy is B4 (own-platform) / B5 (Shopify).
- **B4 — Own-platform storefront (Path 3):** ✅ *DONE (pending migration)* —
  launch persists the plan (`stores.content`) + products (`store_products`) and
  goes **live** with a `live_url`. Public storefront `/store/[id]` (hero, logo,
  products) with a **cart + guest Stripe Checkout** (server-trusted prices,
  shipping collected). Success handler records `store_orders`, **routes to
  suppliers** (creates supplier `orders` + items with the customer's shipping),
  and **decrements inventory** (logged adjustment). Stores list links "View store".
  *(Beta: platform Stripe collects; per-merchant Stripe Connect + custom domain
  are later.)*
- **B5 — Shopify app + provisioning (Paths 1–2):** ✅ *DONE (needs Partner + dev
  store to run)* — Shopify app (`apps/ecom-strait-ai`): expanded scopes,
  **`afterAuth`** pushes shop+token to `/api/shopify/connect` (shared secret) and
  **registers the `orders/create` webhook** → the merchant. Merchant:
  `/api/shopify/connect` (upserts the `shopify_stores` pool), `/api/shopify/
  webhooks` (**HMAC-verified**, maps line items by SKU/title → **records the order
  + routes to suppliers + decrements stock** via shared `order-sink`),
  `lib/shopify.ts` (Admin GraphQL + product push), and **`provisionShopifyStore`**
  (claims a pool store, pushes the AI catalog) with a "Provision on Shopify"
  button on `/stores`. *Original spec (kept, remaining):*  build out
  **`apps/ecom-strait-ai`** (§6.1) — expand scopes, `afterAuth` → `/api/shopify/
  connect`, register commerce webhooks → `/api/shopify/webhooks`, embedded UI —
  and attach it to a **dev store** via `shopify app dev`. On our side: the
  `/api/shopify/connect` + `/api/shopify/webhooks` + `/api/inngest` endpoints in
  `apps/merchant`, which **auto-populate the `shopify_stores` pool** on install
  (the admin "Add development store" form stays as a manual fallback).
  **Assignment** picks the next `AVAILABLE` store on build (→ `ASSIGNED`/
  `BUILDING`); push products/content + a **Liquid theme** via the Admin API from
  Inngest; order webhook → supplier order; admin-assisted transfer
  (`WAITING_FOR_TRANSFER → TRANSFERRED`); low-pool alert when `AVAILABLE` < 5.
- **B5b — Liquid theme upload (Path 2 · `shopify_liquid_theme`):** ✅ *BUILT
  (needs a live dev-store test + a public merchant URL)* — the Shopify + our-Liquid-theme
  path is now wired end to end:
  - **First Liquid theme — `aurora`** (`apps/merchant/themes/aurora/`, 22 files):
    a complete, valid Shopify theme — `layout/theme.liquid`, index/product/
    collection/cart/page/search/404/list-collections templates, header/footer/hero/
    featured-collection/value-props/main-product/main-collection sections,
    product-card + price snippets, settings-driven `theme.css`, `settings_schema.json`
    + `settings_data.json`, locales. Brand color / accent / text / fonts / radius /
    hero copy / logo are **theme settings**, so cosmetic edits map onto them. Aligned
    to the `aurora` style id — **one theme per niche/style, added one at a time**
    (registry in `lib/themes.ts`).
  - **Scope:** ✅ added **`read_themes,write_themes`** to `apps/ecom-strait-ai/
    shopify.app.toml` (re-prompts merchants to approve on next load).
  - **Serving the zip:** `scripts/bundle-themes.mjs` (runs on `prebuild`/`predev`)
    bundles each theme into `src/themes/generated/<id>.json`; **`GET /api/themes/[id]`**
    streams it as an uncompressed zip via a dependency-free builder (`lib/zip.ts`,
    STORE method + CRC32). Shopify's `themeCreate` fetches this URL — so
    `NEXT_PUBLIC_MERCHANT_URL` **must be publicly reachable** (a tunnel in dev, not
    localhost).
  - **Upload + publish (`lib/shopify-theme.ts`):** `themeCreate(source)` → poll
    `theme.processing` → **`themeFilesUpsert`** uploads the **logo into `assets/`**
    (body type `URL` — Shopify fetches the merchant's Supabase logo) and overwrites
    `config/settings_data.json` with the store's brand (`settingsFromPlan` maps
    `stores.content` → colors + hero; `logoAssetFrom` sets `logo_asset`) →
    **`themePublish`**. Returns the Shopify theme gid. The theme header renders
    `settings.logo_asset` (uploaded logo) → `settings.logo` (picker) → shop-name text.
  - **Wired into `provisionShopifyStore`:** for `type = shopify_liquid_theme`, after
    the product push → upload the logo asset + publish the theme, store the gid in
    `shopify_stores.theme_id`, `sync_status = "pushed N products + theme"`.
  - **Live re-sync (`resyncShopifyTheme`):** ✅ pushes the current plan (colors, hero,
    logo from `stores.content`) onto the already-published theme via `themeFilesUpsert`
    (`pushThemeSettings`, shared with provisioning) — **no re-create/re-publish**. An
    **"Update live store"** button on `/stores` (Liquid-theme, provisioned stores).
  - **Post-launch co-founder editor (`/stores/[id]/edit`):** ✅ a persistent EcomAI
    chat + live preview. A prompt → **`editStore`** refines the plan
    (`refineStorePlan`, token-metered), persists `stores.content`, and **auto-propagates**:
    own-platform reads `content` live; Shopify Liquid auto-calls `resyncShopifyTheme`;
    unprovisioned saves a draft. The chat reports where it synced. "Edit with EcomAI"
    links from `/stores`. This closes the *prompt → live update* loop.
  - **Remaining:** live test on a dev store (needs the public URL above). Path 1
    (`shopify_shopify_theme`) still just keeps Shopify's stock theme.
- **B6 — Orders & Sales + supplier order routing:** ✅ *DONE* — entrepreneur
  **`/orders`** (real `store_orders` table: order id/date, store, customer, items,
  total, status — RLS-scoped to the owner) and **`/sales`** (revenue / orders /
  avg-order / units-sold metrics, a 14-day revenue bar chart, revenue-by-store,
  and top products — all computed from `store_orders`, no chart dependency). The
  routing half — **store order → supplier `orders` + items with shipping**, and
  **inventory decrement** (logged adjustment) — was already wired in B4/B5 via the
  shared `order-sink`; suppliers receive these in the supplier portal.
- **B7 — Custom domain + polish:** ✅ *DONE (own-platform serving on a custom
  domain — the storefront domain-masking wiring — stays deferred, §10)* —
  **Custom domains** in `/settings`: per store, save a custom domain (`stores.domain`,
  owner RLS), path-aware **DNS instructions** (`lib/domain.ts` — Shopify's
  `A 23.227.38.65` + `CNAME www → shops.myshopify.com` for Shopify paths; env-driven
  `STOREFRONT_A_RECORD`/`STOREFRONT_CNAME` for own-platform, with copy buttons), and
  a live **"Check DNS"** verifier (`checkStoreDomain` resolves the domain and
  compares against the expected host → Connected / Pending). **Basic admin:** the
  `/admin/shopify-stores` page (store pool + storefront passwords) now also shows
  **beta-ops metrics** — promo slots claimed (`promo_eligible` count / 100), total
  signups, and available-pool with a **low-pool (<5) warning**. Usage meters +
  entitlement guards were already live (B1/B2). *(Env for own-platform DNS:
  `STOREFRONT_A_RECORD`, `STOREFRONT_CNAME` — default to Vercel.)*

*Recommended first sellable demo:* **B0 → B1 → B2 → B3 → B4** gives a full
entrepreneur signup → build → live (own-platform) → customer order → supplier
fulfilment loop without waiting on Shopify Partner setup. Shopify (B5) layers in
next.

---

## 10. Deferred to post-beta
Fully-automated Shopify transfer; multi-warehouse; advanced analytics/forecasting;
EcomAI consultant chat; agency/white-label; refunds/tax/fraud depth on the
own-platform checkout; Storefront-API domain masking; ERP.

## 11. Needed from Shehzad
- **Stripe** account (test keys, products/prices, webhook secret). ✅ *sandbox key added*
- **Inngest** account (event + signing keys). ✅ *being set up*
- **Shopify app** `apps/ecom-strait-ai` ✅ *scaffolded* — **attach it to a
  development store** (`shopify app dev`) so we can develop against real data.
  A shared secret (`SHOPIFY_APP_SHARED_SECRET`) will bridge app ↔ merchant, and
  the app's `application_url`/`redirect_urls` get set by the CLI on dev.
- **Shopify Partner** account + dev stores for the pool (B5).
- **Hosting** decision for Path-3 storefronts — *recommend one multi-tenant
  storefront keyed by domain for beta*.
- Decide the app's **nested git** (submodule vs. de-git — §6.1). ✅ *de-git'd —
  tracked in the monorepo.*
- **B5b Liquid theme:** ✅ *scope added, first theme (`aurora`) built + upload wired.*
  Remaining: a **publicly reachable `NEXT_PUBLIC_MERCHANT_URL`** (tunnel/deploy) so
  Shopify's `themeCreate` can fetch `/api/themes/[id]`, plus a dev store to run the
  live test. Additional per-niche themes get added one at a time.
- Confirm minor calls: card-on-file trial vs no-card; does an own-platform site
  consume a store slot (recommend yes).

---

**First deliverable on approval:** **B0** — `apps/merchant` scaffold + entrepreneur
signup + subscriptions/usage/stores schema, building green, so the portal exists
before Stripe and Shopify are wired.
