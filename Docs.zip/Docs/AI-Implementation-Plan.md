# EcomStrait — "AI Co-Founder" Implementation Plan

> Working plan derived from `NewPlan.md`. Review target: agree, then build phase by phase.

## 1. Vision & locked decisions

**Positioning:** stop selling the platform, sell the transformation —
**"The world's first AI Ecommerce Co-Founder."** Every section should let a
visitor *watch their future business get built*. EcomAI is the main character.

Decisions locked with Shehzad:
- **Coverage:** *Flagship + light voice* — 2–3 fully interactive AI moments
  (Hero, AI Business Simulator, Store-Gallery "watch it generate") + a lighter
  "AI voice" treatment elsewhere. Not every section becomes a chatbot.
- **Honesty:** *Aspirational but labeled* — show the full vision, but framed as
  a **simulated preview**, with example/**ranged** numbers and a subtle
  "rolling out in beta" line. Never present fabricated data as live.
- **LLM:** **Groq-hosted Llama**, behind a swappable interface, with a
  deterministic **preset engine as the always-on base**.
- **Order:** *Foundations first.*

## 2. AI stack — cost, model, limits

Latest Groq pricing (groq.com/pricing) and free-tier limits (per 1M tokens):

| Model | Input | Output | Speed | ~Cost / 1,000 builds* |
|---|---|---|---|---|
| **Llama 4 Scout** (default) | $0.11 | $0.34 | 594 tok/s | **~$0.50** |
| Llama 3.3 70B Versatile (voice A/B) | $0.59 | $0.79 | 394 tok/s | ~$2.20 |
| Llama 3.1 8B Instant (fallback) | $0.05 | $0.08 | 840 tok/s | ~$0.19 |

*Assumes ~3,000 input + ~500 output tokens per interaction.*

**Free tier:** ~30 RPM · 6,000 TPM · 14,400 req/day (org-level, first-limit-wins).
TPM is the binding constraint at ~3.5K tokens/build → ~1–2 builds/min free.
**Verdict:** cost is negligible; choose on voice/latency. Free tier covers dev
and light launch traffic; spikes handled by preset fallback + caching, or the
cheap paid tier.

**Model choice:** default **Llama 4 Scout** (quality ≫ 8B, ~5× cheaper than 70B,
fast). A/B **70B** for copy voice since voice *is* the product. All selected via
`GROQ_MODEL`, swappable with zero code change.

## 3. Architecture

A single provider-agnostic contract; the model is never a hard dependency.

```
generateBusinessPlan(input) -> BusinessPlan
  ├─ preset engine   (deterministic, from the niche KB) ── always on, instant
  └─ groq engine     (Llama via Groq, JSON mode)         ── enhancement
       └─ on 429 / timeout / error / no key → falls back to preset
```

- **Output is structured JSON** (`BusinessPlan`: niche, margin range, supplier
  range, product ideas, target countries, build steps, growth suggestions,
  disclaimer). The client animates it as a "typing"/timeline reveal — identical
  for preset and LLM, and fully controllable (no dependence on token streaming).
- **Guardrails (system prompt + schema):** on-brand voice; numbers must be
  **ranges/examples** and labeled; refuse off-topic; JSON-only; length caps.
- **Safety/ops:** input length cap, basic prompt-injection/profanity screen,
  in-memory + (later) edge cache of common niches, per-IP rate limit, hard
  monthly cost cap via env, graceful preset fallback on any failure.
- **Honesty layer:** every AI surface carries a small "Simulated preview —
  features roll out in beta" affordance; CTAs funnel to **Join Founders
  Waitlist** (Supabase + Resend already wired).
- **Future upgrade path:** KB grows → move from prompt-stuffing to **RAG on
  Supabase `pgvector`** (no new vendor).

## 4. EcomAI component kit (build once, reuse everywhere)

`src/components/ecomai/` — theme-aware, reduced-motion-safe, SSR/static fallback:
- `AiAvatar` — the EcomAI mark + presence/"thinking" states.
- `AiChat` / `AiBubble` / `AiTyping` — conversation primitives.
- `AiProgressLog` — the `00:00 → 00:50` build timeline.
- `AiTerminal` — generation/log panel.
- `AiPromptInput` — the "what do you want to sell?" field (free-text + niche chips).
- Defined **voice/tone** doc (confident, concise, friendly, no hype).

## 5. Content — the niche knowledge base

`src/content/niches.ts` — curated, **labeled** dataset seeding both engines:
niche → example margin range, supplier-count range, product ideas, target
countries, build-step narrative, plus EcomAI voice snippets and disclaimer
strings. Seeded from existing `store-themes.ts`.

## 6. Phases

- **Phase 0 — Foundations** *(current)*
  - Fix the in-flight storefront image refactor (multi-extension loader + hero
    background image) — unblocks the build.
  - EcomAI component kit + voice doc.
  - `niches.ts` knowledge base.
  - `lib/ecomai/*`: `BusinessPlan` types, preset engine, Groq client,
    `generateBusinessPlan()`, `/api/ecomai` route, cache + fallback + guardrails.
  - Env: `GROQ_API_KEY`, `GROQ_MODEL` (documented in `.env.example`).
- **Phase 1 — Hero (flagship)** — interactive "idea → business built in ~40s":
  prompt → conversation → build timeline → store preview (deep-links into a real
  `/store/[slug]` demo) → **Join Founders Waitlist**. (NewPlan: Hero + Section 1.)
- **Phase 2 — Messaging pass (copy + metadata, fast wins)** — rewrite headlines,
  subheads, and metadata site-wide: Section 1 headline, Why EcomStrait
  comparison, Services → "AI Business Services", Final CTA → "Meet Your Future
  Business Partner". Ships in ~a day; run in parallel with Phase 1.
- **Phase 3 — Persona + AI Business Simulator** — interactive persona picker
  (Entrepreneur/Supplier/Agency/Store Owner) → qualify → estimate; **merge the
  ROI calculator into the simulator**; wire to waitlist. (NewPlan: Section 2 + ROI.)
- **Phase 4 — Story / animation sections** — Problem (tools shake → converge),
  How-It-Works timeline, EcomAI conversation examples, Store Gallery "how it was
  generated", Founder Stories. Mostly light-voice + one or two interactive.
- **Phase 5 — Pre-launch & waitlist** — Founders Waitlist flow, "30 Days to Your
  First Business" narrative + Resend email drip, lightweight analytics events
  (idea submitted / build clicked / waitlist joined).
- **Phase 6 — Polish** — performance, reduced-motion, mobile, accessibility,
  SEO (keep functional keywords despite the bold brand line), QA.

## 7. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Overpromising pre-launch | "Aspirational but **labeled**"; ranges not fabricated stats; beta affordance |
| Free-tier TPM spikes | Preset fallback on 429 + cache common niches + lean prompt; cheap paid tier |
| "Everything's a chatbot" fatigue | Flagship + light voice; static fallbacks; rhythm |
| SEO regression from bold brand line | Keep functional keywords in copy + metadata; real text under every animation |
| Scope creep / stall | Strict phases; messaging pass ships value in days |

## 8. Needed from Shehzad
- A **Groq API key** → add `GROQ_API_KEY` to `.env.local` (I'll build so the
  preset fallback works immediately, even before the key exists).
- Product images per `Docs`/the asset list (progressively enhances the demos).

---

## Appendix A — Section-by-section website changes

Every numeric claim below is **illustrative / labeled** (ranges, "example",
"simulated preview"), per the honesty decision. "Phase" = when it ships.

### Global / positioning · Phase 2
- Brand line → **"The world's first AI Ecommerce Co-Founder."**
- Keep functional SEO keywords (launch online store, AI store builder,
  suppliers) in body + metadata despite the bold hero line.

### 1. Hero · Phase 1 (interactive) + Phase 2 (copy)
- **Headline:** "AI-Powered Commerce Operating System" → **"Build Your Online
  Business. AI Handles Everything."**
- **Sub:** "From suppliers and websites to SEO, marketing and growth. Tell
  EcomAI what you want to build and launch in minutes."
- **Interaction:** type an idea → EcomAI: *N suppliers found → website generated
  → SEO → products imported → marketing ready → "Business launched."* → store
  preview (deep-links to a real `/store/[slug]`) → **Join Founders Waitlist**.
  No scroll needed to "get it."

### 2. "Not sure where you fit?" → persona simulator · Phase 3
- Persona picker: **Entrepreneur / Supplier / Agency / Existing Store Owner**.
- Conversational qualify: what to sell → country → budget → *Analyzing…* →
  niche suggestions + **estimated profit range** → "Shall I build your store?"
  → waitlist. Jarvis-like feel.
  

### 3. Problem section · Phase 4
- **BEFORE:** fragmented tools with prices (Website $29 + SEO $49 + Hosting $30 +
  Agency $500 + Marketing $200 + Inventory + Supplier searching = **$1000+**)
  that **shake and break apart**.
- **AFTER:** the pieces fly together into **ONE PLATFORM** around EcomAI.

### 4. How It Works · Phase 4
- Replace 5 static steps with an **AI build timeline** `00:00 → 00:50`: finding
  suppliers → importing products → building brand → writing SEO → homepage →
  collections → mobile → payments → conversion → **store ready**.

### 5. EcomAI section · Phase 4
- Show **real conversations**, not feature cards:
  - "My sales dropped." → diagnoses (low conversion / poor images / checkout
    abandonment) → optimize? → done, **+18–24% (est.)**.
  - "Which products are profitable?" → recommends niches, **~46% margin (est.)**
    → "import them?"

### 6. Store Gallery · Phase 4 (interactive)
- Show **how** a store is generated: prompt ("Luxury fashion store, women 25–40")
  → AI working → logo → products → SEO → mobile → **STORE GENERATED** → opens the
  real `/store/[slug]` demo. (Not just "here's the store.")

### 7. Services → "AI Business Services" · Phase 2
- Reframe as advisors: Website Builder · Marketing Consultant · SEO Consultant ·
  Business Advisor · Inventory Manager · Supplier Consultant · Sales Advisor ·
  Conversion Optimization · Automation Expert.

### 8. Why EcomStrait · Phase 2 (copy) + reuse animated scoreboard
- **Without EcomAI:** 10 tools · $1500+ · 14 days · developers · agencies ·
  complicated setup.
- **With EcomAI:** one prompt · 45 seconds · store generated · SEO completed ·
  business launched · AI consultant included.

### 9. Success Stories → "Founder Stories" · Phase 4/5
- Narrative, **no fabricated stats**: Sarah wants cosmetics → AI built her store →
  15 min later launched → 30 days later **$3,200 (example)**. Clearly illustrative.

### 10. ROI Calculator → "AI Business Simulator" · Phase 3
- Country → budget → products → target revenue → marketing budget → **AI
  analysis** → estimated revenue / profit / margins / best niche / supplier +
  growth suggestions (labeled ranges). Merge the current calculator into this.

### 11. FAQ → "Ask EcomAI" · Phase 3/4
- Upgrade the existing chat FAQ to the engine: "Will perfumes work?" → yes,
  **~46% margin (est.)**, 7 suppliers, 3 countries → "continue?" → waitlist.

### 12. Final CTA · Phase 2 (copy) + Phase 5 (waitlist)
- "Ready to build your business?" → **"Meet Your Future Business Partner."**
  EcomAI never sleeps — ask questions, build stores, grow, optimize marketing,
  find profitable products, launch globally. CTAs: **Join Founders Waitlist** +
  **Watch AI Build a Business**.

### 13. Pre-launch campaign · Phase 5
- Market **"30 Days to Your First Business"**, not "AI Commerce OS". Resend drip:
  Day 1 store ready → Day 3 SEO → Day 7 FB campaign → Day 15 +17% → Day 30
  $4,700 (all labeled examples).

**Target lift (from NewPlan):** Messaging 7→10, Hero 7→10, Storytelling 6→10,
Conversion 7→10, Waitlist 5→10, Positioning 6→10.
