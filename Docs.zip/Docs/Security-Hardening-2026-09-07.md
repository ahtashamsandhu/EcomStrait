# Security hardening — 7 Sep 2026

Companion to `Docs/Security-Audit-Merchandise-Suppliers.pdf`. This is what changed, and what you must do when deploying it.

## Deploy checklist

1. **Apply the five new migrations** (`supabase db push`), in order:
   - `20260907120000_function_grants_lockdown.sql` — every function is deny-by-default for `anon`/`authenticated`; only the RLS helpers and the RPCs below are granted back.
   - `20260907120100_privileged_column_guards.sql` — triggers stop sessions changing `profiles.role`, supplier approval/KYC fields, and the money columns on `orders`; adds status/price CHECKs.
   - `20260907120200_money_functions_hardening.sql` — `reverse_cod_deduction` refunds from the ledger; `request_payout()` RPC replaces direct inserts; one pending payout per account.
   - `20260907120300_tenant_integrity_guards.sql` — listing trigger derives `supplier_id`; message sender, team invites, usage counters, store limits, storage MIME/size limits, atomic stock RPCs; published products are no longer readable anonymously.
   - `20260907120400_shopify_token_column_privacy.sql` — `shopify_stores.access_token` is unreadable from any session.
2. **Set `MCP_SERVER_SECRET`** on the merchant app (any long random string) if you use `/api/mcp/*`. Unset, those routes return 404. Every request must send `Authorization: Bearer <secret>`.
3. **Shopify webhooks:** subscribe the app to `orders/paid` and `orders/cancelled` in addition to `orders/create`. Prepaid orders are now recorded only from a paid state; cancellations reverse the wallet debit.
4. **Stripe webhook (merchant):** `checkout.session.completed` now also records storefront purchases, so a customer who closes the tab after paying still produces an order. Nothing to configure if the endpoint is already registered.
5. **Storage buckets** now enforce MIME/size limits at the bucket. SVG uploads are no longer accepted anywhere.

## New RPCs (all `authenticated`, all ownership-checked inside)

| Function | Used by |
|---|---|
| `request_payout(account_type, amount, bank…)` | both wallet pages |
| `increment_token_usage(tokens)` / `increment_supplier_token_usage(supplier_id, tokens)` | AI features |
| `set_product_stock(product_id, stock, reason)` / `adjust_product_stock(product_id, delta, reason)` | supplier inventory, merchant order sink |
| `reverse_cod_deduction(order_id)` | supplier order cancellation, Shopify cancellation |

## Rule for new database functions

`ALTER DEFAULT PRIVILEGES` now revokes EXECUTE from `anon`/`authenticated`. A new function is callable by the service role only until you `grant execute … to authenticated` explicitly. Do that only for functions that check `auth.uid()` themselves.

## App-layer changes worth knowing

- `@ecomstrait/db/admin` is `server-only` and no longer re-exported from `@ecomstrait/db`.
- `safeNextPath()` (`@ecomstrait/auth/redirect`) validates every post-login `next`/`redirect` value.
- `secretMatches()` / `bearerMatches()` (`apps/merchant/src/lib/secret-compare.ts`) do constant-time secret comparison for the cross-app routes.
- JSON-LD is serialized with `safeJsonForHtml()`; supplier text can no longer break out of the script tag.
- Supplier server actions validate product input (lengths, non-negative prices, status enum, image URLs), cap CSV imports at 2,000 rows, enforce order status transitions, and map raw database errors to plain messages.
- Both apps send baseline security headers (`frame-ancestors 'self'`, nosniff, referrer policy, HSTS).

## Still open (deliberately)

- Shopify Admin tokens and storefront passwords are unreadable from sessions but still stored in plaintext. At-rest encryption needs a key-management decision.
- Co-Founder chat history is client-supplied (self-tenant only, no tools).
- Staff invite acceptance trusts the session email; enforce email confirmation in the hosted Supabase project.
