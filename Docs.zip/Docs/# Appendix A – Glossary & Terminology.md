# Appendix A – Glossary & Terminology

---

# Purpose

This glossary establishes a shared vocabulary for everyone working on the EcomStrait platform, including product managers, designers, developers, QA engineers, AI engineers, customer success teams, suppliers, and business stakeholders.

Using consistent terminology reduces ambiguity and improves communication across the project.

---

# Business Terms

## EcomStrait

The AI-powered Commerce Operating System that connects verified suppliers with entrepreneurs to launch, manage, and grow ecommerce businesses.

---

## Supplier

A verified business or manufacturer that publishes products to the marketplace.

Suppliers manage:

- Products
- Inventory
- Pricing
- Business profile
- Store requests

---

## Store Owner

A customer using EcomStrait to launch and operate an ecommerce business.

Store owners:

- Browse suppliers
- Select products
- Request store creation
- Manage orders
- Grow their business using AI

---

## Marketplace

The B2B product discovery platform where suppliers publish products and merchants discover business opportunities.

---

## Store Request

A request submitted by a merchant asking EcomStrait to generate an ecommerce store using selected products.

---

## White-Label

A version of EcomStrait that can be branded and operated by another organization under its own identity.

---

## Business Opportunity Score

A proprietary AI-generated score estimating the commercial potential of a product based on factors such as demand, supplier quality, profit margin, and market trends.

---

## Business Health Score

An AI-generated score summarizing the operational health of a supplier or merchant.

---

# Technical Terms

## Tenant

A logical customer boundary in the multi-tenant architecture.

Each tenant owns its own users, suppliers, products, stores, and business data.

---

## Organization

A company or business entity operating within the platform.

---

## Workspace

A dedicated environment where a tenant manages users, products, analytics, and settings.

---

## Module

An independent functional area of the platform.

Examples:

- Products
- Orders
- AI
- Analytics
- Billing

---

## Domain

A business capability following Domain-Driven Design principles.

Examples:

Identity

Commerce

Analytics

Notifications

AI

---

## Event

A business occurrence that triggers additional processing.

Examples:

ProductPublished

SupplierApproved

OrderCreated

WebsiteGenerated

---

## Workflow

A sequence of automated actions initiated by an event.

---

## AI Agent

A specialized AI component responsible for a particular business capability.

Examples:

Marketing Agent

Supplier Agent

Executive Copilot

---

## AI Orchestrator

The component responsible for coordinating multiple AI agents and routing requests to the appropriate models or services.

---

## API

Application Programming Interface used for communication between services.

---

## RBAC

Role-Based Access Control.

A security model where users receive permissions based on assigned roles.

---

## Feature Flag

A mechanism that enables or disables features without deploying new code.

---

## Audit Log

A permanent record of important business and security events.

---

## Soft Delete

A deletion strategy where records are marked as deleted instead of being permanently removed.

---

## AI Credits

Units representing AI usage for billable features.

---

# Commerce Terms

## MOQ

Minimum Order Quantity.

The smallest quantity a supplier is willing to sell.

---

## SKU

Stock Keeping Unit.

A unique identifier assigned to a product or variant.

---

## Product Variant

A variation of a product based on attributes such as color, size, or material.

---

## Collection

A curated group of related products.

---

## Category

A hierarchical grouping of products.

---

## Inventory

The quantity of products currently available for sale.

---

## Lead Time

The expected duration between placing an order and product availability or shipment.

---

# Financial Terms

## MRR

Monthly Recurring Revenue.

---

## ARR

Annual Recurring Revenue.

---

## LTV

Customer Lifetime Value.

---

## CAC

Customer Acquisition Cost.

---

## GMV

Gross Merchandise Value.

---

## ARPU

Average Revenue Per User.

---

## Churn

The percentage of customers who stop using the platform.

---

# AI Terms

## Prompt

The instruction provided to an AI model.

---

## Context

Relevant information supplied to AI to improve response quality.

---

## Embedding

A numerical representation of text or data used for semantic search and retrieval.

---

## Vector Search

A search technique that retrieves information based on meaning rather than exact keyword matches.

---

## RAG

Retrieval-Augmented Generation.

An AI technique combining external knowledge retrieval with language model generation.

---

## Agent Memory

Stored context enabling AI agents to provide more personalized and consistent assistance across interactions.

---

# Infrastructure Terms

## CDN

Content Delivery Network.

---

## Object Storage

Cloud storage optimized for files such as images, videos, and documents.

---

## Queue

A background processing mechanism for asynchronous tasks.

---

## Worker

A service responsible for processing queued jobs.

---

## Webhook

An HTTP callback used to notify external systems when events occur.

---

## CI/CD

Continuous Integration and Continuous Deployment.

---

## Infrastructure as Code (IaC)

Managing infrastructure through version-controlled configuration rather than manual setup.

---

# Conclusion

Maintaining consistent terminology across documentation, user interfaces, APIs, engineering discussions, and customer support improves communication, accelerates onboarding, and reduces implementation errors.

This glossary should evolve alongside the platform as new modules and capabilities are introduced.