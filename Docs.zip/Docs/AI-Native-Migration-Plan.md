# AI-Native Migration Plan — Model-Agnostic Architecture

Status: **plan, not yet built.** Written 2026-08-29. Companion doc:
`AI-Native-Manual-Setup.md` (accounts, infra, and config Shehzad does by hand).

---

## 1. Locked decisions

1. **No agent, MCP server, or workflow ever imports a vendor SDK or hardcodes
   a model name.** Every AI call goes through one internal gateway. Swapping
   Claude for GPT, Gemini, or a self-hosted open-source model (Llama/Qwen via
   Ollama or vLLM) is a config change in one place, never a code change.
2. **Roles, not models.** Code asks for a role (`reasoning`, `workhorse`,
   `fast-cheap`, `embeddings`); a config file maps each role to an actual
   model. This is the same pattern `GROQ_MODEL` already uses in
   `apps/website/src/lib/ecomai.ts` and `apps/merchant/src/lib/ecomai.ts` —
   we're generalizing it into a shared package instead of duplicating it.
3. **Gateway = self-hosted LiteLLM proxy.** Open-source, OpenAI-compatible
   API, already speaks Anthropic/OpenAI/Gemini/Groq/Ollama/vLLM. We do not
   hand-roll a multi-provider adapter.
4. **New shared package `@ecomstrait/ai`** (`packages/ai`) holds the gateway
   client, role config, RAG helpers, agents, MCP servers, and guardrails —
   consumed by `apps/website` and `apps/merchant` (and `apps/supplier` later),
   same pattern as `@ecomstrait/db` / `@ecomstrait/auth`.
5. **RAG on Supabase `pgvector`.** No new vector DB vendor at this stage.
6. **Orchestration via LangGraph.** Agent code holds no vendor model imports —
   only calls into `@ecomstrait/ai`'s `getModel(role)`.
7. **MCP servers run as Next.js API routes in `apps/merchant`** using
   `@modelcontextprotocol/sdk`'s Streamable HTTP transport — not a separate
   always-on service — to avoid new infra for v1. Revisit only if load
   requires a dedicated worker.
8. **In-process for automation that's entirely internal.** The restock check
   (Phase 6) calls its decision function and the approval guardrail directly
   from the Shopify webhook's `after()` block — no n8n. n8n was evaluated and
   deliberately not used here: it would have added an outbound call, an
   inbound endpoint, and a second secret for something that's one function
   call within our own DB and Shopify integration — the same reasoning that
   already keeps the orchestrator calling Shopify tools directly instead of
   round-tripping through the MCP HTTP endpoint. n8n remains the right tool
   for genuinely cross-system, event-driven automation (multi-channel
   notification fan-out, third-party integrations we have no direct API
   for) — just not for this.

---

## 2. Architecture

```
apps/website, apps/merchant, apps/supplier
              │  getModel("reasoning") / embed(texts)
              ▼
      packages/ai  (gateway client, roles, RAG, agents, guardrails)
              │  HTTPS, OpenAI-compatible chat/embeddings API
              ▼
      LiteLLM proxy (self-hosted)  ← litellm_config.yaml maps
              │                       role-aliases → real providers
   ┌──────────┼───────────┬───────────────┬─────────────────┐
   ▼          ▼           ▼               ▼                 ▼
 Claude    OpenAI      Voyage AI      Groq (kept as        Ollama / vLLM
 (Anthropic) (optional) (embeddings)   cheap fallback)      (self-hosted,
                                                             portability proof)
```

Agents (LangGraph, in `packages/ai/src/agents/`) call tools via **MCP
servers**, which wrap existing logic already in the repo
(`apps/merchant/src/lib/shopify.ts`, Supabase queries) rather than new
integrations:

```
Orchestrator (LangGraph)
  ├─ Business Advisor agent  → RAG (pgvector) + Shopify MCP + Supabase MCP
  └─ Analytics agent         → Supabase MCP (read-only text-to-SQL)
```

The restock check (order → decide → propose) runs in-process from the
Shopify webhook handler — no external workflow tool in the loop.

---

## 3. New package: `packages/ai`

```
packages/ai/
  package.json                # @ecomstrait/ai
  src/
    index.ts                  # public exports
    types.ts                  # ModelRole, ChatMessage, ChatResult, EmbeddingResult
    roles.ts                  # resolves AI_MODEL_* env vars → gateway model alias
    gateway.ts                # chat(role, messages, opts), embed(role, texts)
    prompts/
      system.ts                # shared voice/tone + guardrail boilerplate
    rag/
      embed.ts                 # embedText() / embedBatch() via gateway "embeddings" role
      store.ts                 # pgvector read/write (uses @ecomstrait/db)
      retrieve.ts              # similarity search helper, tenant-scoped
    agents/
      orchestrator.ts          # LangGraph graph definition + routing
      business-advisor.ts      # agent node: RAG-grounded business Q&A
      analytics-agent.ts       # agent node: text-to-SQL over store_orders etc.
    mcp/
      shopify-server.ts        # MCP tools: product/theme/order actions
      supabase-server.ts       # MCP tool: read-only parameterized SQL
    guardrails/
      approvals.ts             # requestApproval() / resolveApproval()
      audit.ts                 # logToolCall()
      cost.ts                  # recordUsage() / assertCostBudget()
```

### `types.ts`

```ts
export type ModelRole = "reasoning" | "workhorse" | "fast-cheap" | "embeddings";

export type ChatMessage = { role: "system" | "user" | "assistant" | "tool"; content: string };

export type ChatResult = {
  content: string;
  model: string;        // the *resolved* model id, for cost/audit logging
  usage: { inputTokens: number; outputTokens: number };
};

export type EmbeddingResult = { vector: number[]; model: string; dimension: number };
```

### `roles.ts`

```ts
// One place, one pattern — mirrors GROQ_MODEL from apps/*/lib/ecomai.ts,
// generalized to four roles instead of one model.
const ROLE_ENV: Record<ModelRole, string> = {
  reasoning: "AI_MODEL_REASONING",
  workhorse: "AI_MODEL_WORKHORSE",
  "fast-cheap": "AI_MODEL_FAST_CHEAP",
  embeddings: "AI_MODEL_EMBEDDINGS",
};

export function resolveModel(role: ModelRole): string {
  const alias = process.env[ROLE_ENV[role]]?.trim();
  if (!alias) {
    throw new Error(`[ai] ${ROLE_ENV[role]} is not set — no fallback by design, so a missing role fails loudly instead of silently hitting the wrong model.`);
  }
  return alias; // this alias is a name in litellm_config.yaml, not a vendor model id
}
```

### `gateway.ts`

```ts
const GATEWAY_URL = process.env.AI_GATEWAY_URL!;      // LiteLLM proxy base URL
const GATEWAY_KEY = process.env.AI_GATEWAY_API_KEY!;  // our own proxy key, not a vendor key

export async function chat(role: ModelRole, messages: ChatMessage[], opts?: { maxTokens?: number; temperature?: number; tools?: unknown[] }): Promise<ChatResult> {
  const model = resolveModel(role);
  const res = await fetch(`${GATEWAY_URL}/chat/completions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${GATEWAY_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model, messages, max_tokens: opts?.maxTokens ?? 800, temperature: opts?.temperature ?? 0.5, tools: opts?.tools }),
  });
  if (!res.ok) throw new Error(`[ai] gateway ${res.status}: ${await res.text()}`);
  const data = await res.json();
  return {
    content: data.choices[0].message.content,
    model,
    usage: { inputTokens: data.usage.prompt_tokens, outputTokens: data.usage.completion_tokens },
  };
}

export async function embed(texts: string[]): Promise<EmbeddingResult[]> {
  const model = resolveModel("embeddings");
  const res = await fetch(`${GATEWAY_URL}/embeddings`, {
    method: "POST",
    headers: { Authorization: `Bearer ${GATEWAY_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model, input: texts }),
  });
  if (!res.ok) throw new Error(`[ai] gateway embeddings ${res.status}: ${await res.text()}`);
  const data = await res.json();
  return data.data.map((d: { embedding: number[] }) => ({ vector: d.embedding, model, dimension: d.embedding.length }));
}
```

Every call records `model` (the resolved alias) alongside token usage — this
is what `guardrails/cost.ts` writes to `ai_cost_ledger`, and it's how a future
swap decision gets made from data instead of guesswork.

---

## 4. Database schema (new Supabase migration)

New file: `supabase/migrations/20260829120000_ai_native.sql`

```sql
create extension if not exists vector;

create table ai_embeddings (
  id            uuid primary key default gen_random_uuid(),
  tenant_id     uuid,                          -- null for the shared niche KB
  source_type   text not null,                 -- 'niche_kb' | 'store_catalog' | 'supplier_doc' | 'conversation'
  source_id     text not null,
  content       text not null,
  embedding     vector(1024) not null,          -- Voyage-3 dimension; revisit if the embedding model changes
  provider      text not null,                  -- resolved model alias at embed time
  created_at    timestamptz not null default now()
);
create index on ai_embeddings using ivfflat (embedding vector_cosine_ops);

create table ai_agent_runs (
  id            uuid primary key default gen_random_uuid(),
  tenant_id     uuid not null,
  agent         text not null,                  -- 'business-advisor' | 'analytics-agent' | ...
  thread_id     uuid not null,
  status        text not null default 'running', -- running | done | failed | awaiting_approval
  input         jsonb not null,
  output        jsonb,
  tool_calls    jsonb not null default '[]',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table ai_approvals (
  id             uuid primary key default gen_random_uuid(),
  agent_run_id   uuid not null references ai_agent_runs(id),
  action         text not null,                 -- e.g. 'shopify.publish_theme'
  payload        jsonb not null,
  status         text not null default 'pending', -- pending | approved | rejected
  approved_by    uuid,
  created_at     timestamptz not null default now(),
  resolved_at    timestamptz
);

create table ai_cost_ledger (
  id             uuid primary key default gen_random_uuid(),
  tenant_id      uuid not null,
  role           text not null,                 -- reasoning | workhorse | fast-cheap | embeddings
  model          text not null,                 -- resolved alias, for per-model cost comparison
  input_tokens   integer not null,
  output_tokens  integer not null,
  cost_usd       numeric(10,4) not null,
  created_at     timestamptz not null default now()
);

-- RLS: service-role only (agents run server-side); no client-side access.
alter table ai_embeddings enable row level security;
alter table ai_agent_runs enable row level security;
alter table ai_approvals enable row level security;
alter table ai_cost_ledger enable row level security;
```

---

## 5. Phases (build order)

### Phase 1 — Gateway skeleton (no behavior change yet)

- Create `packages/ai` with `types.ts`, `roles.ts`, `gateway.ts` only.
- Deploy the LiteLLM proxy (see manual-setup doc) with four aliases mapped to
  Claude tiers to start.
- Migrate `apps/website/src/lib/ecomai.ts`'s `groqPlan()` to call
  `chat("workhorse", ...)` instead of hitting Groq directly. Keep the preset
  fallback untouched — lowest-risk proof the gateway pattern works.
- **Acceptance:** the website's AI builder demo still works, now routed
  through the gateway; changing `AI_MODEL_WORKHORSE` in the proxy config
  changes the model with zero app redeploy.

### Phase 2 — RAG foundation

- Run the `20260829120000_ai_native.sql` migration.
- Build `rag/embed.ts`, `rag/store.ts`, `rag/retrieve.ts`.
- One-off script: embed `apps/website/src/content/niches.ts` into
  `ai_embeddings` (`source_type = 'niche_kb'`).
- **Acceptance:** a similarity query for a sample niche returns the right KB
  entry.

### Phase 3 — MCP servers

- `mcp/shopify-server.ts` — wraps `apps/merchant/src/lib/shopify.ts` calls as
  MCP tools (`list_products`, `push_theme_settings`, `create_order_note`, …).
  Mounted at `apps/merchant/src/app/api/mcp/shopify/route.ts`.
- `mcp/supabase-server.ts` — one tool, `query(sql, params)`, restricted to a
  read-only Postgres role. Mounted at `/api/mcp/supabase/route.ts`.
- **Acceptance:** an MCP inspector (or a manual LangGraph tool-call test) can
  list products and run a read-only query through each server.

### Phase 4 — Orchestrator + first two agents

- `agents/orchestrator.ts` (LangGraph `StateGraph`), `agents/business-advisor.ts`,
  `agents/analytics-agent.ts`.
- Repoint the existing "Edit with EcomAI" chat in
  `apps/merchant/src/components/builder/store-builder.tsx` /
  `apps/merchant/src/lib/builder-actions.ts` at the orchestrator for one
  code path, behind a feature flag.
- **Acceptance:** a real merchant question ("why did my sales drop?") returns
  an answer grounded in that store's own `ai_embeddings` + `store_orders`
  data, with a full trace in `ai_agent_runs`.

### Phase 5 — Guardrails

- `guardrails/approvals.ts`, `guardrails/audit.ts`, `guardrails/cost.ts`.
- Any MCP tool call that writes (not reads) must create an `ai_approvals`
  row and block until `status = 'approved'`.
- **Acceptance:** asking the Business Advisor to change a product price
  produces a pending approval, not an immediate write.

### Phase 6 — Restock check (in-process, not n8n)

- Revised from the original plan: n8n was scoped in here first, but for a
  single decision-and-approval loop entirely within our own DB and Shopify
  integration, routing it through an external workflow tool added a round
  trip and a secret for no real benefit — see the Locked Decisions note
  above.
- `packages/ai/src/agents/restock-agent.ts` — a single-shot `fast-cheap`
  decision (`decideRestock`), not a LangGraph agent — no tools, no
  multi-turn conversation needed.
- `apps/merchant/src/lib/restock-check.ts` — called from the Shopify
  `orders/create` webhook's `after()` block (`app/api/shopify/webhooks/route.ts`),
  after `recordCustomerOrder` (already wired in
  `apps/merchant/src/lib/order-sink.ts`) has decremented stock. Looks up the
  product, asks `decideRestock`, and — same principle as the Shopify write
  tools in Phase 5 — **proposes** a restock via `requestApproval()` rather
  than writing stock directly. Approving it is what actually adjusts
  `products.stock` (the `"inventory.restock"` case in
  `app/api/admin/approvals/[id]/route.ts`, logged to `inventory_adjustments`
  like any other stock change).
- An ops-team email (`alertRestockRecommended` in
  `apps/merchant/src/lib/ops-alert.ts`, reusing the existing Resend pattern)
  fires when a restock is proposed — no supplier-facing approval UI exists
  yet, so ops is the only audience able to act on it today.
- **Acceptance:** a test order against a low-stock product creates a pending
  `ai_approvals` row with a sound recommendation; approving it bumps
  `products.stock` and logs the adjustment. Verified live against a real
  signed Shopify webhook, not just the unit pieces.

### Phase 7 — Portability proof (do not skip) ✅ DONE

- Added a `reasoning-oss` alias to `litellm_config.yaml`, kept separate from
  the live `reasoning` alias. Landed on `groq/openai/gpt-oss-120b` (an
  open-weight model, served over Groq's hosted API) after two dead ends:
  - `groq/compound` resolves and is `active`, but its `supported_features`
    from Groq's own `/v1/models` list only include `json_mode` — **no
    `tools`** — so it can't support the Business Advisor's custom
    function-calling even once the naming/auth issue is fixed. Confirmed via
    Groq's model list before spending more time on it, not assumed.
  - LiteLLM's `<provider>/<model>` parsing bit us twice: `model:
    openai/gpt-oss-120b` alone gets read as "call OpenAI's real API" (wrong
    vendor — gpt-oss isn't hosted there at all), and `groq/compound` alone
    returns "model not found" from Groq itself. The correct form needs
    *both* prefixes: `groq/openai/gpt-oss-120b` — LiteLLM's routing prefix,
    then Groq's own id for the model.
  - This is the second time a Groq model id has gone stale/wrong mid-migration
    (`llama-3.1-8b-instant` no longer existed on this account) — check
    `GET https://api.groq.com/openai/v1/models` against the live account
    before configuring a new alias, rather than assuming a model name.
  - `gpt-4o-mini` (proposed mid-troubleshooting) would have proven the
    "swappable across proprietary vendors" claim only — not "open source,"
    which is the specific claim this phase exists to prove. Rejected for
    that reason before implementing it.
- Re-ran the Phase 4 acceptance test (the exact `/api/admin/ask-advisor`
  question, same store) with `AI_MODEL_REASONING=reasoning-oss` — **zero
  code change**, only the env var value. Result: correct, well-grounded
  answer (real margin data via `run_sql_query`), including a 6-step
  self-correction sequence recovering from 3 wrong-column guesses via
  `information_schema` lookups — the same tool-use competence observed from
  Claude in Phase 4. Slower (61s vs. Claude's single-digit-to-tens of
  seconds) but complete, not truncated.
- Reverted `AI_MODEL_REASONING` to `reasoning` immediately after — this
  alias is a standing proof fixture in the proxy config, not a production
  path.
- This step is what proves the "not rigid to one vendor" requirement, and it
  held under an unusually rocky path to get there — every dead end was a
  real infra/config finding, not a flaw in the role/alias architecture
  itself, which never needed touching once the alias actually resolved.

---

## 6. Environment variables

| Var | Where | Meaning |
|---|---|---|
| `AI_GATEWAY_URL` | all apps | LiteLLM proxy base URL |
| `AI_GATEWAY_API_KEY` | all apps | our own proxy key (not a vendor key) |
| `AI_MODEL_REASONING` | proxy config + apps | alias for the reasoning role |
| `AI_MODEL_WORKHORSE` | proxy config + apps | alias for the workhorse role |
| `AI_MODEL_FAST_CHEAP` | proxy config + apps | alias for the fast/cheap role |
| `AI_MODEL_EMBEDDINGS` | proxy config + apps | alias for the embeddings role |
| `ANTHROPIC_API_KEY` | proxy only | never read by app code directly |
| `VOYAGE_API_KEY` | proxy only | ditto |
| `GROQ_API_KEY` | proxy only | kept as a cheap-tier option, still never in app code |
| `OLLAMA_BASE_URL` | proxy only | self-hosted portability test |

Add the `AI_MODEL_*` and `AI_GATEWAY_*` vars to `turbo.json`'s `globalEnv`
alongside the existing `GROQ_*` entries (remove `GROQ_*` from app code once
Phase 1 lands; the proxy config can still hold a Groq key as a role option).

---

## 7. Risks & mitigations

| Risk | Mitigation |
|---|---|
| LiteLLM proxy becomes a single point of failure | It's stateless — run two instances behind a load balancer once past the proof stage; not needed for the 7-day slice |
| Role aliases drift from what's actually deployed | `resolveModel()` throws loudly on a missing env var instead of silently falling back to the wrong model |
| MCP write tools bypass approval by a future code change | Enforce the approval check inside the MCP server itself, not in calling agent code, so it can't be skipped by a new agent |
| Embedding model swap invalidates existing vectors | `ai_embeddings.provider` records what generated each row; a swap re-embeds rather than silently mixing incompatible vectors |

---

## 8. Explicitly out of scope here

Remaining specialist agents (Launch, Supplier, Marketing, SEO, Growth,
Support), remaining MCP servers (Stripe, Resend, Ads), a supplier-facing
approvals UI (still an internal API route), and tracing/observability
beyond basic `ai_agent_runs` logging. These land in the same package with
the same pattern once the skeleton above is proven. n8n itself stays a
tool worth reaching for later — genuinely cross-system automation a future
feature needs — just not adopted here since nothing built so far needed it.
